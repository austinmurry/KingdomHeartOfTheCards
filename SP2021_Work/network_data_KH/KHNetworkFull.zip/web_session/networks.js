var networks = {"KHXCutsceneNetwork.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.8.2",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "KHXCutsceneNetwork.tsv",
    "name" : "KHXCutsceneNetwork.tsv",
    "SUID" : 61,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "1882",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "3",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 6,
        "name" : "3",
        "SelfLoops" : 0,
        "SUID" : 1882,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 431.99817982921394,
        "y" : -556.0615879766686
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1880",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "4",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 6,
        "name" : "4",
        "SelfLoops" : 0,
        "SUID" : 1880,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 470.92948839158817,
        "y" : -556.0615879766686
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1878",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "5",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 6,
        "name" : "5",
        "SelfLoops" : 0,
        "SUID" : 1878,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 431.0535782442882,
        "y" : -595.9374981239687
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1877",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "6",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 6,
        "name" : "6",
        "SelfLoops" : 0,
        "SUID" : 1877,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 471.8740899765137,
        "y" : -595.9374981239687
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1871",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "VII",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "name" : "VII",
        "SelfLoops" : 0,
        "SUID" : 1871,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 592.5541334771129,
        "y" : -452.0617875712242
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1869",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "VIII",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "name" : "VIII",
        "SelfLoops" : 0,
        "SUID" : 1869,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 624.2219175542166,
        "y" : -470.345191232779
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1868",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "9",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "name" : "9",
        "SelfLoops" : 0,
        "SUID" : 1868,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 592.5541334771129,
        "y" : -488.62859489433373
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1795",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Dale",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Dale",
        "SelfLoops" : 0,
        "SUID" : 1795,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 565.988201158501,
        "y" : -355.0370425320014
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1794",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Chip",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Chip",
        "SelfLoops" : 0,
        "SUID" : 1794,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 467.840408477444,
        "y" : -355.03704253200135
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1731",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 16,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "Barrel",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 16,
        "name" : "Barrel",
        "SelfLoops" : 0,
        "SUID" : 1731,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : true,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 593.3072681364573,
        "y" : -550.368367525417
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "1729",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 16,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "Shock",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 16,
        "name" : "Shock",
        "SelfLoops" : 0,
        "SUID" : 1729,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : true,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 625.2949014311431,
        "y" : -568.8364362188429
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "1728",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 16,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "Lock",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 16,
        "name" : "Lock",
        "SelfLoops" : 0,
        "SUID" : 1728,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : true,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 593.3072681364573,
        "y" : -587.3045049122687
      },
      "selected" : true
    }, {
      "data" : {
        "id" : "1713",
        "ClosenessCentrality" : 0.3153846153846154,
        "Eccentricity" : 5,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.963821138211382,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Oogie Boogie",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Oogie Boogie",
        "SelfLoops" : 0,
        "SUID" : 1713,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.1707317073170733,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -523.1540321782859,
        "y" : -458.3965485139788
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1710",
        "ClosenessCentrality" : 0.3153846153846154,
        "Eccentricity" : 5,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.963821138211382,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Sally",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 6,
        "name" : "Sally",
        "SelfLoops" : 0,
        "SUID" : 1710,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.1707317073170733,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -503.4636866477166,
        "y" : -473.14565199580113
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1700",
        "ClosenessCentrality" : 0.3153846153846154,
        "Eccentricity" : 5,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.963821138211382,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Mayor",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Mayor",
        "SelfLoops" : 0,
        "SUID" : 1700,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.1707317073170733,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -542.3484710314339,
        "y" : -443.1308510001437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1683",
        "ClosenessCentrality" : 0.2523076923076923,
        "Eccentricity" : 5,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.950609756097561,
        "Stress" : 0,
        "TopologicalCoefficient" : 1.0,
        "shared_name" : "Flotsam & Jetsam",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "name" : "Flotsam & Jetsam",
        "SelfLoops" : 0,
        "SUID" : 1683,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.9634146341463414,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 257.9275759730589,
        "y" : -613.9112440270311
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1646",
        "ClosenessCentrality" : 0.3333333333333333,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9666666666666667,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.5666666666666667,
        "shared_name" : "Ursula",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 10,
        "name" : "Ursula",
        "SelfLoops" : 0,
        "SUID" : 1646,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.666666666666667
      },
      "position" : {
        "x" : 236.47207929662784,
        "y" : -561.5798871839957
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1644",
        "ClosenessCentrality" : 0.3346938775510204,
        "Eccentricity" : 4,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.966869918699187,
        "Stress" : 286,
        "TopologicalCoefficient" : 0.45,
        "shared_name" : "Flotsam",
        "BetweennessCentrality" : 0.012044564890093345,
        "NumberOfUndirectedEdges" : 12,
        "name" : "Flotsam",
        "SelfLoops" : 0,
        "SUID" : 1644,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.9878048780487805,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.5
      },
      "position" : {
        "x" : 221.05537697719205,
        "y" : -598.5249445985725
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1642",
        "ClosenessCentrality" : 0.3346938775510204,
        "Eccentricity" : 4,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.966869918699187,
        "Stress" : 286,
        "TopologicalCoefficient" : 0.45,
        "shared_name" : "Jetsam",
        "BetweennessCentrality" : 0.012044564890093345,
        "NumberOfUndirectedEdges" : 12,
        "name" : "Jetsam",
        "SelfLoops" : 0,
        "SUID" : 1642,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.9878048780487805,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.5
      },
      "position" : {
        "x" : 273.38663185895405,
        "y" : -577.0694897255628
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1631",
        "ClosenessCentrality" : 0.3293172690763052,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9660569105691057,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Sebstian",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Sebstian",
        "SelfLoops" : 0,
        "SUID" : 1631,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.0365853658536586,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 285.72442370898773,
        "y" : -537.7502078835189
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1617",
        "ClosenessCentrality" : 0.3374485596707819,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9672764227642277,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.7272727272727273,
        "shared_name" : "Flounder",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "name" : "Flounder",
        "SelfLoops" : 0,
        "SUID" : 1617,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.9634146341463414,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : 189.57563849605015,
        "y" : -282.30206657958274
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1450",
        "ClosenessCentrality" : 0.3374485596707819,
        "Eccentricity" : 5,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9672764227642277,
        "Stress" : 2,
        "TopologicalCoefficient" : 0.5641025641025641,
        "shared_name" : "Iago",
        "BetweennessCentrality" : 1.5055706112616682E-4,
        "NumberOfUndirectedEdges" : 10,
        "name" : "Iago",
        "SelfLoops" : 0,
        "SUID" : 1450,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.9634146341463414,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.333333333333333
      },
      "position" : {
        "x" : 427.27836226614386,
        "y" : 32.243668608292296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1421",
        "ClosenessCentrality" : 0.3253968253968254,
        "Eccentricity" : 5,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9654471544715447,
        "Stress" : 2,
        "TopologicalCoefficient" : 0.7407407407407407,
        "shared_name" : "Rabbit",
        "BetweennessCentrality" : 6.022282445046673E-5,
        "NumberOfUndirectedEdges" : 12,
        "name" : "Rabbit",
        "SelfLoops" : 0,
        "SUID" : 1421,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.073170731707317,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.666666666666667
      },
      "position" : {
        "x" : 237.76725743454267,
        "y" : 550.6672040408498
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1339",
        "ClosenessCentrality" : 0.3129770992366412,
        "Eccentricity" : 5,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9634146341463414,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Sephiroth",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Sephiroth",
        "SelfLoops" : 0,
        "SUID" : 1339,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.1951219512195124,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : -344.8300053416232,
        "y" : -560.8510700428428
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1252",
        "ClosenessCentrality" : 0.3253968253968254,
        "Eccentricity" : 5,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9654471544715447,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "White Rabbit",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "White Rabbit",
        "SelfLoops" : 0,
        "SUID" : 1252,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.073170731707317,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : -591.5923699633855,
        "y" : 698.4475049796552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1042",
        "ClosenessCentrality" : 0.38679245283018865,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9735772357723577,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Sora & Donald",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Sora & Donald",
        "SelfLoops" : 0,
        "SUID" : 1042,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5853658536585367,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.0
      },
      "position" : {
        "x" : 271.2664126475928,
        "y" : 844.2037088686493
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "844",
        "ClosenessCentrality" : 0.36936936936936937,
        "Eccentricity" : 5,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9715447154471544,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Sora & Goofy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Sora & Goofy",
        "SelfLoops" : 0,
        "SUID" : 844,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.707317073170732,
        "selected" : false,
        "NeighborhoodConnectivity" : 35.0
      },
      "position" : {
        "x" : -290.19988704661955,
        "y" : 880.2144200125995
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "706",
        "ClosenessCentrality" : 0.4019607843137255,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9752032520325203,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.5703703703703704,
        "shared_name" : "Minnie",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 6,
        "name" : "Minnie",
        "SelfLoops" : 0,
        "SUID" : 706,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.4878048780487805,
        "selected" : false,
        "NeighborhoodConnectivity" : 25.666666666666668
      },
      "position" : {
        "x" : -254.63015497344588,
        "y" : 604.4517164137899
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "704",
        "ClosenessCentrality" : 0.4019607843137255,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9752032520325203,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.5703703703703704,
        "shared_name" : "Daisy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 6,
        "name" : "Daisy",
        "SelfLoops" : 0,
        "SUID" : 704,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.4878048780487805,
        "selected" : false,
        "NeighborhoodConnectivity" : 25.666666666666668
      },
      "position" : {
        "x" : -294.34355140166383,
        "y" : 584.8752378652114
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "666",
        "ClosenessCentrality" : 0.3416666666666667,
        "Eccentricity" : 5,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9678861788617886,
        "Stress" : 18,
        "TopologicalCoefficient" : 0.4583333333333333,
        "shared_name" : "Smee",
        "BetweennessCentrality" : 5.570611261668172E-4,
        "NumberOfUndirectedEdges" : 10,
        "name" : "Smee",
        "SelfLoops" : 0,
        "SUID" : 666,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.926829268292683,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.333333333333333
      },
      "position" : {
        "x" : -490.87417798242217,
        "y" : -88.40064456231778
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "603",
        "ClosenessCentrality" : 0.4659090909090909,
        "Eccentricity" : 4,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9808943089430894,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.5559701492537313,
        "shared_name" : "Mickey",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 8,
        "name" : "Mickey",
        "SelfLoops" : 0,
        "SUID" : 603,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1463414634146343,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.25
      },
      "position" : {
        "x" : -441.537438931273,
        "y" : -162.14238388182662
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "598",
        "ClosenessCentrality" : 0.4505494505494505,
        "Eccentricity" : 4,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9796747967479675,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.7857142857142857,
        "shared_name" : "Ansem",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 8,
        "name" : "Ansem",
        "SelfLoops" : 0,
        "SUID" : 598,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2195121951219514,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.5
      },
      "position" : {
        "x" : 109.23567192842586,
        "y" : 618.2730108855296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "591",
        "ClosenessCentrality" : 0.4505494505494505,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 0.8333333333333334,
        "Radiality" : 0.9796747967479675,
        "Stress" : 2,
        "TopologicalCoefficient" : 0.32786885245901637,
        "shared_name" : "Eeyore",
        "BetweennessCentrality" : 6.022282445046673E-5,
        "NumberOfUndirectedEdges" : 10,
        "name" : "Eeyore",
        "SelfLoops" : 0,
        "SUID" : 591,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2195121951219514,
        "selected" : false,
        "NeighborhoodConnectivity" : 20.0
      },
      "position" : {
        "x" : 305.6227824900261,
        "y" : 490.89233305372863
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "581",
        "ClosenessCentrality" : 0.45555555555555555,
        "Eccentricity" : 4,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9800813008130081,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.27049180327868855,
        "shared_name" : "Snow Whtie",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 12,
        "name" : "Snow Whtie",
        "SelfLoops" : 0,
        "SUID" : 581,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1951219512195124,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : -433.1757575330894,
        "y" : 471.69829521546035
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "562",
        "ClosenessCentrality" : 0.45555555555555555,
        "Eccentricity" : 4,
        "Degree" : 30,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9800813008130081,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.27049180327868855,
        "shared_name" : "Snow White",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 30,
        "name" : "Snow White",
        "SelfLoops" : 0,
        "SUID" : 562,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1951219512195124,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : 296.97028507353787,
        "y" : -200.34419163537405
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "558",
        "ClosenessCentrality" : 0.45555555555555555,
        "Eccentricity" : 4,
        "Degree" : 42,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9800813008130081,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.27049180327868855,
        "shared_name" : "Aurora",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 42,
        "name" : "Aurora",
        "SelfLoops" : 0,
        "SUID" : 558,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1951219512195124,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : -545.5829964706775,
        "y" : 227.46297133794235
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "556",
        "ClosenessCentrality" : 0.45555555555555555,
        "Eccentricity" : 4,
        "Degree" : 42,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9800813008130081,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.27049180327868855,
        "shared_name" : "Cinderella",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 42,
        "name" : "Cinderella",
        "SelfLoops" : 0,
        "SUID" : 556,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1951219512195124,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.5
      },
      "position" : {
        "x" : 263.529583127161,
        "y" : -231.03820804016124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "554",
        "ClosenessCentrality" : 0.4408602150537635,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9788617886178862,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Belle",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Belle",
        "SelfLoops" : 0,
        "SUID" : 554,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.268292682926829,
        "selected" : false,
        "NeighborhoodConnectivity" : 60.0
      },
      "position" : {
        "x" : -591.5923699633855,
        "y" : -398.97546783490895
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "548",
        "ClosenessCentrality" : 0.448087431693989,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9794715447154471,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.3879781420765027,
        "shared_name" : "Roo",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 10,
        "name" : "Roo",
        "SelfLoops" : 0,
        "SUID" : 548,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.231707317073171,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.666666666666668
      },
      "position" : {
        "x" : -67.92817833601703,
        "y" : -346.64158831093965
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "534",
        "ClosenessCentrality" : 0.4659090909090909,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9808943089430894,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.5559701492537313,
        "shared_name" : "Beast",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 10,
        "name" : "Beast",
        "SelfLoops" : 0,
        "SUID" : 534,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1463414634146343,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.25
      },
      "position" : {
        "x" : -467.8458191496454,
        "y" : -126.39114828634166
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "490",
        "ClosenessCentrality" : 0.44324324324324327,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9790650406504064,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.525,
        "shared_name" : "Wendy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 10,
        "name" : "Wendy",
        "SelfLoops" : 0,
        "SUID" : 490,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2560975609756095,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.5
      },
      "position" : {
        "x" : -321.3133664366756,
        "y" : -269.4506161296533
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "488",
        "ClosenessCentrality" : 0.4530386740331491,
        "Eccentricity" : 4,
        "Degree" : 14,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9798780487804878,
        "Stress" : 8,
        "TopologicalCoefficient" : 0.5343915343915344,
        "shared_name" : "Peter Pan",
        "BetweennessCentrality" : 5.01856870420556E-4,
        "NumberOfUndirectedEdges" : 14,
        "name" : "Peter Pan",
        "SelfLoops" : 0,
        "SUID" : 488,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.207317073170732,
        "selected" : false,
        "NeighborhoodConnectivity" : 33.666666666666664
      },
      "position" : {
        "x" : 66.66409919188118,
        "y" : 631.1006998779967
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "474",
        "ClosenessCentrality" : 0.45810055865921784,
        "Eccentricity" : 4,
        "Degree" : 26,
        "PartnerOfMultiEdgedNodePairs" : 5,
        "ClusteringCoefficient" : 0.1,
        "Radiality" : 0.9802845528455285,
        "Stress" : 594,
        "TopologicalCoefficient" : 0.21,
        "shared_name" : "Jack",
        "BetweennessCentrality" : 0.07226738934056007,
        "NumberOfUndirectedEdges" : 26,
        "name" : "Jack",
        "SelfLoops" : 0,
        "SUID" : 474,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.182926829268293,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.2
      },
      "position" : {
        "x" : -357.9507783118102,
        "y" : -243.80302761775
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "471",
        "ClosenessCentrality" : 0.46067415730337075,
        "Eccentricity" : 4,
        "Degree" : 16,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9804878048780488,
        "Stress" : 32,
        "TopologicalCoefficient" : 0.5050505050505051,
        "shared_name" : "Finkelstein",
        "BetweennessCentrality" : 0.0020074274816822245,
        "NumberOfUndirectedEdges" : 16,
        "name" : "Finkelstein",
        "SelfLoops" : 0,
        "SUID" : 471,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1707317073170733,
        "selected" : false,
        "NeighborhoodConnectivity" : 33.333333333333336
      },
      "position" : {
        "x" : -332.3095945754783,
        "y" : 561.7350568833263
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "466",
        "ClosenessCentrality" : 0.45555555555555555,
        "Eccentricity" : 4,
        "Degree" : 22,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 0.5333333333333333,
        "Radiality" : 0.9800813008130081,
        "Stress" : 162,
        "TopologicalCoefficient" : 0.226775956284153,
        "shared_name" : "Owl",
        "BetweennessCentrality" : 0.007352007623010345,
        "NumberOfUndirectedEdges" : 22,
        "name" : "Owl",
        "SelfLoops" : 0,
        "SUID" : 466,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1951219512195124,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.833333333333334
      },
      "position" : {
        "x" : -23.288354496082434,
        "y" : -345.78161502366635
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "450",
        "ClosenessCentrality" : 0.47126436781609193,
        "Eccentricity" : 3,
        "Degree" : 30,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.98130081300813,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.4227941176470588,
        "shared_name" : "Triton",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 30,
        "name" : "Triton",
        "SelfLoops" : 0,
        "SUID" : 450,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1219512195121952,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.75
      },
      "position" : {
        "x" : 227.42563044616293,
        "y" : -258.55016526846475
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "447",
        "ClosenessCentrality" : 0.4880952380952381,
        "Eccentricity" : 3,
        "Degree" : 48,
        "PartnerOfMultiEdgedNodePairs" : 9,
        "ClusteringCoefficient" : 0.2777777777777778,
        "Radiality" : 0.982520325203252,
        "Stress" : 1912,
        "TopologicalCoefficient" : 0.20098039215686275,
        "shared_name" : "Ariel",
        "BetweennessCentrality" : 0.12634064219430072,
        "NumberOfUndirectedEdges" : 48,
        "name" : "Ariel",
        "SelfLoops" : 0,
        "SUID" : 447,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.048780487804878,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.777777777777779
      },
      "position" : {
        "x" : 149.43843276325458,
        "y" : -302.6931207264278
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "ClosenessCentrality" : 0.45810055865921784,
        "Eccentricity" : 4,
        "Degree" : 28,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9802845528455285,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.5390625,
        "shared_name" : "Hercules",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 28,
        "name" : "Hercules",
        "SelfLoops" : 0,
        "SUID" : 443,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.182926829268293,
        "selected" : false,
        "NeighborhoodConnectivity" : 34.5
      },
      "position" : {
        "x" : -157.5943900160637,
        "y" : -336.1254932935351
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "ClosenessCentrality" : 0.4530386740331491,
        "Eccentricity" : 4,
        "Degree" : 18,
        "PartnerOfMultiEdgedNodePairs" : 5,
        "ClusteringCoefficient" : 0.7,
        "Radiality" : 0.9798780487804878,
        "Stress" : 6,
        "TopologicalCoefficient" : 0.2721311475409836,
        "shared_name" : "Tigger",
        "BetweennessCentrality" : 3.1115125966074475E-4,
        "NumberOfUndirectedEdges" : 18,
        "name" : "Tigger",
        "SelfLoops" : 0,
        "SUID" : 441,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.207317073170732,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.6
      },
      "position" : {
        "x" : 334.7633004323212,
        "y" : 457.16327499929025
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "432",
        "ClosenessCentrality" : 0.4530386740331491,
        "Eccentricity" : 4,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9798780487804878,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.42857142857142855,
        "shared_name" : "Geppetto",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 12,
        "name" : "Geppetto",
        "SelfLoops" : 0,
        "SUID" : 432,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.207317073170732,
        "selected" : false,
        "NeighborhoodConnectivity" : 27.0
      },
      "position" : {
        "x" : 64.89542938869374,
        "y" : -332.0728340448212
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "424",
        "ClosenessCentrality" : 0.44324324324324327,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9790650406504064,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.55,
        "shared_name" : "????????",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 6,
        "name" : "????????",
        "SelfLoops" : 0,
        "SUID" : 424,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2560975609756095,
        "selected" : false,
        "NeighborhoodConnectivity" : 33.0
      },
      "position" : {
        "x" : -200.85945939521952,
        "y" : -324.9492471378025
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "412",
        "ClosenessCentrality" : 0.45810055865921784,
        "Eccentricity" : 4,
        "Degree" : 28,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 0.5333333333333333,
        "Radiality" : 0.9802845528455285,
        "Stress" : 186,
        "TopologicalCoefficient" : 0.23387096774193547,
        "shared_name" : "Piglet",
        "BetweennessCentrality" : 0.00772820474717495,
        "NumberOfUndirectedEdges" : 28,
        "name" : "Piglet",
        "SelfLoops" : 0,
        "SUID" : 412,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.182926829268293,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.5
      },
      "position" : {
        "x" : 360.9445133431816,
        "y" : 420.6762305509683
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "400",
        "ClosenessCentrality" : 0.4659090909090909,
        "Eccentricity" : 4,
        "Degree" : 36,
        "PartnerOfMultiEdgedNodePairs" : 5,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9808943089430894,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.45454545454545453,
        "shared_name" : "Genie",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 36,
        "name" : "Genie",
        "SelfLoops" : 0,
        "SUID" : 400,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1463414634146343,
        "selected" : false,
        "NeighborhoodConnectivity" : 30.0
      },
      "position" : {
        "x" : -505.6393388052601,
        "y" : 358.6004625250031
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "ClosenessCentrality" : 0.47126436781609193,
        "Eccentricity" : 4,
        "Degree" : 54,
        "PartnerOfMultiEdgedNodePairs" : 7,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.98130081300813,
        "Stress" : 292,
        "TopologicalCoefficient" : 0.3484848484848485,
        "shared_name" : "Aladdin",
        "BetweennessCentrality" : 0.01025179527889555,
        "NumberOfUndirectedEdges" : 54,
        "name" : "Aladdin",
        "SelfLoops" : 0,
        "SUID" : 395,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1219512195121952,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -522.9430243799059,
        "y" : 316.2746660990513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "387",
        "ClosenessCentrality" : 0.4685714285714285,
        "Eccentricity" : 4,
        "Degree" : 32,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 0.6,
        "Radiality" : 0.9810975609756097,
        "Stress" : 30,
        "TopologicalCoefficient" : 0.30303030303030304,
        "shared_name" : "Pinocchio",
        "BetweennessCentrality" : 0.0016762019472046571,
        "NumberOfUndirectedEdges" : 32,
        "name" : "Pinocchio",
        "SelfLoops" : 0,
        "SUID" : 387,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1341463414634148,
        "selected" : false,
        "NeighborhoodConnectivity" : 20.0
      },
      "position" : {
        "x" : -460.69745330296763,
        "y" : 436.2585047097198
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "ClosenessCentrality" : 0.4408602150537635,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9788617886178862,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Fairy Godmother",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "name" : "Fairy Godmother",
        "SelfLoops" : 0,
        "SUID" : 361,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.268292682926829,
        "selected" : false,
        "NeighborhoodConnectivity" : 60.0
      },
      "position" : {
        "x" : -608.9060250154592,
        "y" : -381.55159544978153
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "ClosenessCentrality" : 0.46067415730337075,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 5,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9804878048780488,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.471875,
        "shared_name" : "Sora, Donald & Goofy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 10,
        "name" : "Sora, Donald & Goofy",
        "SelfLoops" : 0,
        "SUID" : 345,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1707317073170733,
        "selected" : false,
        "NeighborhoodConnectivity" : 30.2
      },
      "position" : {
        "x" : -158.21337286274905,
        "y" : 635.4666213489584
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "ClosenessCentrality" : 0.46067415730337075,
        "Eccentricity" : 4,
        "Degree" : 36,
        "PartnerOfMultiEdgedNodePairs" : 5,
        "ClusteringCoefficient" : 0.8,
        "Radiality" : 0.9804878048780488,
        "Stress" : 16,
        "TopologicalCoefficient" : 0.45,
        "shared_name" : "Tarzan",
        "BetweennessCentrality" : 6.022282445046673E-4,
        "NumberOfUndirectedEdges" : 36,
        "name" : "Tarzan",
        "SelfLoops" : 0,
        "SUID" : 328,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1707317073170733,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.8
      },
      "position" : {
        "x" : -21.394483100386424,
        "y" : 645.1281937095548
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "325",
        "ClosenessCentrality" : 0.44565217391304346,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9792682926829268,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.4,
        "shared_name" : "Clayton",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 10,
        "name" : "Clayton",
        "SelfLoops" : 0,
        "SUID" : 325,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2439024390243905,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : 107.513825683974,
        "y" : -319.40157888328304
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "317",
        "ClosenessCentrality" : 0.4530386740331491,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9798780487804878,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.5608465608465608,
        "shared_name" : "Donald & Sora",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 6,
        "name" : "Donald & Sora",
        "SelfLoops" : 0,
        "SUID" : 317,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.207317073170732,
        "selected" : false,
        "NeighborhoodConnectivity" : 35.333333333333336
      },
      "position" : {
        "x" : 23.15246057100387,
        "y" : 640.0628976141763
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "ClosenessCentrality" : 0.4530386740331491,
        "Eccentricity" : 4,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 0.3333333333333333,
        "Radiality" : 0.9798780487804878,
        "Stress" : 194,
        "TopologicalCoefficient" : 0.3548387096774194,
        "shared_name" : "Cloud",
        "BetweennessCentrality" : 0.024390243902439025,
        "NumberOfUndirectedEdges" : 8,
        "name" : "Cloud",
        "SelfLoops" : 0,
        "SUID" : 302,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.207317073170732,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.333333333333332
      },
      "position" : {
        "x" : -242.59999257424033,
        "y" : -310.0692623099666
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "ClosenessCentrality" : 0.4767441860465116,
        "Eccentricity" : 4,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 0.3333333333333333,
        "Radiality" : 0.9817073170731708,
        "Stress" : 368,
        "TopologicalCoefficient" : 0.29901960784313725,
        "shared_name" : "Hades",
        "BetweennessCentrality" : 0.0097141641857089,
        "NumberOfUndirectedEdges" : 12,
        "name" : "Hades",
        "SelfLoops" : 0,
        "SUID" : 296,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.097560975609756,
        "selected" : false,
        "NeighborhoodConnectivity" : 20.5
      },
      "position" : {
        "x" : -484.90744407454804,
        "y" : 398.4788959772236
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "ClosenessCentrality" : 0.45810055865921784,
        "Eccentricity" : 4,
        "Degree" : 42,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9802845528455285,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.5390625,
        "shared_name" : "Philoctetes",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 42,
        "name" : "Philoctetes",
        "SelfLoops" : 0,
        "SUID" : 292,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.182926829268293,
        "selected" : false,
        "NeighborhoodConnectivity" : 34.5
      },
      "position" : {
        "x" : -112.83444748728834,
        "y" : -343.445127116136
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "ClosenessCentrality" : 0.45555555555555555,
        "Eccentricity" : 4,
        "Degree" : 16,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9800813008130081,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.6979166666666666,
        "shared_name" : "Cheshire Cat",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 16,
        "name" : "Cheshire Cat",
        "SelfLoops" : 0,
        "SUID" : 275,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1951219512195124,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.666666666666664
      },
      "position" : {
        "x" : 21.204079828345243,
        "y" : -340.8980885329537
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "ClosenessCentrality" : 0.46067415730337075,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9804878048780488,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.5576923076923077,
        "shared_name" : "Card Soldier",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 10,
        "name" : "Card Soldier",
        "SelfLoops" : 0,
        "SUID" : 272,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1707317073170733,
        "selected" : false,
        "NeighborhoodConnectivity" : 36.25
      },
      "position" : {
        "x" : 327.08850043369455,
        "y" : -167.18324769281287
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "ClosenessCentrality" : 0.47953216374269003,
        "Eccentricity" : 4,
        "Degree" : 54,
        "PartnerOfMultiEdgedNodePairs" : 11,
        "ClusteringCoefficient" : 0.45454545454545453,
        "Radiality" : 0.9819105691056911,
        "Stress" : 474,
        "TopologicalCoefficient" : 0.25,
        "shared_name" : "Alice",
        "BetweennessCentrality" : 0.028962159991970295,
        "NumberOfUndirectedEdges" : 54,
        "name" : "Alice",
        "SelfLoops" : 0,
        "SUID" : 265,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.0853658536585367,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.09090909090909
      },
      "position" : {
        "x" : -402.2744929894034,
        "y" : 504.79515653468343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "ClosenessCentrality" : 0.46067415730337075,
        "Eccentricity" : 4,
        "Degree" : 24,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9804878048780488,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.5576923076923077,
        "shared_name" : "Queen of Hearts",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 24,
        "name" : "Queen of Hearts",
        "SelfLoops" : 0,
        "SUID" : 263,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1707317073170733,
        "selected" : false,
        "NeighborhoodConnectivity" : 36.25
      },
      "position" : {
        "x" : -368.3134568543014,
        "y" : 535.0802824395237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "258",
        "ClosenessCentrality" : 0.4505494505494505,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9796747967479675,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.7857142857142857,
        "shared_name" : "Doorknob",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 6,
        "name" : "Doorknob",
        "SelfLoops" : 0,
        "SUID" : 258,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2195121951219514,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.5
      },
      "position" : {
        "x" : -282.84767328080164,
        "y" : -291.5271411721823
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "253",
        "ClosenessCentrality" : 0.4685714285714285,
        "Eccentricity" : 4,
        "Degree" : 30,
        "PartnerOfMultiEdgedNodePairs" : 5,
        "ClusteringCoefficient" : 0.9,
        "Radiality" : 0.9810975609756097,
        "Stress" : 4,
        "TopologicalCoefficient" : 0.4626865671641791,
        "shared_name" : "Jiminy",
        "BetweennessCentrality" : 1.5055706112616682E-4,
        "NumberOfUndirectedEdges" : 30,
        "name" : "Jiminy",
        "SelfLoops" : 0,
        "SUID" : 253,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1341463414634148,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.0
      },
      "position" : {
        "x" : -66.66320751776084,
        "y" : 646.1445446364289
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "222",
        "ClosenessCentrality" : 0.47126436781609193,
        "Eccentricity" : 4,
        "Degree" : 48,
        "PartnerOfMultiEdgedNodePairs" : 7,
        "ClusteringCoefficient" : 0.42857142857142855,
        "Radiality" : 0.98130081300813,
        "Stress" : 332,
        "TopologicalCoefficient" : 0.34285714285714286,
        "shared_name" : "??????",
        "BetweennessCentrality" : 0.00859279734618488,
        "NumberOfUndirectedEdges" : 48,
        "name" : "??????",
        "SelfLoops" : 0,
        "SUID" : 222,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1219512195121952,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.428571428571427
      },
      "position" : {
        "x" : 383.98287026484525,
        "y" : 381.4793816205313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "ClosenessCentrality" : 0.46327683615819204,
        "Eccentricity" : 4,
        "Degree" : 32,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9806910569105691,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.4114583333333333,
        "shared_name" : "Cid",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 32,
        "name" : "Cid",
        "SelfLoops" : 0,
        "SUID" : 220,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.158536585365854,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.333333333333332
      },
      "position" : {
        "x" : -550.6342940848997,
        "y" : 182.31583371115244
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "217",
        "ClosenessCentrality" : 0.4408602150537635,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9788617886178862,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "???",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "name" : "???",
        "SelfLoops" : 0,
        "SUID" : 217,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.268292682926829,
        "selected" : false,
        "NeighborhoodConnectivity" : 60.0
      },
      "position" : {
        "x" : -573.7810979258646,
        "y" : -415.8903301920434
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "179",
        "ClosenessCentrality" : 0.4685714285714285,
        "Eccentricity" : 4,
        "Degree" : 92,
        "PartnerOfMultiEdgedNodePairs" : 8,
        "ClusteringCoefficient" : 0.8571428571428571,
        "Radiality" : 0.9810975609756097,
        "Stress" : 8,
        "TopologicalCoefficient" : 0.33203125,
        "shared_name" : "Aerith",
        "BetweennessCentrality" : 2.308541603934558E-4,
        "NumberOfUndirectedEdges" : 92,
        "name" : "Aerith",
        "SelfLoops" : 0,
        "SUID" : 179,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1341463414634148,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.25
      },
      "position" : {
        "x" : -112.87141159351228,
        "y" : 642.9128403272848
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177",
        "ClosenessCentrality" : 0.4659090909090909,
        "Eccentricity" : 4,
        "Degree" : 64,
        "PartnerOfMultiEdgedNodePairs" : 7,
        "ClusteringCoefficient" : 0.9523809523809523,
        "Radiality" : 0.9808943089430894,
        "Stress" : 2,
        "TopologicalCoefficient" : 0.3705357142857143,
        "shared_name" : "Yuffie",
        "BetweennessCentrality" : 5.018568704205561E-5,
        "NumberOfUndirectedEdges" : 64,
        "name" : "Yuffie",
        "SelfLoops" : 0,
        "SUID" : 177,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1463414634146343,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.714285714285715
      },
      "position" : {
        "x" : -528.5743926486218,
        "y" : -0.0468930491744004
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "175",
        "ClosenessCentrality" : 0.47126436781609193,
        "Eccentricity" : 4,
        "Degree" : 96,
        "PartnerOfMultiEdgedNodePairs" : 9,
        "ClusteringCoefficient" : 0.75,
        "Radiality" : 0.98130081300813,
        "Stress" : 20,
        "TopologicalCoefficient" : 0.3003472222222222,
        "shared_name" : "Leon",
        "BetweennessCentrality" : 7.32711030814012E-4,
        "NumberOfUndirectedEdges" : 96,
        "name" : "Leon",
        "SelfLoops" : 0,
        "SUID" : 175,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1219512195121952,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.22222222222222
      },
      "position" : {
        "x" : -551.5112411713334,
        "y" : 135.89151351942655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "173",
        "ClosenessCentrality" : 0.45555555555555555,
        "Eccentricity" : 4,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.9800813008130081,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.44841269841269843,
        "shared_name" : "Donald & Goofy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 8,
        "name" : "Donald & Goofy",
        "SelfLoops" : 0,
        "SUID" : 173,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1951219512195124,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.25
      },
      "position" : {
        "x" : -548.1017696209981,
        "y" : 90.03158589561326
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "136",
        "ClosenessCentrality" : 0.4880952380952381,
        "Eccentricity" : 3,
        "Degree" : 30,
        "PartnerOfMultiEdgedNodePairs" : 7,
        "ClusteringCoefficient" : 0.5714285714285714,
        "Radiality" : 0.982520325203252,
        "Stress" : 400,
        "TopologicalCoefficient" : 0.3199195171026157,
        "shared_name" : "Sebastian",
        "BetweennessCentrality" : 0.015958364129095834,
        "NumberOfUndirectedEdges" : 30,
        "name" : "Sebastian",
        "SelfLoops" : 0,
        "SUID" : 136,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.048780487804878,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.714285714285715
      },
      "position" : {
        "x" : 398.1365482548514,
        "y" : -52.93024371740569
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "133",
        "ClosenessCentrality" : 0.4659090909090909,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 5,
        "ClusteringCoefficient" : 0.9,
        "Radiality" : 0.9808943089430894,
        "Stress" : 4,
        "TopologicalCoefficient" : 0.4575757575757576,
        "shared_name" : "Merlin",
        "BetweennessCentrality" : 7.695138679781859E-5,
        "NumberOfUndirectedEdges" : 10,
        "name" : "Merlin",
        "SelfLoops" : 0,
        "SUID" : 133,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1463414634146343,
        "selected" : false,
        "NeighborhoodConnectivity" : 30.2
      },
      "position" : {
        "x" : 200.72800382196692,
        "y" : 575.2635879615339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "123",
        "ClosenessCentrality" : 0.4767441860465116,
        "Eccentricity" : 4,
        "Degree" : 34,
        "PartnerOfMultiEdgedNodePairs" : 9,
        "ClusteringCoefficient" : 0.5,
        "Radiality" : 0.9817073170731708,
        "Stress" : 528,
        "TopologicalCoefficient" : 0.2878787878787879,
        "shared_name" : "Jafar",
        "BetweennessCentrality" : 0.015442009728369269,
        "NumberOfUndirectedEdges" : 34,
        "name" : "Jafar",
        "SelfLoops" : 0,
        "SUID" : 123,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.097560975609756,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.0
      },
      "position" : {
        "x" : 435.91512484167833,
        "y" : 76.27580257150566
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "120",
        "ClosenessCentrality" : 0.47953216374269003,
        "Eccentricity" : 4,
        "Degree" : 50,
        "PartnerOfMultiEdgedNodePairs" : 10,
        "ClusteringCoefficient" : 0.5555555555555556,
        "Radiality" : 0.9819105691056911,
        "Stress" : 106,
        "TopologicalCoefficient" : 0.23636363636363636,
        "shared_name" : "Jasmine",
        "BetweennessCentrality" : 0.004665118079752227,
        "NumberOfUndirectedEdges" : 50,
        "name" : "Jasmine",
        "SelfLoops" : 0,
        "SUID" : 120,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.0853658536585367,
        "selected" : false,
        "NeighborhoodConnectivity" : 15.6
      },
      "position" : {
        "x" : -536.3440745013764,
        "y" : 272.28410673052565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "117",
        "ClosenessCentrality" : 0.4659090909090909,
        "Eccentricity" : 4,
        "Degree" : 40,
        "PartnerOfMultiEdgedNodePairs" : 7,
        "ClusteringCoefficient" : 0.5714285714285714,
        "Radiality" : 0.9808943089430894,
        "Stress" : 34,
        "TopologicalCoefficient" : 0.33705357142857145,
        "shared_name" : "Jane",
        "BetweennessCentrality" : 0.0015557562983037239,
        "NumberOfUndirectedEdges" : 40,
        "name" : "Jane",
        "SelfLoops" : 0,
        "SUID" : 117,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1463414634146343,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.571428571428573
      },
      "position" : {
        "x" : 441.11401350066376,
        "y" : 165.9612625879888
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "114",
        "ClosenessCentrality" : 0.5815602836879433,
        "Eccentricity" : 4,
        "Degree" : 350,
        "PartnerOfMultiEdgedNodePairs" : 35,
        "ClusteringCoefficient" : 0.15294117647058825,
        "Radiality" : 0.9880081300813008,
        "Stress" : 2064,
        "TopologicalCoefficient" : 0.11918367346938775,
        "shared_name" : "Donald",
        "BetweennessCentrality" : 0.10499124482864318,
        "NumberOfUndirectedEdges" : 350,
        "name" : "Donald",
        "SelfLoops" : 0,
        "SUID" : 114,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.7195121951219512,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.371428571428572
      },
      "position" : {
        "x" : -207.2500442150298,
        "y" : 622.4125306199824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "106",
        "ClosenessCentrality" : 0.6259541984732824,
        "Eccentricity" : 3,
        "Degree" : 344,
        "PartnerOfMultiEdgedNodePairs" : 39,
        "ClusteringCoefficient" : 0.13900134952766532,
        "Radiality" : 0.9900406504065041,
        "Stress" : 3164,
        "TopologicalCoefficient" : 0.10803418803418803,
        "shared_name" : "Goofy",
        "BetweennessCentrality" : 0.16885220570857432,
        "NumberOfUndirectedEdges" : 344,
        "name" : "Goofy",
        "SelfLoops" : 0,
        "SUID" : 106,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.5975609756097562,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.128205128205128
      },
      "position" : {
        "x" : 156.0624529765172,
        "y" : 599.110791230677
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "104",
        "ClosenessCentrality" : 0.35042735042735046,
        "Eccentricity" : 5,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9691056910569106,
        "Stress" : 30,
        "TopologicalCoefficient" : 0.4125,
        "shared_name" : "Captain Hook",
        "BetweennessCentrality" : 9.535280537990566E-4,
        "NumberOfUndirectedEdges" : 12,
        "name" : "Captain Hook",
        "SelfLoops" : 0,
        "SUID" : 104,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.8536585365853657,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.25
      },
      "position" : {
        "x" : 418.4509281700184,
        "y" : 298.880108267144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "102",
        "ClosenessCentrality" : 0.3374485596707819,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9672764227642277,
        "Stress" : 12,
        "TopologicalCoefficient" : 0.48717948717948717,
        "shared_name" : "Hook",
        "BetweennessCentrality" : 3.9646692763223936E-4,
        "NumberOfUndirectedEdges" : 8,
        "name" : "Hook",
        "SelfLoops" : 0,
        "SUID" : 102,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.9634146341463414,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.333333333333333
      },
      "position" : {
        "x" : 429.88576270536396,
        "y" : 255.95193287049472
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "98",
        "ClosenessCentrality" : 0.36936936936936937,
        "Eccentricity" : 5,
        "Degree" : 34,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 0.3333333333333333,
        "Radiality" : 0.9715447154471544,
        "Stress" : 82,
        "TopologicalCoefficient" : 0.3273809523809524,
        "shared_name" : "Maleficent",
        "BetweennessCentrality" : 0.004133997087926626,
        "NumberOfUndirectedEdges" : 34,
        "name" : "Maleficent",
        "SelfLoops" : 0,
        "SUID" : 98,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.707317073170732,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.166666666666666
      },
      "position" : {
        "x" : 414.70185986795605,
        "y" : -10.82899182229744
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "96",
        "ClosenessCentrality" : 0.5061728395061729,
        "Eccentricity" : 4,
        "Degree" : 180,
        "PartnerOfMultiEdgedNodePairs" : 15,
        "ClusteringCoefficient" : 0.3238095238095238,
        "Radiality" : 0.983739837398374,
        "Stress" : 1024,
        "TopologicalCoefficient" : 0.1961904761904762,
        "shared_name" : "Riku",
        "BetweennessCentrality" : 0.04744981924295379,
        "NumberOfUndirectedEdges" : 180,
        "name" : "Riku",
        "SelfLoops" : 0,
        "SUID" : 96,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.975609756097561,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.733333333333333
      },
      "position" : {
        "x" : -511.6685057848681,
        "y" : -45.599604340055066
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "94",
        "ClosenessCentrality" : 0.47126436781609193,
        "Eccentricity" : 4,
        "Degree" : 54,
        "PartnerOfMultiEdgedNodePairs" : 8,
        "ClusteringCoefficient" : 0.4642857142857143,
        "Radiality" : 0.98130081300813,
        "Stress" : 274,
        "TopologicalCoefficient" : 0.19807692307692307,
        "shared_name" : "Pooh",
        "BetweennessCentrality" : 0.012172288549885665,
        "NumberOfUndirectedEdges" : 54,
        "name" : "Pooh",
        "SelfLoops" : 0,
        "SUID" : 94,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1219512195121952,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.875
      },
      "position" : {
        "x" : 273.0725727105414,
        "y" : 522.3153947009669
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "89",
        "ClosenessCentrality" : 0.351931330472103,
        "Eccentricity" : 5,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 0.16666666666666666,
        "Radiality" : 0.9693089430894308,
        "Stress" : 22,
        "TopologicalCoefficient" : 0.4852941176470588,
        "shared_name" : "??????????",
        "BetweennessCentrality" : 5.900402919373109E-4,
        "NumberOfUndirectedEdges" : 10,
        "name" : "??????????",
        "SelfLoops" : 0,
        "SUID" : 89,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.841463414634146,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.75
      },
      "position" : {
        "x" : 403.2106609460085,
        "y" : 340.64878869986944
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84",
        "ClosenessCentrality" : 0.780952380952381,
        "Eccentricity" : 3,
        "Degree" : 762,
        "PartnerOfMultiEdgedNodePairs" : 60,
        "ClusteringCoefficient" : 0.08305084745762711,
        "Radiality" : 0.9953252032520326,
        "Stress" : 7206,
        "TopologicalCoefficient" : 0.08247863247863248,
        "shared_name" : "Sora",
        "BetweennessCentrality" : 0.6170500766255059,
        "NumberOfUndirectedEdges" : 762,
        "name" : "Sora",
        "SelfLoops" : 0,
        "SUID" : 84,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.2804878048780488,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.483333333333333
      },
      "position" : {
        "x" : -398.3187610170028,
        "y" : -217.19031530713818
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82",
        "ClosenessCentrality" : 0.48520710059171596,
        "Eccentricity" : 4,
        "Degree" : 76,
        "PartnerOfMultiEdgedNodePairs" : 9,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9823170731707317,
        "Stress" : 88,
        "TopologicalCoefficient" : 0.30434782608695654,
        "shared_name" : "Kairi",
        "BetweennessCentrality" : 0.0027060187629293323,
        "NumberOfUndirectedEdges" : 76,
        "name" : "Kairi",
        "SelfLoops" : 0,
        "SUID" : 82,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.0609756097560976,
        "selected" : false,
        "NeighborhoodConnectivity" : 21.0
      },
      "position" : {
        "x" : -540.5428266170097,
        "y" : 45.04752571996164
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "78",
        "ClosenessCentrality" : 0.4939759036144578,
        "Eccentricity" : 4,
        "Degree" : 40,
        "PartnerOfMultiEdgedNodePairs" : 10,
        "ClusteringCoefficient" : 0.4666666666666667,
        "Radiality" : 0.9829268292682927,
        "Stress" : 584,
        "TopologicalCoefficient" : 0.2633802816901408,
        "shared_name" : "?????",
        "BetweennessCentrality" : 0.013349393588779315,
        "NumberOfUndirectedEdges" : 40,
        "name" : "?????",
        "SelfLoops" : 0,
        "SUID" : 78,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.024390243902439,
        "selected" : false,
        "NeighborhoodConnectivity" : 18.7
      },
      "position" : {
        "x" : 377.7532117907582,
        "y" : -93.44627867972417
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "76",
        "ClosenessCentrality" : 0.47398843930635837,
        "Eccentricity" : 4,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.9815040650406505,
        "Stress" : 34,
        "TopologicalCoefficient" : 0.33578431372549017,
        "shared_name" : "???????",
        "BetweennessCentrality" : 0.0010454265196812623,
        "NumberOfUndirectedEdges" : 12,
        "name" : "???????",
        "SelfLoops" : 0,
        "SUID" : 76,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1097560975609757,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.833333333333332
      },
      "position" : {
        "x" : 440.5437768125737,
        "y" : 120.94498549429875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "72",
        "ClosenessCentrality" : 0.4659090909090909,
        "Eccentricity" : 4,
        "Degree" : 14,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 0.8333333333333334,
        "Radiality" : 0.9808943089430894,
        "Stress" : 8,
        "TopologicalCoefficient" : 0.43656716417910446,
        "shared_name" : "Voice",
        "BetweennessCentrality" : 1.756499046471946E-4,
        "NumberOfUndirectedEdges" : 14,
        "name" : "Voice",
        "SelfLoops" : 0,
        "SUID" : 72,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.1463414634146343,
        "selected" : false,
        "NeighborhoodConnectivity" : 29.25
      },
      "position" : {
        "x" : 353.92681983157274,
        "y" : -131.68817046455848
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "71",
        "ClosenessCentrality" : 0.49696969696969695,
        "Eccentricity" : 4,
        "Degree" : 48,
        "PartnerOfMultiEdgedNodePairs" : 12,
        "ClusteringCoefficient" : 0.2878787878787879,
        "Radiality" : 0.9831300813008129,
        "Stress" : 1074,
        "TopologicalCoefficient" : 0.2,
        "shared_name" : "????",
        "BetweennessCentrality" : 0.04678083467604694,
        "NumberOfUndirectedEdges" : 48,
        "name" : "????",
        "SelfLoops" : 0,
        "SUID" : 71,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.0121951219512195,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : 437.5217270147898,
        "y" : 211.50890285859214
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "1892",
        "source" : "1882",
        "target" : "1880",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "3 (cut1) 4",
        "shared_interaction" : "cut1",
        "name" : "3 (cut1) 4",
        "interaction" : "cut1",
        "SUID" : 1892,
        "BEND_MAP_ID" : 1892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1891",
        "source" : "1882",
        "target" : "1878",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "3 (cut1) 5",
        "shared_interaction" : "cut1",
        "name" : "3 (cut1) 5",
        "interaction" : "cut1",
        "SUID" : 1891,
        "BEND_MAP_ID" : 1891,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1890",
        "source" : "1882",
        "target" : "1877",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "3 (cut1) 6",
        "shared_interaction" : "cut1",
        "name" : "3 (cut1) 6",
        "interaction" : "cut1",
        "SUID" : 1890,
        "BEND_MAP_ID" : 1890,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1889",
        "source" : "1880",
        "target" : "1882",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "4 (cut1) 3",
        "shared_interaction" : "cut1",
        "name" : "4 (cut1) 3",
        "interaction" : "cut1",
        "SUID" : 1889,
        "BEND_MAP_ID" : 1889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1888",
        "source" : "1880",
        "target" : "1878",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "4 (cut1) 5",
        "shared_interaction" : "cut1",
        "name" : "4 (cut1) 5",
        "interaction" : "cut1",
        "SUID" : 1888,
        "BEND_MAP_ID" : 1888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1887",
        "source" : "1880",
        "target" : "1877",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "4 (cut1) 6",
        "shared_interaction" : "cut1",
        "name" : "4 (cut1) 6",
        "interaction" : "cut1",
        "SUID" : 1887,
        "BEND_MAP_ID" : 1887,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1886",
        "source" : "1878",
        "target" : "1882",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "5 (cut1) 3",
        "shared_interaction" : "cut1",
        "name" : "5 (cut1) 3",
        "interaction" : "cut1",
        "SUID" : 1886,
        "BEND_MAP_ID" : 1886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1885",
        "source" : "1878",
        "target" : "1880",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "5 (cut1) 4",
        "shared_interaction" : "cut1",
        "name" : "5 (cut1) 4",
        "interaction" : "cut1",
        "SUID" : 1885,
        "BEND_MAP_ID" : 1885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1884",
        "source" : "1878",
        "target" : "1877",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "5 (cut1) 6",
        "shared_interaction" : "cut1",
        "name" : "5 (cut1) 6",
        "interaction" : "cut1",
        "SUID" : 1884,
        "BEND_MAP_ID" : 1884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1883",
        "source" : "1877",
        "target" : "1882",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "6 (cut1) 3",
        "shared_interaction" : "cut1",
        "name" : "6 (cut1) 3",
        "interaction" : "cut1",
        "SUID" : 1883,
        "BEND_MAP_ID" : 1883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1881",
        "source" : "1877",
        "target" : "1880",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "6 (cut1) 4",
        "shared_interaction" : "cut1",
        "name" : "6 (cut1) 4",
        "interaction" : "cut1",
        "SUID" : 1881,
        "BEND_MAP_ID" : 1881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1879",
        "source" : "1877",
        "target" : "1878",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "6 (cut1) 5",
        "shared_interaction" : "cut1",
        "name" : "6 (cut1) 5",
        "interaction" : "cut1",
        "SUID" : 1879,
        "BEND_MAP_ID" : 1879,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1876",
        "source" : "1871",
        "target" : "1869",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "VII (cut1) VIII",
        "shared_interaction" : "cut1",
        "name" : "VII (cut1) VIII",
        "interaction" : "cut1",
        "SUID" : 1876,
        "BEND_MAP_ID" : 1876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1875",
        "source" : "1871",
        "target" : "1868",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "VII (cut1) 9",
        "shared_interaction" : "cut1",
        "name" : "VII (cut1) 9",
        "interaction" : "cut1",
        "SUID" : 1875,
        "BEND_MAP_ID" : 1875,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1874",
        "source" : "1869",
        "target" : "1871",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "VIII (cut1) VII",
        "shared_interaction" : "cut1",
        "name" : "VIII (cut1) VII",
        "interaction" : "cut1",
        "SUID" : 1874,
        "BEND_MAP_ID" : 1874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1873",
        "source" : "1869",
        "target" : "1868",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "VIII (cut1) 9",
        "shared_interaction" : "cut1",
        "name" : "VIII (cut1) 9",
        "interaction" : "cut1",
        "SUID" : 1873,
        "BEND_MAP_ID" : 1873,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1872",
        "source" : "1868",
        "target" : "1871",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "9 (cut1) VII",
        "shared_interaction" : "cut1",
        "name" : "9 (cut1) VII",
        "interaction" : "cut1",
        "SUID" : 1872,
        "BEND_MAP_ID" : 1872,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1870",
        "source" : "1868",
        "target" : "1869",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "9 (cut1) VIII",
        "shared_interaction" : "cut1",
        "name" : "9 (cut1) VIII",
        "interaction" : "cut1",
        "SUID" : 1870,
        "BEND_MAP_ID" : 1870,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1797",
        "source" : "1795",
        "target" : "1794",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Dale (cut1) Chip",
        "shared_interaction" : "cut1",
        "name" : "Dale (cut1) Chip",
        "interaction" : "cut1",
        "SUID" : 1797,
        "BEND_MAP_ID" : 1797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1796",
        "source" : "1794",
        "target" : "1795",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Chip (cut1) Dale",
        "shared_interaction" : "cut1",
        "name" : "Chip (cut1) Dale",
        "interaction" : "cut1",
        "SUID" : 1796,
        "BEND_MAP_ID" : 1796,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1754",
        "source" : "1731",
        "target" : "1728",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Barrel (cut5) Lock",
        "shared_interaction" : "cut5",
        "name" : "Barrel (cut5) Lock",
        "interaction" : "cut5",
        "SUID" : 1754,
        "BEND_MAP_ID" : 1754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1753",
        "source" : "1731",
        "target" : "1729",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Barrel (cut5) Shock",
        "shared_interaction" : "cut5",
        "name" : "Barrel (cut5) Shock",
        "interaction" : "cut5",
        "SUID" : 1753,
        "BEND_MAP_ID" : 1753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1752",
        "source" : "1731",
        "target" : "1728",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Barrel (cut4) Lock",
        "shared_interaction" : "cut4",
        "name" : "Barrel (cut4) Lock",
        "interaction" : "cut4",
        "SUID" : 1752,
        "BEND_MAP_ID" : 1752,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1751",
        "source" : "1731",
        "target" : "1729",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Barrel (cut4) Shock",
        "shared_interaction" : "cut4",
        "name" : "Barrel (cut4) Shock",
        "interaction" : "cut4",
        "SUID" : 1751,
        "BEND_MAP_ID" : 1751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1750",
        "source" : "1731",
        "target" : "1729",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Barrel (cut2) Shock",
        "shared_interaction" : "cut2",
        "name" : "Barrel (cut2) Shock",
        "interaction" : "cut2",
        "SUID" : 1750,
        "BEND_MAP_ID" : 1750,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1749",
        "source" : "1731",
        "target" : "1728",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Barrel (cut2) Lock",
        "shared_interaction" : "cut2",
        "name" : "Barrel (cut2) Lock",
        "interaction" : "cut2",
        "SUID" : 1749,
        "BEND_MAP_ID" : 1749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1748",
        "source" : "1731",
        "target" : "1729",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Barrel (cut1) Shock",
        "shared_interaction" : "cut1",
        "name" : "Barrel (cut1) Shock",
        "interaction" : "cut1",
        "SUID" : 1748,
        "BEND_MAP_ID" : 1748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1747",
        "source" : "1731",
        "target" : "1728",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Barrel (cut1) Lock",
        "shared_interaction" : "cut1",
        "name" : "Barrel (cut1) Lock",
        "interaction" : "cut1",
        "SUID" : 1747,
        "BEND_MAP_ID" : 1747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1746",
        "source" : "1729",
        "target" : "1728",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Shock (cut4) Lock",
        "shared_interaction" : "cut4",
        "name" : "Shock (cut4) Lock",
        "interaction" : "cut4",
        "SUID" : 1746,
        "BEND_MAP_ID" : 1746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1745",
        "source" : "1729",
        "target" : "1731",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Shock (cut4) Barrel",
        "shared_interaction" : "cut4",
        "name" : "Shock (cut4) Barrel",
        "interaction" : "cut4",
        "SUID" : 1745,
        "BEND_MAP_ID" : 1745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1744",
        "source" : "1729",
        "target" : "1731",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Shock (cut3) Barrel",
        "shared_interaction" : "cut3",
        "name" : "Shock (cut3) Barrel",
        "interaction" : "cut3",
        "SUID" : 1744,
        "BEND_MAP_ID" : 1744,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1743",
        "source" : "1729",
        "target" : "1728",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Shock (cut3) Lock",
        "shared_interaction" : "cut3",
        "name" : "Shock (cut3) Lock",
        "interaction" : "cut3",
        "SUID" : 1743,
        "BEND_MAP_ID" : 1743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1742",
        "source" : "1729",
        "target" : "1728",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Shock (cut2) Lock",
        "shared_interaction" : "cut2",
        "name" : "Shock (cut2) Lock",
        "interaction" : "cut2",
        "SUID" : 1742,
        "BEND_MAP_ID" : 1742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1741",
        "source" : "1729",
        "target" : "1731",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Shock (cut2) Barrel",
        "shared_interaction" : "cut2",
        "name" : "Shock (cut2) Barrel",
        "interaction" : "cut2",
        "SUID" : 1741,
        "BEND_MAP_ID" : 1741,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1740",
        "source" : "1729",
        "target" : "1731",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Shock (cut1) Barrel",
        "shared_interaction" : "cut1",
        "name" : "Shock (cut1) Barrel",
        "interaction" : "cut1",
        "SUID" : 1740,
        "BEND_MAP_ID" : 1740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1739",
        "source" : "1729",
        "target" : "1728",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Shock (cut1) Lock",
        "shared_interaction" : "cut1",
        "name" : "Shock (cut1) Lock",
        "interaction" : "cut1",
        "SUID" : 1739,
        "BEND_MAP_ID" : 1739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1738",
        "source" : "1728",
        "target" : "1729",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Lock (cut4) Shock",
        "shared_interaction" : "cut4",
        "name" : "Lock (cut4) Shock",
        "interaction" : "cut4",
        "SUID" : 1738,
        "BEND_MAP_ID" : 1738,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1737",
        "source" : "1728",
        "target" : "1731",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Lock (cut4) Barrel",
        "shared_interaction" : "cut4",
        "name" : "Lock (cut4) Barrel",
        "interaction" : "cut4",
        "SUID" : 1737,
        "BEND_MAP_ID" : 1737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1736",
        "source" : "1728",
        "target" : "1731",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Lock (cut3) Barrel",
        "shared_interaction" : "cut3",
        "name" : "Lock (cut3) Barrel",
        "interaction" : "cut3",
        "SUID" : 1736,
        "BEND_MAP_ID" : 1736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1735",
        "source" : "1728",
        "target" : "1729",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Lock (cut3) Shock",
        "shared_interaction" : "cut3",
        "name" : "Lock (cut3) Shock",
        "interaction" : "cut3",
        "SUID" : 1735,
        "BEND_MAP_ID" : 1735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1734",
        "source" : "1728",
        "target" : "1729",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Lock (cut2) Shock",
        "shared_interaction" : "cut2",
        "name" : "Lock (cut2) Shock",
        "interaction" : "cut2",
        "SUID" : 1734,
        "BEND_MAP_ID" : 1734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1733",
        "source" : "1728",
        "target" : "1731",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Lock (cut2) Barrel",
        "shared_interaction" : "cut2",
        "name" : "Lock (cut2) Barrel",
        "interaction" : "cut2",
        "SUID" : 1733,
        "BEND_MAP_ID" : 1733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1732",
        "source" : "1728",
        "target" : "1731",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Lock (cut1) Barrel",
        "shared_interaction" : "cut1",
        "name" : "Lock (cut1) Barrel",
        "interaction" : "cut1",
        "SUID" : 1732,
        "BEND_MAP_ID" : 1732,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1730",
        "source" : "1728",
        "target" : "1729",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Lock (cut1) Shock",
        "shared_interaction" : "cut1",
        "name" : "Lock (cut1) Shock",
        "interaction" : "cut1",
        "SUID" : 1730,
        "BEND_MAP_ID" : 1730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1755",
        "source" : "1713",
        "target" : "474",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Oogie Boogie (cut4) Jack",
        "shared_interaction" : "cut4",
        "name" : "Oogie Boogie (cut4) Jack",
        "interaction" : "cut4",
        "SUID" : 1755,
        "BEND_MAP_ID" : 1755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1727",
        "source" : "1710",
        "target" : "474",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Sally (cut4) Jack",
        "shared_interaction" : "cut4",
        "name" : "Sally (cut4) Jack",
        "interaction" : "cut4",
        "SUID" : 1727,
        "BEND_MAP_ID" : 1727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1726",
        "source" : "1710",
        "target" : "474",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Sally (cut2) Jack",
        "shared_interaction" : "cut2",
        "name" : "Sally (cut2) Jack",
        "interaction" : "cut2",
        "SUID" : 1726,
        "BEND_MAP_ID" : 1726,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1725",
        "source" : "1710",
        "target" : "474",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Sally (cut1) Jack",
        "shared_interaction" : "cut1",
        "name" : "Sally (cut1) Jack",
        "interaction" : "cut1",
        "SUID" : 1725,
        "BEND_MAP_ID" : 1725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1701",
        "source" : "1700",
        "target" : "474",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Mayor (cut4) Jack",
        "shared_interaction" : "cut4",
        "name" : "Mayor (cut4) Jack",
        "interaction" : "cut4",
        "SUID" : 1701,
        "BEND_MAP_ID" : 1701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1694",
        "source" : "1683",
        "target" : "1642",
        "EdgeBetweenness" : 82.0,
        "shared_name" : "Flotsam & Jetsam (cut1) Jetsam",
        "shared_interaction" : "cut1",
        "name" : "Flotsam & Jetsam (cut1) Jetsam",
        "interaction" : "cut1",
        "SUID" : 1694,
        "BEND_MAP_ID" : 1694,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1693",
        "source" : "1683",
        "target" : "1644",
        "EdgeBetweenness" : 82.0,
        "shared_name" : "Flotsam & Jetsam (cut1) Flotsam",
        "shared_interaction" : "cut1",
        "name" : "Flotsam & Jetsam (cut1) Flotsam",
        "interaction" : "cut1",
        "SUID" : 1693,
        "BEND_MAP_ID" : 1693,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1679",
        "source" : "1646",
        "target" : "447",
        "EdgeBetweenness" : 158.0,
        "shared_name" : "Ursula (cut18) Ariel",
        "shared_interaction" : "cut18",
        "name" : "Ursula (cut18) Ariel",
        "interaction" : "cut18",
        "SUID" : 1679,
        "BEND_MAP_ID" : 1679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1678",
        "source" : "1646",
        "target" : "1642",
        "EdgeBetweenness" : 3.0,
        "shared_name" : "Ursula (cut13) Jetsam",
        "shared_interaction" : "cut13",
        "name" : "Ursula (cut13) Jetsam",
        "interaction" : "cut13",
        "SUID" : 1678,
        "BEND_MAP_ID" : 1678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1677",
        "source" : "1646",
        "target" : "1644",
        "EdgeBetweenness" : 3.0,
        "shared_name" : "Ursula (cut13) Flotsam",
        "shared_interaction" : "cut13",
        "name" : "Ursula (cut13) Flotsam",
        "interaction" : "cut13",
        "SUID" : 1677,
        "BEND_MAP_ID" : 1677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1676",
        "source" : "1646",
        "target" : "447",
        "EdgeBetweenness" : 158.0,
        "shared_name" : "Ursula (cut12) Ariel",
        "shared_interaction" : "cut12",
        "name" : "Ursula (cut12) Ariel",
        "interaction" : "cut12",
        "SUID" : 1676,
        "BEND_MAP_ID" : 1676,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1675",
        "source" : "1646",
        "target" : "447",
        "EdgeBetweenness" : 158.0,
        "shared_name" : "Ursula (cut5) Ariel",
        "shared_interaction" : "cut5",
        "name" : "Ursula (cut5) Ariel",
        "interaction" : "cut5",
        "SUID" : 1675,
        "BEND_MAP_ID" : 1675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1686",
        "source" : "1644",
        "target" : "1642",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Flotsam (cut4) Jetsam",
        "shared_interaction" : "cut4",
        "name" : "Flotsam (cut4) Jetsam",
        "interaction" : "cut4",
        "SUID" : 1686,
        "BEND_MAP_ID" : 1686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1685",
        "source" : "1644",
        "target" : "1646",
        "EdgeBetweenness" : 3.0,
        "shared_name" : "Flotsam (cut4) Ursula",
        "shared_interaction" : "cut4",
        "name" : "Flotsam (cut4) Ursula",
        "interaction" : "cut4",
        "SUID" : 1685,
        "BEND_MAP_ID" : 1685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1684",
        "source" : "1644",
        "target" : "1683",
        "EdgeBetweenness" : 82.0,
        "shared_name" : "Flotsam (cut3) Flotsam & Jetsam",
        "shared_interaction" : "cut3",
        "name" : "Flotsam (cut3) Flotsam & Jetsam",
        "interaction" : "cut3",
        "SUID" : 1684,
        "BEND_MAP_ID" : 1684,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1682",
        "source" : "1644",
        "target" : "1642",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Flotsam (cut3) Jetsam",
        "shared_interaction" : "cut3",
        "name" : "Flotsam (cut3) Jetsam",
        "interaction" : "cut3",
        "SUID" : 1682,
        "BEND_MAP_ID" : 1682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1681",
        "source" : "1644",
        "target" : "447",
        "EdgeBetweenness" : 237.0,
        "shared_name" : "Flotsam (cut2) Ariel",
        "shared_interaction" : "cut2",
        "name" : "Flotsam (cut2) Ariel",
        "interaction" : "cut2",
        "SUID" : 1681,
        "BEND_MAP_ID" : 1681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1680",
        "source" : "1644",
        "target" : "1642",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Flotsam (cut2) Jetsam",
        "shared_interaction" : "cut2",
        "name" : "Flotsam (cut2) Jetsam",
        "interaction" : "cut2",
        "SUID" : 1680,
        "BEND_MAP_ID" : 1680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1692",
        "source" : "1642",
        "target" : "1644",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Jetsam (cut3) Flotsam",
        "shared_interaction" : "cut3",
        "name" : "Jetsam (cut3) Flotsam",
        "interaction" : "cut3",
        "SUID" : 1692,
        "BEND_MAP_ID" : 1692,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1691",
        "source" : "1642",
        "target" : "1646",
        "EdgeBetweenness" : 3.0,
        "shared_name" : "Jetsam (cut3) Ursula",
        "shared_interaction" : "cut3",
        "name" : "Jetsam (cut3) Ursula",
        "interaction" : "cut3",
        "SUID" : 1691,
        "BEND_MAP_ID" : 1691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1690",
        "source" : "1642",
        "target" : "1683",
        "EdgeBetweenness" : 82.0,
        "shared_name" : "Jetsam (cut2) Flotsam & Jetsam",
        "shared_interaction" : "cut2",
        "name" : "Jetsam (cut2) Flotsam & Jetsam",
        "interaction" : "cut2",
        "SUID" : 1690,
        "BEND_MAP_ID" : 1690,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1689",
        "source" : "1642",
        "target" : "1644",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Jetsam (cut2) Flotsam",
        "shared_interaction" : "cut2",
        "name" : "Jetsam (cut2) Flotsam",
        "interaction" : "cut2",
        "SUID" : 1689,
        "BEND_MAP_ID" : 1689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1688",
        "source" : "1642",
        "target" : "447",
        "EdgeBetweenness" : 237.0,
        "shared_name" : "Jetsam (cut1) Ariel",
        "shared_interaction" : "cut1",
        "name" : "Jetsam (cut1) Ariel",
        "interaction" : "cut1",
        "SUID" : 1688,
        "BEND_MAP_ID" : 1688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1687",
        "source" : "1642",
        "target" : "1644",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Jetsam (cut1) Flotsam",
        "shared_interaction" : "cut1",
        "name" : "Jetsam (cut1) Flotsam",
        "interaction" : "cut1",
        "SUID" : 1687,
        "BEND_MAP_ID" : 1687,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1659",
        "source" : "1631",
        "target" : "447",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Sebstian (cut1) Ariel",
        "shared_interaction" : "cut1",
        "name" : "Sebstian (cut1) Ariel",
        "interaction" : "cut1",
        "SUID" : 1659,
        "BEND_MAP_ID" : 1659,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1658",
        "source" : "1617",
        "target" : "136",
        "EdgeBetweenness" : 90.84545454545453,
        "shared_name" : "Flounder (cut2) Sebastian",
        "shared_interaction" : "cut2",
        "name" : "Flounder (cut2) Sebastian",
        "interaction" : "cut2",
        "SUID" : 1658,
        "BEND_MAP_ID" : 1658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1657",
        "source" : "1617",
        "target" : "447",
        "EdgeBetweenness" : 73.15454545454547,
        "shared_name" : "Flounder (cut2) Ariel",
        "shared_interaction" : "cut2",
        "name" : "Flounder (cut2) Ariel",
        "interaction" : "cut2",
        "SUID" : 1657,
        "BEND_MAP_ID" : 1657,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1487",
        "source" : "1450",
        "target" : "123",
        "EdgeBetweenness" : 71.07813852813854,
        "shared_name" : "Iago (cut5) Jafar",
        "shared_interaction" : "cut5",
        "name" : "Iago (cut5) Jafar",
        "interaction" : "cut5",
        "SUID" : 1487,
        "BEND_MAP_ID" : 1487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1486",
        "source" : "1450",
        "target" : "123",
        "EdgeBetweenness" : 71.07813852813854,
        "shared_name" : "Iago (cut2) Jafar",
        "shared_interaction" : "cut2",
        "name" : "Iago (cut2) Jafar",
        "interaction" : "cut2",
        "SUID" : 1486,
        "BEND_MAP_ID" : 1486,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1485",
        "source" : "1450",
        "target" : "395",
        "EdgeBetweenness" : 69.79242424242425,
        "shared_name" : "Iago (cut2) Aladdin",
        "shared_interaction" : "cut2",
        "name" : "Iago (cut2) Aladdin",
        "interaction" : "cut2",
        "SUID" : 1485,
        "BEND_MAP_ID" : 1485,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1484",
        "source" : "1450",
        "target" : "98",
        "EdgeBetweenness" : 25.129437229437226,
        "shared_name" : "Iago (cut1) Maleficent",
        "shared_interaction" : "cut1",
        "name" : "Iago (cut1) Maleficent",
        "interaction" : "cut1",
        "SUID" : 1484,
        "BEND_MAP_ID" : 1484,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1483",
        "source" : "1450",
        "target" : "123",
        "EdgeBetweenness" : 71.07813852813854,
        "shared_name" : "Iago (cut1) Jafar",
        "shared_interaction" : "cut1",
        "name" : "Iago (cut1) Jafar",
        "interaction" : "cut1",
        "SUID" : 1483,
        "BEND_MAP_ID" : 1483,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1603",
        "source" : "1421",
        "target" : "466",
        "EdgeBetweenness" : 49.065367965368054,
        "shared_name" : "Rabbit (cut14) Owl",
        "shared_interaction" : "cut14",
        "name" : "Rabbit (cut14) Owl",
        "interaction" : "cut14",
        "SUID" : 1603,
        "BEND_MAP_ID" : 1603,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1602",
        "source" : "1421",
        "target" : "94",
        "EdgeBetweenness" : 64.40865800865811,
        "shared_name" : "Rabbit (cut9) Pooh",
        "shared_interaction" : "cut9",
        "name" : "Rabbit (cut9) Pooh",
        "interaction" : "cut9",
        "SUID" : 1602,
        "BEND_MAP_ID" : 1602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1601",
        "source" : "1421",
        "target" : "412",
        "EdgeBetweenness" : 51.32597402597413,
        "shared_name" : "Rabbit (cut8) Piglet",
        "shared_interaction" : "cut8",
        "name" : "Rabbit (cut8) Piglet",
        "interaction" : "cut8",
        "SUID" : 1601,
        "BEND_MAP_ID" : 1601,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1600",
        "source" : "1421",
        "target" : "94",
        "EdgeBetweenness" : 64.40865800865811,
        "shared_name" : "Rabbit (cut8) Pooh",
        "shared_interaction" : "cut8",
        "name" : "Rabbit (cut8) Pooh",
        "interaction" : "cut8",
        "SUID" : 1600,
        "BEND_MAP_ID" : 1600,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1599",
        "source" : "1421",
        "target" : "94",
        "EdgeBetweenness" : 64.40865800865811,
        "shared_name" : "Rabbit (cut3) Pooh",
        "shared_interaction" : "cut3",
        "name" : "Rabbit (cut3) Pooh",
        "interaction" : "cut3",
        "SUID" : 1599,
        "BEND_MAP_ID" : 1599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1598",
        "source" : "1421",
        "target" : "94",
        "EdgeBetweenness" : 64.40865800865811,
        "shared_name" : "Rabbit (cut1) Pooh",
        "shared_interaction" : "cut1",
        "name" : "Rabbit (cut1) Pooh",
        "interaction" : "cut1",
        "SUID" : 1598,
        "BEND_MAP_ID" : 1598,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1862",
        "source" : "1339",
        "target" : "302",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Sephiroth (cut1) Cloud",
        "shared_interaction" : "cut1",
        "name" : "Sephiroth (cut1) Cloud",
        "interaction" : "cut1",
        "SUID" : 1862,
        "BEND_MAP_ID" : 1862,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1253",
        "source" : "1252",
        "target" : "265",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "White Rabbit (cut4) Alice",
        "shared_interaction" : "cut4",
        "name" : "White Rabbit (cut4) Alice",
        "interaction" : "cut4",
        "SUID" : 1253,
        "BEND_MAP_ID" : 1253,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1863",
        "source" : "1042",
        "target" : "106",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Sora & Donald (cut1) Goofy",
        "shared_interaction" : "cut1",
        "name" : "Sora & Donald (cut1) Goofy",
        "interaction" : "cut1",
        "SUID" : 1863,
        "BEND_MAP_ID" : 1863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1784",
        "source" : "844",
        "target" : "114",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Sora & Goofy (cut1) Donald",
        "shared_interaction" : "cut1",
        "name" : "Sora & Goofy (cut1) Donald",
        "interaction" : "cut1",
        "SUID" : 1784,
        "BEND_MAP_ID" : 1784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1059",
        "source" : "706",
        "target" : "114",
        "EdgeBetweenness" : 71.44242424242425,
        "shared_name" : "Minnie (cut1) Donald",
        "shared_interaction" : "cut1",
        "name" : "Minnie (cut1) Donald",
        "interaction" : "cut1",
        "SUID" : 1059,
        "BEND_MAP_ID" : 1059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1058",
        "source" : "706",
        "target" : "106",
        "EdgeBetweenness" : 90.55757575757576,
        "shared_name" : "Minnie (cut1) Goofy",
        "shared_interaction" : "cut1",
        "name" : "Minnie (cut1) Goofy",
        "interaction" : "cut1",
        "SUID" : 1058,
        "BEND_MAP_ID" : 1058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1057",
        "source" : "706",
        "target" : "704",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Minnie (cut1) Daisy",
        "shared_interaction" : "cut1",
        "name" : "Minnie (cut1) Daisy",
        "interaction" : "cut1",
        "SUID" : 1057,
        "BEND_MAP_ID" : 1057,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1056",
        "source" : "704",
        "target" : "114",
        "EdgeBetweenness" : 71.44242424242425,
        "shared_name" : "Daisy (cut1) Donald",
        "shared_interaction" : "cut1",
        "name" : "Daisy (cut1) Donald",
        "interaction" : "cut1",
        "SUID" : 1056,
        "BEND_MAP_ID" : 1056,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1055",
        "source" : "704",
        "target" : "106",
        "EdgeBetweenness" : 90.55757575757576,
        "shared_name" : "Daisy (cut1) Goofy",
        "shared_interaction" : "cut1",
        "name" : "Daisy (cut1) Goofy",
        "interaction" : "cut1",
        "SUID" : 1055,
        "BEND_MAP_ID" : 1055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1054",
        "source" : "704",
        "target" : "706",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Daisy (cut1) Minnie",
        "shared_interaction" : "cut1",
        "name" : "Daisy (cut1) Minnie",
        "interaction" : "cut1",
        "SUID" : 1054,
        "BEND_MAP_ID" : 1054,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1766",
        "source" : "666",
        "target" : "102",
        "EdgeBetweenness" : 8.333333333333334,
        "shared_name" : "Smee (cut3) Hook",
        "shared_interaction" : "cut3",
        "name" : "Smee (cut3) Hook",
        "interaction" : "cut3",
        "SUID" : 1766,
        "BEND_MAP_ID" : 1766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1765",
        "source" : "666",
        "target" : "104",
        "EdgeBetweenness" : 4.633333333333333,
        "shared_name" : "Smee (cut3) Captain Hook",
        "shared_interaction" : "cut3",
        "name" : "Smee (cut3) Captain Hook",
        "interaction" : "cut3",
        "SUID" : 1765,
        "BEND_MAP_ID" : 1765,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1764",
        "source" : "666",
        "target" : "104",
        "EdgeBetweenness" : 4.633333333333333,
        "shared_name" : "Smee (cut2) Captain Hook",
        "shared_interaction" : "cut2",
        "name" : "Smee (cut2) Captain Hook",
        "interaction" : "cut2",
        "SUID" : 1764,
        "BEND_MAP_ID" : 1764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1763",
        "source" : "666",
        "target" : "96",
        "EdgeBetweenness" : 158.43333333333334,
        "shared_name" : "Smee (cut2) Riku",
        "shared_interaction" : "cut2",
        "name" : "Smee (cut2) Riku",
        "interaction" : "cut2",
        "SUID" : 1763,
        "BEND_MAP_ID" : 1763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1762",
        "source" : "666",
        "target" : "102",
        "EdgeBetweenness" : 8.333333333333334,
        "shared_name" : "Smee (cut1) Hook",
        "shared_interaction" : "cut1",
        "name" : "Smee (cut1) Hook",
        "interaction" : "cut1",
        "SUID" : 1762,
        "BEND_MAP_ID" : 1762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1867",
        "source" : "603",
        "target" : "96",
        "EdgeBetweenness" : 14.947252747252747,
        "shared_name" : "Mickey (cut1) Riku",
        "shared_interaction" : "cut1",
        "name" : "Mickey (cut1) Riku",
        "interaction" : "cut1",
        "SUID" : 1867,
        "BEND_MAP_ID" : 1867,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1866",
        "source" : "603",
        "target" : "106",
        "EdgeBetweenness" : 37.232967032967046,
        "shared_name" : "Mickey (cut1) Goofy",
        "shared_interaction" : "cut1",
        "name" : "Mickey (cut1) Goofy",
        "interaction" : "cut1",
        "SUID" : 1866,
        "BEND_MAP_ID" : 1866,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1865",
        "source" : "603",
        "target" : "84",
        "EdgeBetweenness" : 84.7201465201465,
        "shared_name" : "Mickey (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Mickey (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1865,
        "BEND_MAP_ID" : 1865,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1864",
        "source" : "603",
        "target" : "114",
        "EdgeBetweenness" : 27.099633699633696,
        "shared_name" : "Mickey (cut1) Donald",
        "shared_interaction" : "cut1",
        "name" : "Mickey (cut1) Donald",
        "interaction" : "cut1",
        "SUID" : 1864,
        "BEND_MAP_ID" : 1864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1788",
        "source" : "598",
        "target" : "84",
        "EdgeBetweenness" : 108.25396825396825,
        "shared_name" : "Ansem (cut35) Sora",
        "shared_interaction" : "cut35",
        "name" : "Ansem (cut35) Sora",
        "interaction" : "cut35",
        "SUID" : 1788,
        "BEND_MAP_ID" : 1788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1787",
        "source" : "598",
        "target" : "84",
        "EdgeBetweenness" : 108.25396825396825,
        "shared_name" : "Ansem (cut16) Sora",
        "shared_interaction" : "cut16",
        "name" : "Ansem (cut16) Sora",
        "interaction" : "cut16",
        "SUID" : 1787,
        "BEND_MAP_ID" : 1787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1786",
        "source" : "598",
        "target" : "84",
        "EdgeBetweenness" : 108.25396825396825,
        "shared_name" : "Ansem (cut14) Sora",
        "shared_interaction" : "cut14",
        "name" : "Ansem (cut14) Sora",
        "interaction" : "cut14",
        "SUID" : 1786,
        "BEND_MAP_ID" : 1786,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1785",
        "source" : "598",
        "target" : "106",
        "EdgeBetweenness" : 55.74603174603175,
        "shared_name" : "Ansem (cut8) Goofy",
        "shared_interaction" : "cut8",
        "name" : "Ansem (cut8) Goofy",
        "interaction" : "cut8",
        "SUID" : 1785,
        "BEND_MAP_ID" : 1785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1699",
        "source" : "591",
        "target" : "84",
        "EdgeBetweenness" : 148.30952380952385,
        "shared_name" : "Eeyore (cut7) Sora",
        "shared_interaction" : "cut7",
        "name" : "Eeyore (cut7) Sora",
        "interaction" : "cut7",
        "SUID" : 1699,
        "BEND_MAP_ID" : 1699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1698",
        "source" : "591",
        "target" : "94",
        "EdgeBetweenness" : 7.404761904761904,
        "shared_name" : "Eeyore (cut6) Pooh",
        "shared_interaction" : "cut6",
        "name" : "Eeyore (cut6) Pooh",
        "interaction" : "cut6",
        "SUID" : 1698,
        "BEND_MAP_ID" : 1698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1697",
        "source" : "591",
        "target" : "466",
        "EdgeBetweenness" : 4.566666666666666,
        "shared_name" : "Eeyore (cut4) Owl",
        "shared_interaction" : "cut4",
        "name" : "Eeyore (cut4) Owl",
        "interaction" : "cut4",
        "SUID" : 1697,
        "BEND_MAP_ID" : 1697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1696",
        "source" : "591",
        "target" : "94",
        "EdgeBetweenness" : 7.404761904761904,
        "shared_name" : "Eeyore (cut4) Pooh",
        "shared_interaction" : "cut4",
        "name" : "Eeyore (cut4) Pooh",
        "interaction" : "cut4",
        "SUID" : 1696,
        "BEND_MAP_ID" : 1696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1695",
        "source" : "591",
        "target" : "412",
        "EdgeBetweenness" : 4.519047619047619,
        "shared_name" : "Eeyore (cut3) Piglet",
        "shared_interaction" : "cut3",
        "name" : "Eeyore (cut3) Piglet",
        "interaction" : "cut3",
        "SUID" : 1695,
        "BEND_MAP_ID" : 1695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1861",
        "source" : "581",
        "target" : "120",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Snow Whtie (cut1) Jasmine",
        "shared_interaction" : "cut1",
        "name" : "Snow Whtie (cut1) Jasmine",
        "interaction" : "cut1",
        "SUID" : 1861,
        "BEND_MAP_ID" : 1861,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1860",
        "source" : "581",
        "target" : "265",
        "EdgeBetweenness" : 10.933333333333334,
        "shared_name" : "Snow Whtie (cut1) Alice",
        "shared_interaction" : "cut1",
        "name" : "Snow Whtie (cut1) Alice",
        "interaction" : "cut1",
        "SUID" : 1860,
        "BEND_MAP_ID" : 1860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1859",
        "source" : "581",
        "target" : "556",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Snow Whtie (cut1) Cinderella",
        "shared_interaction" : "cut1",
        "name" : "Snow Whtie (cut1) Cinderella",
        "interaction" : "cut1",
        "SUID" : 1859,
        "BEND_MAP_ID" : 1859,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1858",
        "source" : "581",
        "target" : "84",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Snow Whtie (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Snow Whtie (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1858,
        "BEND_MAP_ID" : 1858,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1857",
        "source" : "581",
        "target" : "558",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Snow Whtie (cut1) Aurora",
        "shared_interaction" : "cut1",
        "name" : "Snow Whtie (cut1) Aurora",
        "interaction" : "cut1",
        "SUID" : 1857,
        "BEND_MAP_ID" : 1857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1856",
        "source" : "581",
        "target" : "562",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Snow Whtie (cut1) Snow White",
        "shared_interaction" : "cut1",
        "name" : "Snow Whtie (cut1) Snow White",
        "interaction" : "cut1",
        "SUID" : 1856,
        "BEND_MAP_ID" : 1856,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1855",
        "source" : "562",
        "target" : "120",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Snow White (cut3) Jasmine",
        "shared_interaction" : "cut3",
        "name" : "Snow White (cut3) Jasmine",
        "interaction" : "cut3",
        "SUID" : 1855,
        "BEND_MAP_ID" : 1855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1854",
        "source" : "562",
        "target" : "558",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Snow White (cut3) Aurora",
        "shared_interaction" : "cut3",
        "name" : "Snow White (cut3) Aurora",
        "interaction" : "cut3",
        "SUID" : 1854,
        "BEND_MAP_ID" : 1854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1853",
        "source" : "562",
        "target" : "265",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Snow White (cut3) Alice",
        "shared_interaction" : "cut3",
        "name" : "Snow White (cut3) Alice",
        "interaction" : "cut3",
        "SUID" : 1853,
        "BEND_MAP_ID" : 1853,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1852",
        "source" : "562",
        "target" : "556",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Snow White (cut3) Cinderella",
        "shared_interaction" : "cut3",
        "name" : "Snow White (cut3) Cinderella",
        "interaction" : "cut3",
        "SUID" : 1852,
        "BEND_MAP_ID" : 1852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1851",
        "source" : "562",
        "target" : "120",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Snow White (cut2) Jasmine",
        "shared_interaction" : "cut2",
        "name" : "Snow White (cut2) Jasmine",
        "interaction" : "cut2",
        "SUID" : 1851,
        "BEND_MAP_ID" : 1851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1850",
        "source" : "562",
        "target" : "581",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Snow White (cut2) Snow Whtie",
        "shared_interaction" : "cut2",
        "name" : "Snow White (cut2) Snow Whtie",
        "interaction" : "cut2",
        "SUID" : 1850,
        "BEND_MAP_ID" : 1850,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1849",
        "source" : "562",
        "target" : "265",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Snow White (cut2) Alice",
        "shared_interaction" : "cut2",
        "name" : "Snow White (cut2) Alice",
        "interaction" : "cut2",
        "SUID" : 1849,
        "BEND_MAP_ID" : 1849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1848",
        "source" : "562",
        "target" : "556",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Snow White (cut2) Cinderella",
        "shared_interaction" : "cut2",
        "name" : "Snow White (cut2) Cinderella",
        "interaction" : "cut2",
        "SUID" : 1848,
        "BEND_MAP_ID" : 1848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1847",
        "source" : "562",
        "target" : "84",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Snow White (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Snow White (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1847,
        "BEND_MAP_ID" : 1847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1846",
        "source" : "562",
        "target" : "558",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Snow White (cut2) Aurora",
        "shared_interaction" : "cut2",
        "name" : "Snow White (cut2) Aurora",
        "interaction" : "cut2",
        "SUID" : 1846,
        "BEND_MAP_ID" : 1846,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1845",
        "source" : "562",
        "target" : "556",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Snow White (cut1) Cinderella",
        "shared_interaction" : "cut1",
        "name" : "Snow White (cut1) Cinderella",
        "interaction" : "cut1",
        "SUID" : 1845,
        "BEND_MAP_ID" : 1845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1844",
        "source" : "562",
        "target" : "558",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Snow White (cut1) Aurora",
        "shared_interaction" : "cut1",
        "name" : "Snow White (cut1) Aurora",
        "interaction" : "cut1",
        "SUID" : 1844,
        "BEND_MAP_ID" : 1844,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1843",
        "source" : "562",
        "target" : "84",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Snow White (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Snow White (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1843,
        "BEND_MAP_ID" : 1843,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1842",
        "source" : "562",
        "target" : "265",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Snow White (cut1) Alice",
        "shared_interaction" : "cut1",
        "name" : "Snow White (cut1) Alice",
        "interaction" : "cut1",
        "SUID" : 1842,
        "BEND_MAP_ID" : 1842,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1841",
        "source" : "562",
        "target" : "120",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Snow White (cut1) Jasmine",
        "shared_interaction" : "cut1",
        "name" : "Snow White (cut1) Jasmine",
        "interaction" : "cut1",
        "SUID" : 1841,
        "BEND_MAP_ID" : 1841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1840",
        "source" : "558",
        "target" : "120",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Aurora (cut5) Jasmine",
        "shared_interaction" : "cut5",
        "name" : "Aurora (cut5) Jasmine",
        "interaction" : "cut5",
        "SUID" : 1840,
        "BEND_MAP_ID" : 1840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1839",
        "source" : "558",
        "target" : "265",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Aurora (cut5) Alice",
        "shared_interaction" : "cut5",
        "name" : "Aurora (cut5) Alice",
        "interaction" : "cut5",
        "SUID" : 1839,
        "BEND_MAP_ID" : 1839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1838",
        "source" : "558",
        "target" : "562",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Aurora (cut5) Snow White",
        "shared_interaction" : "cut5",
        "name" : "Aurora (cut5) Snow White",
        "interaction" : "cut5",
        "SUID" : 1838,
        "BEND_MAP_ID" : 1838,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1837",
        "source" : "558",
        "target" : "556",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Aurora (cut5) Cinderella",
        "shared_interaction" : "cut5",
        "name" : "Aurora (cut5) Cinderella",
        "interaction" : "cut5",
        "SUID" : 1837,
        "BEND_MAP_ID" : 1837,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1836",
        "source" : "558",
        "target" : "120",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Aurora (cut4) Jasmine",
        "shared_interaction" : "cut4",
        "name" : "Aurora (cut4) Jasmine",
        "interaction" : "cut4",
        "SUID" : 1836,
        "BEND_MAP_ID" : 1836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1835",
        "source" : "558",
        "target" : "581",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Aurora (cut4) Snow Whtie",
        "shared_interaction" : "cut4",
        "name" : "Aurora (cut4) Snow Whtie",
        "interaction" : "cut4",
        "SUID" : 1835,
        "BEND_MAP_ID" : 1835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1834",
        "source" : "558",
        "target" : "265",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Aurora (cut4) Alice",
        "shared_interaction" : "cut4",
        "name" : "Aurora (cut4) Alice",
        "interaction" : "cut4",
        "SUID" : 1834,
        "BEND_MAP_ID" : 1834,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1833",
        "source" : "558",
        "target" : "556",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Aurora (cut4) Cinderella",
        "shared_interaction" : "cut4",
        "name" : "Aurora (cut4) Cinderella",
        "interaction" : "cut4",
        "SUID" : 1833,
        "BEND_MAP_ID" : 1833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1832",
        "source" : "558",
        "target" : "84",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Aurora (cut4) Sora",
        "shared_interaction" : "cut4",
        "name" : "Aurora (cut4) Sora",
        "interaction" : "cut4",
        "SUID" : 1832,
        "BEND_MAP_ID" : 1832,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1831",
        "source" : "558",
        "target" : "562",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Aurora (cut4) Snow White",
        "shared_interaction" : "cut4",
        "name" : "Aurora (cut4) Snow White",
        "interaction" : "cut4",
        "SUID" : 1831,
        "BEND_MAP_ID" : 1831,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1830",
        "source" : "558",
        "target" : "556",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Aurora (cut3) Cinderella",
        "shared_interaction" : "cut3",
        "name" : "Aurora (cut3) Cinderella",
        "interaction" : "cut3",
        "SUID" : 1830,
        "BEND_MAP_ID" : 1830,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1829",
        "source" : "558",
        "target" : "84",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Aurora (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Aurora (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1829,
        "BEND_MAP_ID" : 1829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1828",
        "source" : "558",
        "target" : "120",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Aurora (cut3) Jasmine",
        "shared_interaction" : "cut3",
        "name" : "Aurora (cut3) Jasmine",
        "interaction" : "cut3",
        "SUID" : 1828,
        "BEND_MAP_ID" : 1828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1827",
        "source" : "558",
        "target" : "265",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Aurora (cut3) Alice",
        "shared_interaction" : "cut3",
        "name" : "Aurora (cut3) Alice",
        "interaction" : "cut3",
        "SUID" : 1827,
        "BEND_MAP_ID" : 1827,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1826",
        "source" : "558",
        "target" : "556",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Aurora (cut2) Cinderella",
        "shared_interaction" : "cut2",
        "name" : "Aurora (cut2) Cinderella",
        "interaction" : "cut2",
        "SUID" : 1826,
        "BEND_MAP_ID" : 1826,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1825",
        "source" : "558",
        "target" : "84",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Aurora (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Aurora (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1825,
        "BEND_MAP_ID" : 1825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1824",
        "source" : "558",
        "target" : "562",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Aurora (cut2) Snow White",
        "shared_interaction" : "cut2",
        "name" : "Aurora (cut2) Snow White",
        "interaction" : "cut2",
        "SUID" : 1824,
        "BEND_MAP_ID" : 1824,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1823",
        "source" : "558",
        "target" : "265",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Aurora (cut2) Alice",
        "shared_interaction" : "cut2",
        "name" : "Aurora (cut2) Alice",
        "interaction" : "cut2",
        "SUID" : 1823,
        "BEND_MAP_ID" : 1823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1822",
        "source" : "558",
        "target" : "120",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Aurora (cut2) Jasmine",
        "shared_interaction" : "cut2",
        "name" : "Aurora (cut2) Jasmine",
        "interaction" : "cut2",
        "SUID" : 1822,
        "BEND_MAP_ID" : 1822,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1821",
        "source" : "558",
        "target" : "84",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Aurora (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Aurora (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1821,
        "BEND_MAP_ID" : 1821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1820",
        "source" : "558",
        "target" : "556",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Aurora (cut1) Cinderella",
        "shared_interaction" : "cut1",
        "name" : "Aurora (cut1) Cinderella",
        "interaction" : "cut1",
        "SUID" : 1820,
        "BEND_MAP_ID" : 1820,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1819",
        "source" : "556",
        "target" : "120",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Cinderella (cut5) Jasmine",
        "shared_interaction" : "cut5",
        "name" : "Cinderella (cut5) Jasmine",
        "interaction" : "cut5",
        "SUID" : 1819,
        "BEND_MAP_ID" : 1819,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1818",
        "source" : "556",
        "target" : "558",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Cinderella (cut5) Aurora",
        "shared_interaction" : "cut5",
        "name" : "Cinderella (cut5) Aurora",
        "interaction" : "cut5",
        "SUID" : 1818,
        "BEND_MAP_ID" : 1818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1817",
        "source" : "556",
        "target" : "265",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Cinderella (cut5) Alice",
        "shared_interaction" : "cut5",
        "name" : "Cinderella (cut5) Alice",
        "interaction" : "cut5",
        "SUID" : 1817,
        "BEND_MAP_ID" : 1817,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1816",
        "source" : "556",
        "target" : "562",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Cinderella (cut5) Snow White",
        "shared_interaction" : "cut5",
        "name" : "Cinderella (cut5) Snow White",
        "interaction" : "cut5",
        "SUID" : 1816,
        "BEND_MAP_ID" : 1816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1815",
        "source" : "556",
        "target" : "120",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Cinderella (cut4) Jasmine",
        "shared_interaction" : "cut4",
        "name" : "Cinderella (cut4) Jasmine",
        "interaction" : "cut4",
        "SUID" : 1815,
        "BEND_MAP_ID" : 1815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1814",
        "source" : "556",
        "target" : "581",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Cinderella (cut4) Snow Whtie",
        "shared_interaction" : "cut4",
        "name" : "Cinderella (cut4) Snow Whtie",
        "interaction" : "cut4",
        "SUID" : 1814,
        "BEND_MAP_ID" : 1814,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1813",
        "source" : "556",
        "target" : "265",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Cinderella (cut4) Alice",
        "shared_interaction" : "cut4",
        "name" : "Cinderella (cut4) Alice",
        "interaction" : "cut4",
        "SUID" : 1813,
        "BEND_MAP_ID" : 1813,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1812",
        "source" : "556",
        "target" : "84",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Cinderella (cut4) Sora",
        "shared_interaction" : "cut4",
        "name" : "Cinderella (cut4) Sora",
        "interaction" : "cut4",
        "SUID" : 1812,
        "BEND_MAP_ID" : 1812,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1811",
        "source" : "556",
        "target" : "558",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Cinderella (cut4) Aurora",
        "shared_interaction" : "cut4",
        "name" : "Cinderella (cut4) Aurora",
        "interaction" : "cut4",
        "SUID" : 1811,
        "BEND_MAP_ID" : 1811,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1810",
        "source" : "556",
        "target" : "562",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Cinderella (cut4) Snow White",
        "shared_interaction" : "cut4",
        "name" : "Cinderella (cut4) Snow White",
        "interaction" : "cut4",
        "SUID" : 1810,
        "BEND_MAP_ID" : 1810,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1809",
        "source" : "556",
        "target" : "84",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Cinderella (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Cinderella (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1809,
        "BEND_MAP_ID" : 1809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1808",
        "source" : "556",
        "target" : "558",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Cinderella (cut3) Aurora",
        "shared_interaction" : "cut3",
        "name" : "Cinderella (cut3) Aurora",
        "interaction" : "cut3",
        "SUID" : 1808,
        "BEND_MAP_ID" : 1808,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1807",
        "source" : "556",
        "target" : "120",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Cinderella (cut3) Jasmine",
        "shared_interaction" : "cut3",
        "name" : "Cinderella (cut3) Jasmine",
        "interaction" : "cut3",
        "SUID" : 1807,
        "BEND_MAP_ID" : 1807,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1806",
        "source" : "556",
        "target" : "265",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Cinderella (cut3) Alice",
        "shared_interaction" : "cut3",
        "name" : "Cinderella (cut3) Alice",
        "interaction" : "cut3",
        "SUID" : 1806,
        "BEND_MAP_ID" : 1806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1805",
        "source" : "556",
        "target" : "558",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Cinderella (cut2) Aurora",
        "shared_interaction" : "cut2",
        "name" : "Cinderella (cut2) Aurora",
        "interaction" : "cut2",
        "SUID" : 1805,
        "BEND_MAP_ID" : 1805,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1804",
        "source" : "556",
        "target" : "84",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Cinderella (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Cinderella (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1804,
        "BEND_MAP_ID" : 1804,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1803",
        "source" : "556",
        "target" : "562",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Cinderella (cut2) Snow White",
        "shared_interaction" : "cut2",
        "name" : "Cinderella (cut2) Snow White",
        "interaction" : "cut2",
        "SUID" : 1803,
        "BEND_MAP_ID" : 1803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1802",
        "source" : "556",
        "target" : "265",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Cinderella (cut2) Alice",
        "shared_interaction" : "cut2",
        "name" : "Cinderella (cut2) Alice",
        "interaction" : "cut2",
        "SUID" : 1802,
        "BEND_MAP_ID" : 1802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1801",
        "source" : "556",
        "target" : "120",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Cinderella (cut2) Jasmine",
        "shared_interaction" : "cut2",
        "name" : "Cinderella (cut2) Jasmine",
        "interaction" : "cut2",
        "SUID" : 1801,
        "BEND_MAP_ID" : 1801,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1800",
        "source" : "556",
        "target" : "558",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Cinderella (cut1) Aurora",
        "shared_interaction" : "cut1",
        "name" : "Cinderella (cut1) Aurora",
        "interaction" : "cut1",
        "SUID" : 1800,
        "BEND_MAP_ID" : 1800,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1799",
        "source" : "556",
        "target" : "84",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Cinderella (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Cinderella (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1799,
        "BEND_MAP_ID" : 1799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1798",
        "source" : "554",
        "target" : "84",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Belle (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Belle (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1798,
        "BEND_MAP_ID" : 1798,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1793",
        "source" : "548",
        "target" : "441",
        "EdgeBetweenness" : 3.6666666666666665,
        "shared_name" : "Roo (cut3) Tigger",
        "shared_interaction" : "cut3",
        "name" : "Roo (cut3) Tigger",
        "interaction" : "cut3",
        "SUID" : 1793,
        "BEND_MAP_ID" : 1793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1792",
        "source" : "548",
        "target" : "466",
        "EdgeBetweenness" : 5.666666666666666,
        "shared_name" : "Roo (cut2) Owl",
        "shared_interaction" : "cut2",
        "name" : "Roo (cut2) Owl",
        "interaction" : "cut2",
        "SUID" : 1792,
        "BEND_MAP_ID" : 1792,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1791",
        "source" : "548",
        "target" : "466",
        "EdgeBetweenness" : 5.666666666666666,
        "shared_name" : "Roo (cut1) Owl",
        "shared_interaction" : "cut1",
        "name" : "Roo (cut1) Owl",
        "interaction" : "cut1",
        "SUID" : 1791,
        "BEND_MAP_ID" : 1791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1790",
        "source" : "548",
        "target" : "84",
        "EdgeBetweenness" : 154.66666666666669,
        "shared_name" : "Roo (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Roo (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1790,
        "BEND_MAP_ID" : 1790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1789",
        "source" : "548",
        "target" : "441",
        "EdgeBetweenness" : 3.6666666666666665,
        "shared_name" : "Roo (cut1) Tigger",
        "shared_interaction" : "cut1",
        "name" : "Roo (cut1) Tigger",
        "interaction" : "cut1",
        "SUID" : 1789,
        "BEND_MAP_ID" : 1789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1783",
        "source" : "534",
        "target" : "114",
        "EdgeBetweenness" : 27.09963369963369,
        "shared_name" : "Beast (cut9) Donald",
        "shared_interaction" : "cut9",
        "name" : "Beast (cut9) Donald",
        "interaction" : "cut9",
        "SUID" : 1783,
        "BEND_MAP_ID" : 1783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1782",
        "source" : "534",
        "target" : "106",
        "EdgeBetweenness" : 37.23296703296703,
        "shared_name" : "Beast (cut9) Goofy",
        "shared_interaction" : "cut9",
        "name" : "Beast (cut9) Goofy",
        "interaction" : "cut9",
        "SUID" : 1782,
        "BEND_MAP_ID" : 1782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1781",
        "source" : "534",
        "target" : "84",
        "EdgeBetweenness" : 84.7201465201465,
        "shared_name" : "Beast (cut9) Sora",
        "shared_interaction" : "cut9",
        "name" : "Beast (cut9) Sora",
        "interaction" : "cut9",
        "SUID" : 1781,
        "BEND_MAP_ID" : 1781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1780",
        "source" : "534",
        "target" : "84",
        "EdgeBetweenness" : 84.7201465201465,
        "shared_name" : "Beast (cut8) Sora",
        "shared_interaction" : "cut8",
        "name" : "Beast (cut8) Sora",
        "interaction" : "cut8",
        "SUID" : 1780,
        "BEND_MAP_ID" : 1780,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1779",
        "source" : "534",
        "target" : "96",
        "EdgeBetweenness" : 14.947252747252747,
        "shared_name" : "Beast (cut1) Riku",
        "shared_interaction" : "cut1",
        "name" : "Beast (cut1) Riku",
        "interaction" : "cut1",
        "SUID" : 1779,
        "BEND_MAP_ID" : 1779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1778",
        "source" : "490",
        "target" : "488",
        "EdgeBetweenness" : 5.333333333333333,
        "shared_name" : "Wendy (cut4) Peter Pan",
        "shared_interaction" : "cut4",
        "name" : "Wendy (cut4) Peter Pan",
        "interaction" : "cut4",
        "SUID" : 1778,
        "BEND_MAP_ID" : 1778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1777",
        "source" : "490",
        "target" : "84",
        "EdgeBetweenness" : 158.66666666666669,
        "shared_name" : "Wendy (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Wendy (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1777,
        "BEND_MAP_ID" : 1777,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1776",
        "source" : "490",
        "target" : "84",
        "EdgeBetweenness" : 158.66666666666669,
        "shared_name" : "Wendy (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Wendy (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1776,
        "BEND_MAP_ID" : 1776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1775",
        "source" : "490",
        "target" : "84",
        "EdgeBetweenness" : 158.66666666666669,
        "shared_name" : "Wendy (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Wendy (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1775,
        "BEND_MAP_ID" : 1775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1774",
        "source" : "490",
        "target" : "488",
        "EdgeBetweenness" : 5.333333333333333,
        "shared_name" : "Wendy (cut1) Peter Pan",
        "shared_interaction" : "cut1",
        "name" : "Wendy (cut1) Peter Pan",
        "interaction" : "cut1",
        "SUID" : 1774,
        "BEND_MAP_ID" : 1774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1773",
        "source" : "488",
        "target" : "490",
        "EdgeBetweenness" : 5.333333333333333,
        "shared_name" : "Peter Pan (cut19) Wendy",
        "shared_interaction" : "cut19",
        "name" : "Peter Pan (cut19) Wendy",
        "interaction" : "cut19",
        "SUID" : 1773,
        "BEND_MAP_ID" : 1773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1772",
        "source" : "488",
        "target" : "84",
        "EdgeBetweenness" : 106.25396825396825,
        "shared_name" : "Peter Pan (cut17) Sora",
        "shared_interaction" : "cut17",
        "name" : "Peter Pan (cut17) Sora",
        "interaction" : "cut17",
        "SUID" : 1772,
        "BEND_MAP_ID" : 1772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1771",
        "source" : "488",
        "target" : "84",
        "EdgeBetweenness" : 106.25396825396825,
        "shared_name" : "Peter Pan (cut16) Sora",
        "shared_interaction" : "cut16",
        "name" : "Peter Pan (cut16) Sora",
        "interaction" : "cut16",
        "SUID" : 1771,
        "BEND_MAP_ID" : 1771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1770",
        "source" : "488",
        "target" : "84",
        "EdgeBetweenness" : 106.25396825396825,
        "shared_name" : "Peter Pan (cut13) Sora",
        "shared_interaction" : "cut13",
        "name" : "Peter Pan (cut13) Sora",
        "interaction" : "cut13",
        "SUID" : 1770,
        "BEND_MAP_ID" : 1770,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1769",
        "source" : "488",
        "target" : "84",
        "EdgeBetweenness" : 106.25396825396825,
        "shared_name" : "Peter Pan (cut6) Sora",
        "shared_interaction" : "cut6",
        "name" : "Peter Pan (cut6) Sora",
        "interaction" : "cut6",
        "SUID" : 1769,
        "BEND_MAP_ID" : 1769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1768",
        "source" : "488",
        "target" : "490",
        "EdgeBetweenness" : 5.333333333333333,
        "shared_name" : "Peter Pan (cut6) Wendy",
        "shared_interaction" : "cut6",
        "name" : "Peter Pan (cut6) Wendy",
        "interaction" : "cut6",
        "SUID" : 1768,
        "BEND_MAP_ID" : 1768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1767",
        "source" : "488",
        "target" : "106",
        "EdgeBetweenness" : 59.07936507936507,
        "shared_name" : "Peter Pan (cut2) Goofy",
        "shared_interaction" : "cut2",
        "name" : "Peter Pan (cut2) Goofy",
        "interaction" : "cut2",
        "SUID" : 1767,
        "BEND_MAP_ID" : 1767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1716",
        "source" : "474",
        "target" : "1710",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Jack (cut26) Sally",
        "shared_interaction" : "cut26",
        "name" : "Jack (cut26) Sally",
        "interaction" : "cut26",
        "SUID" : 1716,
        "BEND_MAP_ID" : 1716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1715",
        "source" : "474",
        "target" : "84",
        "EdgeBetweenness" : 610.6666666666667,
        "shared_name" : "Jack (cut25) Sora",
        "shared_interaction" : "cut25",
        "name" : "Jack (cut25) Sora",
        "interaction" : "cut25",
        "SUID" : 1715,
        "BEND_MAP_ID" : 1715,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1714",
        "source" : "474",
        "target" : "1713",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Jack (cut22) Oogie Boogie",
        "shared_interaction" : "cut22",
        "name" : "Jack (cut22) Oogie Boogie",
        "interaction" : "cut22",
        "SUID" : 1714,
        "BEND_MAP_ID" : 1714,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1712",
        "source" : "474",
        "target" : "1710",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Jack (cut17) Sally",
        "shared_interaction" : "cut17",
        "name" : "Jack (cut17) Sally",
        "interaction" : "cut17",
        "SUID" : 1712,
        "BEND_MAP_ID" : 1712,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1711",
        "source" : "474",
        "target" : "1710",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Jack (cut16) Sally",
        "shared_interaction" : "cut16",
        "name" : "Jack (cut16) Sally",
        "interaction" : "cut16",
        "SUID" : 1711,
        "BEND_MAP_ID" : 1711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1709",
        "source" : "474",
        "target" : "1700",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Jack (cut14) Mayor",
        "shared_interaction" : "cut14",
        "name" : "Jack (cut14) Mayor",
        "interaction" : "cut14",
        "SUID" : 1709,
        "BEND_MAP_ID" : 1709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1708",
        "source" : "474",
        "target" : "84",
        "EdgeBetweenness" : 610.6666666666667,
        "shared_name" : "Jack (cut13) Sora",
        "shared_interaction" : "cut13",
        "name" : "Jack (cut13) Sora",
        "interaction" : "cut13",
        "SUID" : 1708,
        "BEND_MAP_ID" : 1708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1707",
        "source" : "474",
        "target" : "471",
        "EdgeBetweenness" : 21.333333333333332,
        "shared_name" : "Jack (cut13) Finkelstein",
        "shared_interaction" : "cut13",
        "name" : "Jack (cut13) Finkelstein",
        "interaction" : "cut13",
        "SUID" : 1707,
        "BEND_MAP_ID" : 1707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1706",
        "source" : "474",
        "target" : "471",
        "EdgeBetweenness" : 21.333333333333332,
        "shared_name" : "Jack (cut9) Finkelstein",
        "shared_interaction" : "cut9",
        "name" : "Jack (cut9) Finkelstein",
        "interaction" : "cut9",
        "SUID" : 1706,
        "BEND_MAP_ID" : 1706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1705",
        "source" : "474",
        "target" : "84",
        "EdgeBetweenness" : 610.6666666666667,
        "shared_name" : "Jack (cut8) Sora",
        "shared_interaction" : "cut8",
        "name" : "Jack (cut8) Sora",
        "interaction" : "cut8",
        "SUID" : 1705,
        "BEND_MAP_ID" : 1705,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1704",
        "source" : "474",
        "target" : "471",
        "EdgeBetweenness" : 21.333333333333332,
        "shared_name" : "Jack (cut6) Finkelstein",
        "shared_interaction" : "cut6",
        "name" : "Jack (cut6) Finkelstein",
        "interaction" : "cut6",
        "SUID" : 1704,
        "BEND_MAP_ID" : 1704,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1703",
        "source" : "474",
        "target" : "471",
        "EdgeBetweenness" : 21.333333333333332,
        "shared_name" : "Jack (cut5) Finkelstein",
        "shared_interaction" : "cut5",
        "name" : "Jack (cut5) Finkelstein",
        "interaction" : "cut5",
        "SUID" : 1703,
        "BEND_MAP_ID" : 1703,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1702",
        "source" : "474",
        "target" : "471",
        "EdgeBetweenness" : 21.333333333333332,
        "shared_name" : "Jack (cut4) Finkelstein",
        "shared_interaction" : "cut4",
        "name" : "Jack (cut4) Finkelstein",
        "interaction" : "cut4",
        "SUID" : 1702,
        "BEND_MAP_ID" : 1702,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1724",
        "source" : "471",
        "target" : "84",
        "EdgeBetweenness" : 110.92063492063492,
        "shared_name" : "Finkelstein (cut9) Sora",
        "shared_interaction" : "cut9",
        "name" : "Finkelstein (cut9) Sora",
        "interaction" : "cut9",
        "SUID" : 1724,
        "BEND_MAP_ID" : 1724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1723",
        "source" : "471",
        "target" : "474",
        "EdgeBetweenness" : 21.333333333333332,
        "shared_name" : "Finkelstein (cut9) Jack",
        "shared_interaction" : "cut9",
        "name" : "Finkelstein (cut9) Jack",
        "interaction" : "cut9",
        "SUID" : 1723,
        "BEND_MAP_ID" : 1723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1722",
        "source" : "471",
        "target" : "474",
        "EdgeBetweenness" : 21.333333333333332,
        "shared_name" : "Finkelstein (cut5) Jack",
        "shared_interaction" : "cut5",
        "name" : "Finkelstein (cut5) Jack",
        "interaction" : "cut5",
        "SUID" : 1722,
        "BEND_MAP_ID" : 1722,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1721",
        "source" : "471",
        "target" : "84",
        "EdgeBetweenness" : 110.92063492063492,
        "shared_name" : "Finkelstein (cut4) Sora",
        "shared_interaction" : "cut4",
        "name" : "Finkelstein (cut4) Sora",
        "interaction" : "cut4",
        "SUID" : 1721,
        "BEND_MAP_ID" : 1721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1720",
        "source" : "471",
        "target" : "114",
        "EdgeBetweenness" : 58.412698412698404,
        "shared_name" : "Finkelstein (cut4) Donald",
        "shared_interaction" : "cut4",
        "name" : "Finkelstein (cut4) Donald",
        "interaction" : "cut4",
        "SUID" : 1720,
        "BEND_MAP_ID" : 1720,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1719",
        "source" : "471",
        "target" : "474",
        "EdgeBetweenness" : 21.333333333333332,
        "shared_name" : "Finkelstein (cut3) Jack",
        "shared_interaction" : "cut3",
        "name" : "Finkelstein (cut3) Jack",
        "interaction" : "cut3",
        "SUID" : 1719,
        "BEND_MAP_ID" : 1719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1718",
        "source" : "471",
        "target" : "474",
        "EdgeBetweenness" : 21.333333333333332,
        "shared_name" : "Finkelstein (cut2) Jack",
        "shared_interaction" : "cut2",
        "name" : "Finkelstein (cut2) Jack",
        "interaction" : "cut2",
        "SUID" : 1718,
        "BEND_MAP_ID" : 1718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1717",
        "source" : "471",
        "target" : "474",
        "EdgeBetweenness" : 21.333333333333332,
        "shared_name" : "Finkelstein (cut1) Jack",
        "shared_interaction" : "cut1",
        "name" : "Finkelstein (cut1) Jack",
        "interaction" : "cut1",
        "SUID" : 1717,
        "BEND_MAP_ID" : 1717,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1448",
        "source" : "466",
        "target" : "548",
        "EdgeBetweenness" : 5.666666666666666,
        "shared_name" : "Owl (cut18) Roo",
        "shared_interaction" : "cut18",
        "name" : "Owl (cut18) Roo",
        "interaction" : "cut18",
        "SUID" : 1448,
        "BEND_MAP_ID" : 1448,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1447",
        "source" : "466",
        "target" : "84",
        "EdgeBetweenness" : 191.06536796536807,
        "shared_name" : "Owl (cut17) Sora",
        "shared_interaction" : "cut17",
        "name" : "Owl (cut17) Sora",
        "interaction" : "cut17",
        "SUID" : 1447,
        "BEND_MAP_ID" : 1447,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1446",
        "source" : "466",
        "target" : "548",
        "EdgeBetweenness" : 5.666666666666666,
        "shared_name" : "Owl (cut17) Roo",
        "shared_interaction" : "cut17",
        "name" : "Owl (cut17) Roo",
        "interaction" : "cut17",
        "SUID" : 1446,
        "BEND_MAP_ID" : 1446,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1445",
        "source" : "466",
        "target" : "441",
        "EdgeBetweenness" : 3.5666666666666664,
        "shared_name" : "Owl (cut17) Tigger",
        "shared_interaction" : "cut17",
        "name" : "Owl (cut17) Tigger",
        "interaction" : "cut17",
        "SUID" : 1445,
        "BEND_MAP_ID" : 1445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1444",
        "source" : "466",
        "target" : "84",
        "EdgeBetweenness" : 191.06536796536807,
        "shared_name" : "Owl (cut16) Sora",
        "shared_interaction" : "cut16",
        "name" : "Owl (cut16) Sora",
        "interaction" : "cut16",
        "SUID" : 1444,
        "BEND_MAP_ID" : 1444,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1443",
        "source" : "466",
        "target" : "84",
        "EdgeBetweenness" : 191.06536796536807,
        "shared_name" : "Owl (cut15) Sora",
        "shared_interaction" : "cut15",
        "name" : "Owl (cut15) Sora",
        "interaction" : "cut15",
        "SUID" : 1443,
        "BEND_MAP_ID" : 1443,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1442",
        "source" : "466",
        "target" : "84",
        "EdgeBetweenness" : 191.06536796536807,
        "shared_name" : "Owl (cut13) Sora",
        "shared_interaction" : "cut13",
        "name" : "Owl (cut13) Sora",
        "interaction" : "cut13",
        "SUID" : 1442,
        "BEND_MAP_ID" : 1442,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1441",
        "source" : "466",
        "target" : "94",
        "EdgeBetweenness" : 7.7333333333333325,
        "shared_name" : "Owl (cut12) Pooh",
        "shared_interaction" : "cut12",
        "name" : "Owl (cut12) Pooh",
        "interaction" : "cut12",
        "SUID" : 1441,
        "BEND_MAP_ID" : 1441,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1440",
        "source" : "466",
        "target" : "591",
        "EdgeBetweenness" : 4.566666666666666,
        "shared_name" : "Owl (cut12) Eeyore",
        "shared_interaction" : "cut12",
        "name" : "Owl (cut12) Eeyore",
        "interaction" : "cut12",
        "SUID" : 1440,
        "BEND_MAP_ID" : 1440,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1439",
        "source" : "466",
        "target" : "1421",
        "EdgeBetweenness" : 49.065367965368054,
        "shared_name" : "Owl (cut5) Rabbit",
        "shared_interaction" : "cut5",
        "name" : "Owl (cut5) Rabbit",
        "interaction" : "cut5",
        "SUID" : 1439,
        "BEND_MAP_ID" : 1439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1438",
        "source" : "466",
        "target" : "94",
        "EdgeBetweenness" : 7.7333333333333325,
        "shared_name" : "Owl (cut2) Pooh",
        "shared_interaction" : "cut2",
        "name" : "Owl (cut2) Pooh",
        "interaction" : "cut2",
        "SUID" : 1438,
        "BEND_MAP_ID" : 1438,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1674",
        "source" : "450",
        "target" : "106",
        "EdgeBetweenness" : 46.550000000000004,
        "shared_name" : "Triton (cut13) Goofy",
        "shared_interaction" : "cut13",
        "name" : "Triton (cut13) Goofy",
        "interaction" : "cut13",
        "SUID" : 1674,
        "BEND_MAP_ID" : 1674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1673",
        "source" : "450",
        "target" : "84",
        "EdgeBetweenness" : 99.0,
        "shared_name" : "Triton (cut13) Sora",
        "shared_interaction" : "cut13",
        "name" : "Triton (cut13) Sora",
        "interaction" : "cut13",
        "SUID" : 1673,
        "BEND_MAP_ID" : 1673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1672",
        "source" : "450",
        "target" : "447",
        "EdgeBetweenness" : 13.0,
        "shared_name" : "Triton (cut13) Ariel",
        "shared_interaction" : "cut13",
        "name" : "Triton (cut13) Ariel",
        "interaction" : "cut13",
        "SUID" : 1672,
        "BEND_MAP_ID" : 1672,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1671",
        "source" : "450",
        "target" : "136",
        "EdgeBetweenness" : 5.449999999999998,
        "shared_name" : "Triton (cut12) Sebastian",
        "shared_interaction" : "cut12",
        "name" : "Triton (cut12) Sebastian",
        "interaction" : "cut12",
        "SUID" : 1671,
        "BEND_MAP_ID" : 1671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1670",
        "source" : "450",
        "target" : "84",
        "EdgeBetweenness" : 99.0,
        "shared_name" : "Triton (cut11) Sora",
        "shared_interaction" : "cut11",
        "name" : "Triton (cut11) Sora",
        "interaction" : "cut11",
        "SUID" : 1670,
        "BEND_MAP_ID" : 1670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1669",
        "source" : "450",
        "target" : "447",
        "EdgeBetweenness" : 13.0,
        "shared_name" : "Triton (cut11) Ariel",
        "shared_interaction" : "cut11",
        "name" : "Triton (cut11) Ariel",
        "interaction" : "cut11",
        "SUID" : 1669,
        "BEND_MAP_ID" : 1669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1668",
        "source" : "450",
        "target" : "106",
        "EdgeBetweenness" : 46.550000000000004,
        "shared_name" : "Triton (cut10) Goofy",
        "shared_interaction" : "cut10",
        "name" : "Triton (cut10) Goofy",
        "interaction" : "cut10",
        "SUID" : 1668,
        "BEND_MAP_ID" : 1668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1667",
        "source" : "450",
        "target" : "84",
        "EdgeBetweenness" : 99.0,
        "shared_name" : "Triton (cut10) Sora",
        "shared_interaction" : "cut10",
        "name" : "Triton (cut10) Sora",
        "interaction" : "cut10",
        "SUID" : 1667,
        "BEND_MAP_ID" : 1667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1666",
        "source" : "450",
        "target" : "136",
        "EdgeBetweenness" : 5.449999999999998,
        "shared_name" : "Triton (cut7) Sebastian",
        "shared_interaction" : "cut7",
        "name" : "Triton (cut7) Sebastian",
        "interaction" : "cut7",
        "SUID" : 1666,
        "BEND_MAP_ID" : 1666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1665",
        "source" : "450",
        "target" : "136",
        "EdgeBetweenness" : 5.449999999999998,
        "shared_name" : "Triton (cut6) Sebastian",
        "shared_interaction" : "cut6",
        "name" : "Triton (cut6) Sebastian",
        "interaction" : "cut6",
        "SUID" : 1665,
        "BEND_MAP_ID" : 1665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1664",
        "source" : "450",
        "target" : "106",
        "EdgeBetweenness" : 46.550000000000004,
        "shared_name" : "Triton (cut4) Goofy",
        "shared_interaction" : "cut4",
        "name" : "Triton (cut4) Goofy",
        "interaction" : "cut4",
        "SUID" : 1664,
        "BEND_MAP_ID" : 1664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1663",
        "source" : "450",
        "target" : "84",
        "EdgeBetweenness" : 99.0,
        "shared_name" : "Triton (cut4) Sora",
        "shared_interaction" : "cut4",
        "name" : "Triton (cut4) Sora",
        "interaction" : "cut4",
        "SUID" : 1663,
        "BEND_MAP_ID" : 1663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1662",
        "source" : "450",
        "target" : "447",
        "EdgeBetweenness" : 13.0,
        "shared_name" : "Triton (cut4) Ariel",
        "shared_interaction" : "cut4",
        "name" : "Triton (cut4) Ariel",
        "interaction" : "cut4",
        "SUID" : 1662,
        "BEND_MAP_ID" : 1662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1661",
        "source" : "450",
        "target" : "136",
        "EdgeBetweenness" : 5.449999999999998,
        "shared_name" : "Triton (cut4) Sebastian",
        "shared_interaction" : "cut4",
        "name" : "Triton (cut4) Sebastian",
        "interaction" : "cut4",
        "SUID" : 1661,
        "BEND_MAP_ID" : 1661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1660",
        "source" : "450",
        "target" : "447",
        "EdgeBetweenness" : 13.0,
        "shared_name" : "Triton (cut1) Ariel",
        "shared_interaction" : "cut1",
        "name" : "Triton (cut1) Ariel",
        "interaction" : "cut1",
        "SUID" : 1660,
        "BEND_MAP_ID" : 1660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1656",
        "source" : "447",
        "target" : "136",
        "EdgeBetweenness" : 26.700000000000006,
        "shared_name" : "Ariel (cut25) Sebastian",
        "shared_interaction" : "cut25",
        "name" : "Ariel (cut25) Sebastian",
        "interaction" : "cut25",
        "SUID" : 1656,
        "BEND_MAP_ID" : 1656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1655",
        "source" : "447",
        "target" : "84",
        "EdgeBetweenness" : 636.4939393939393,
        "shared_name" : "Ariel (cut24) Sora",
        "shared_interaction" : "cut24",
        "name" : "Ariel (cut24) Sora",
        "interaction" : "cut24",
        "SUID" : 1655,
        "BEND_MAP_ID" : 1655,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1654",
        "source" : "447",
        "target" : "106",
        "EdgeBetweenness" : 296.960606060606,
        "shared_name" : "Ariel (cut23) Goofy",
        "shared_interaction" : "cut23",
        "name" : "Ariel (cut23) Goofy",
        "interaction" : "cut23",
        "SUID" : 1654,
        "BEND_MAP_ID" : 1654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1653",
        "source" : "447",
        "target" : "450",
        "EdgeBetweenness" : 13.0,
        "shared_name" : "Ariel (cut23) Triton",
        "shared_interaction" : "cut23",
        "name" : "Ariel (cut23) Triton",
        "interaction" : "cut23",
        "SUID" : 1653,
        "BEND_MAP_ID" : 1653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1652",
        "source" : "447",
        "target" : "84",
        "EdgeBetweenness" : 636.4939393939393,
        "shared_name" : "Ariel (cut23) Sora",
        "shared_interaction" : "cut23",
        "name" : "Ariel (cut23) Sora",
        "interaction" : "cut23",
        "SUID" : 1652,
        "BEND_MAP_ID" : 1652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1651",
        "source" : "447",
        "target" : "1646",
        "EdgeBetweenness" : 158.0,
        "shared_name" : "Ariel (cut22) Ursula",
        "shared_interaction" : "cut22",
        "name" : "Ariel (cut22) Ursula",
        "interaction" : "cut22",
        "SUID" : 1651,
        "BEND_MAP_ID" : 1651,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1650",
        "source" : "447",
        "target" : "84",
        "EdgeBetweenness" : 636.4939393939393,
        "shared_name" : "Ariel (cut20) Sora",
        "shared_interaction" : "cut20",
        "name" : "Ariel (cut20) Sora",
        "interaction" : "cut20",
        "SUID" : 1650,
        "BEND_MAP_ID" : 1650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1649",
        "source" : "447",
        "target" : "450",
        "EdgeBetweenness" : 13.0,
        "shared_name" : "Ariel (cut20) Triton",
        "shared_interaction" : "cut20",
        "name" : "Ariel (cut20) Triton",
        "interaction" : "cut20",
        "SUID" : 1649,
        "BEND_MAP_ID" : 1649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1648",
        "source" : "447",
        "target" : "1646",
        "EdgeBetweenness" : 158.0,
        "shared_name" : "Ariel (cut19) Ursula",
        "shared_interaction" : "cut19",
        "name" : "Ariel (cut19) Ursula",
        "interaction" : "cut19",
        "SUID" : 1648,
        "BEND_MAP_ID" : 1648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1647",
        "source" : "447",
        "target" : "1646",
        "EdgeBetweenness" : 158.0,
        "shared_name" : "Ariel (cut18) Ursula",
        "shared_interaction" : "cut18",
        "name" : "Ariel (cut18) Ursula",
        "interaction" : "cut18",
        "SUID" : 1647,
        "BEND_MAP_ID" : 1647,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1645",
        "source" : "447",
        "target" : "1644",
        "EdgeBetweenness" : 237.0,
        "shared_name" : "Ariel (cut17) Flotsam",
        "shared_interaction" : "cut17",
        "name" : "Ariel (cut17) Flotsam",
        "interaction" : "cut17",
        "SUID" : 1645,
        "BEND_MAP_ID" : 1645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1643",
        "source" : "447",
        "target" : "1642",
        "EdgeBetweenness" : 237.0,
        "shared_name" : "Ariel (cut17) Jetsam",
        "shared_interaction" : "cut17",
        "name" : "Ariel (cut17) Jetsam",
        "interaction" : "cut17",
        "SUID" : 1643,
        "BEND_MAP_ID" : 1643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1641",
        "source" : "447",
        "target" : "84",
        "EdgeBetweenness" : 636.4939393939393,
        "shared_name" : "Ariel (cut13) Sora",
        "shared_interaction" : "cut13",
        "name" : "Ariel (cut13) Sora",
        "interaction" : "cut13",
        "SUID" : 1641,
        "BEND_MAP_ID" : 1641,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1640",
        "source" : "447",
        "target" : "106",
        "EdgeBetweenness" : 296.960606060606,
        "shared_name" : "Ariel (cut9) Goofy",
        "shared_interaction" : "cut9",
        "name" : "Ariel (cut9) Goofy",
        "interaction" : "cut9",
        "SUID" : 1640,
        "BEND_MAP_ID" : 1640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1639",
        "source" : "447",
        "target" : "84",
        "EdgeBetweenness" : 636.4939393939393,
        "shared_name" : "Ariel (cut9) Sora",
        "shared_interaction" : "cut9",
        "name" : "Ariel (cut9) Sora",
        "interaction" : "cut9",
        "SUID" : 1639,
        "BEND_MAP_ID" : 1639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1638",
        "source" : "447",
        "target" : "450",
        "EdgeBetweenness" : 13.0,
        "shared_name" : "Ariel (cut9) Triton",
        "shared_interaction" : "cut9",
        "name" : "Ariel (cut9) Triton",
        "interaction" : "cut9",
        "SUID" : 1638,
        "BEND_MAP_ID" : 1638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1637",
        "source" : "447",
        "target" : "136",
        "EdgeBetweenness" : 26.700000000000006,
        "shared_name" : "Ariel (cut9) Sebastian",
        "shared_interaction" : "cut9",
        "name" : "Ariel (cut9) Sebastian",
        "interaction" : "cut9",
        "SUID" : 1637,
        "BEND_MAP_ID" : 1637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1636",
        "source" : "447",
        "target" : "450",
        "EdgeBetweenness" : 13.0,
        "shared_name" : "Ariel (cut8) Triton",
        "shared_interaction" : "cut8",
        "name" : "Ariel (cut8) Triton",
        "interaction" : "cut8",
        "SUID" : 1636,
        "BEND_MAP_ID" : 1636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1635",
        "source" : "447",
        "target" : "1617",
        "EdgeBetweenness" : 73.15454545454547,
        "shared_name" : "Ariel (cut6) Flounder",
        "shared_interaction" : "cut6",
        "name" : "Ariel (cut6) Flounder",
        "interaction" : "cut6",
        "SUID" : 1635,
        "BEND_MAP_ID" : 1635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1634",
        "source" : "447",
        "target" : "136",
        "EdgeBetweenness" : 26.700000000000006,
        "shared_name" : "Ariel (cut6) Sebastian",
        "shared_interaction" : "cut6",
        "name" : "Ariel (cut6) Sebastian",
        "interaction" : "cut6",
        "SUID" : 1634,
        "BEND_MAP_ID" : 1634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1633",
        "source" : "447",
        "target" : "136",
        "EdgeBetweenness" : 26.700000000000006,
        "shared_name" : "Ariel (cut5) Sebastian",
        "shared_interaction" : "cut5",
        "name" : "Ariel (cut5) Sebastian",
        "interaction" : "cut5",
        "SUID" : 1633,
        "BEND_MAP_ID" : 1633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1632",
        "source" : "447",
        "target" : "1631",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Ariel (cut4) Sebstian",
        "shared_interaction" : "cut4",
        "name" : "Ariel (cut4) Sebstian",
        "interaction" : "cut4",
        "SUID" : 1632,
        "BEND_MAP_ID" : 1632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1630",
        "source" : "447",
        "target" : "136",
        "EdgeBetweenness" : 26.700000000000006,
        "shared_name" : "Ariel (cut3) Sebastian",
        "shared_interaction" : "cut3",
        "name" : "Ariel (cut3) Sebastian",
        "interaction" : "cut3",
        "SUID" : 1630,
        "BEND_MAP_ID" : 1630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1629",
        "source" : "447",
        "target" : "84",
        "EdgeBetweenness" : 636.4939393939393,
        "shared_name" : "Ariel (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Ariel (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1629,
        "BEND_MAP_ID" : 1629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1354",
        "source" : "443",
        "target" : "292",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Hercules (cut8) Philoctetes",
        "shared_interaction" : "cut8",
        "name" : "Hercules (cut8) Philoctetes",
        "interaction" : "cut8",
        "SUID" : 1354,
        "BEND_MAP_ID" : 1354,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1353",
        "source" : "443",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Hercules (cut8) Sora",
        "shared_interaction" : "cut8",
        "name" : "Hercules (cut8) Sora",
        "interaction" : "cut8",
        "SUID" : 1353,
        "BEND_MAP_ID" : 1353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1352",
        "source" : "443",
        "target" : "292",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Hercules (cut7) Philoctetes",
        "shared_interaction" : "cut7",
        "name" : "Hercules (cut7) Philoctetes",
        "interaction" : "cut7",
        "SUID" : 1352,
        "BEND_MAP_ID" : 1352,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1351",
        "source" : "443",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Hercules (cut7) Sora",
        "shared_interaction" : "cut7",
        "name" : "Hercules (cut7) Sora",
        "interaction" : "cut7",
        "SUID" : 1351,
        "BEND_MAP_ID" : 1351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1350",
        "source" : "443",
        "target" : "106",
        "EdgeBetweenness" : 41.14871794871796,
        "shared_name" : "Hercules (cut6) Goofy",
        "shared_interaction" : "cut6",
        "name" : "Hercules (cut6) Goofy",
        "interaction" : "cut6",
        "SUID" : 1350,
        "BEND_MAP_ID" : 1350,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1349",
        "source" : "443",
        "target" : "114",
        "EdgeBetweenness" : 30.34871794871794,
        "shared_name" : "Hercules (cut6) Donald",
        "shared_interaction" : "cut6",
        "name" : "Hercules (cut6) Donald",
        "interaction" : "cut6",
        "SUID" : 1349,
        "BEND_MAP_ID" : 1349,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1348",
        "source" : "443",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Hercules (cut6) Sora",
        "shared_interaction" : "cut6",
        "name" : "Hercules (cut6) Sora",
        "interaction" : "cut6",
        "SUID" : 1348,
        "BEND_MAP_ID" : 1348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1347",
        "source" : "443",
        "target" : "292",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Hercules (cut5) Philoctetes",
        "shared_interaction" : "cut5",
        "name" : "Hercules (cut5) Philoctetes",
        "interaction" : "cut5",
        "SUID" : 1347,
        "BEND_MAP_ID" : 1347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1346",
        "source" : "443",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Hercules (cut5) Sora",
        "shared_interaction" : "cut5",
        "name" : "Hercules (cut5) Sora",
        "interaction" : "cut5",
        "SUID" : 1346,
        "BEND_MAP_ID" : 1346,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1345",
        "source" : "443",
        "target" : "292",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Hercules (cut4) Philoctetes",
        "shared_interaction" : "cut4",
        "name" : "Hercules (cut4) Philoctetes",
        "interaction" : "cut4",
        "SUID" : 1345,
        "BEND_MAP_ID" : 1345,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1344",
        "source" : "443",
        "target" : "292",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Hercules (cut3) Philoctetes",
        "shared_interaction" : "cut3",
        "name" : "Hercules (cut3) Philoctetes",
        "interaction" : "cut3",
        "SUID" : 1344,
        "BEND_MAP_ID" : 1344,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1343",
        "source" : "443",
        "target" : "106",
        "EdgeBetweenness" : 41.14871794871796,
        "shared_name" : "Hercules (cut2) Goofy",
        "shared_interaction" : "cut2",
        "name" : "Hercules (cut2) Goofy",
        "interaction" : "cut2",
        "SUID" : 1343,
        "BEND_MAP_ID" : 1343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1342",
        "source" : "443",
        "target" : "114",
        "EdgeBetweenness" : 30.34871794871794,
        "shared_name" : "Hercules (cut2) Donald",
        "shared_interaction" : "cut2",
        "name" : "Hercules (cut2) Donald",
        "interaction" : "cut2",
        "SUID" : 1342,
        "BEND_MAP_ID" : 1342,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1341",
        "source" : "443",
        "target" : "292",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Hercules (cut2) Philoctetes",
        "shared_interaction" : "cut2",
        "name" : "Hercules (cut2) Philoctetes",
        "interaction" : "cut2",
        "SUID" : 1341,
        "BEND_MAP_ID" : 1341,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1612",
        "source" : "441",
        "target" : "412",
        "EdgeBetweenness" : 5.519047619047619,
        "shared_name" : "Tigger (cut13) Piglet",
        "shared_interaction" : "cut13",
        "name" : "Tigger (cut13) Piglet",
        "interaction" : "cut13",
        "SUID" : 1612,
        "BEND_MAP_ID" : 1612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1611",
        "source" : "441",
        "target" : "94",
        "EdgeBetweenness" : 8.071428571428571,
        "shared_name" : "Tigger (cut12) Pooh",
        "shared_interaction" : "cut12",
        "name" : "Tigger (cut12) Pooh",
        "interaction" : "cut12",
        "SUID" : 1611,
        "BEND_MAP_ID" : 1611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1610",
        "source" : "441",
        "target" : "412",
        "EdgeBetweenness" : 5.519047619047619,
        "shared_name" : "Tigger (cut12) Piglet",
        "shared_interaction" : "cut12",
        "name" : "Tigger (cut12) Piglet",
        "interaction" : "cut12",
        "SUID" : 1610,
        "BEND_MAP_ID" : 1610,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1609",
        "source" : "441",
        "target" : "548",
        "EdgeBetweenness" : 3.6666666666666665,
        "shared_name" : "Tigger (cut10) Roo",
        "shared_interaction" : "cut10",
        "name" : "Tigger (cut10) Roo",
        "interaction" : "cut10",
        "SUID" : 1609,
        "BEND_MAP_ID" : 1609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1608",
        "source" : "441",
        "target" : "466",
        "EdgeBetweenness" : 3.5666666666666664,
        "shared_name" : "Tigger (cut5) Owl",
        "shared_interaction" : "cut5",
        "name" : "Tigger (cut5) Owl",
        "interaction" : "cut5",
        "SUID" : 1608,
        "BEND_MAP_ID" : 1608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1607",
        "source" : "441",
        "target" : "84",
        "EdgeBetweenness" : 147.30952380952385,
        "shared_name" : "Tigger (cut5) Sora",
        "shared_interaction" : "cut5",
        "name" : "Tigger (cut5) Sora",
        "interaction" : "cut5",
        "SUID" : 1607,
        "BEND_MAP_ID" : 1607,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1606",
        "source" : "441",
        "target" : "548",
        "EdgeBetweenness" : 3.6666666666666665,
        "shared_name" : "Tigger (cut5) Roo",
        "shared_interaction" : "cut5",
        "name" : "Tigger (cut5) Roo",
        "interaction" : "cut5",
        "SUID" : 1606,
        "BEND_MAP_ID" : 1606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1605",
        "source" : "441",
        "target" : "84",
        "EdgeBetweenness" : 147.30952380952385,
        "shared_name" : "Tigger (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Tigger (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1605,
        "BEND_MAP_ID" : 1605,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1604",
        "source" : "441",
        "target" : "94",
        "EdgeBetweenness" : 8.071428571428571,
        "shared_name" : "Tigger (cut1) Pooh",
        "shared_interaction" : "cut1",
        "name" : "Tigger (cut1) Pooh",
        "interaction" : "cut1",
        "SUID" : 1604,
        "BEND_MAP_ID" : 1604,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1597",
        "source" : "432",
        "target" : "387",
        "EdgeBetweenness" : 5.8,
        "shared_name" : "Geppetto (cut8) Pinocchio",
        "shared_interaction" : "cut8",
        "name" : "Geppetto (cut8) Pinocchio",
        "interaction" : "cut8",
        "SUID" : 1597,
        "BEND_MAP_ID" : 1597,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1596",
        "source" : "432",
        "target" : "84",
        "EdgeBetweenness" : 135.5761904761905,
        "shared_name" : "Geppetto (cut8) Sora",
        "shared_interaction" : "cut8",
        "name" : "Geppetto (cut8) Sora",
        "interaction" : "cut8",
        "SUID" : 1596,
        "BEND_MAP_ID" : 1596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1595",
        "source" : "432",
        "target" : "387",
        "EdgeBetweenness" : 5.8,
        "shared_name" : "Geppetto (cut7) Pinocchio",
        "shared_interaction" : "cut7",
        "name" : "Geppetto (cut7) Pinocchio",
        "interaction" : "cut7",
        "SUID" : 1595,
        "BEND_MAP_ID" : 1595,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1594",
        "source" : "432",
        "target" : "84",
        "EdgeBetweenness" : 135.5761904761905,
        "shared_name" : "Geppetto (cut7) Sora",
        "shared_interaction" : "cut7",
        "name" : "Geppetto (cut7) Sora",
        "interaction" : "cut7",
        "SUID" : 1594,
        "BEND_MAP_ID" : 1594,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1593",
        "source" : "432",
        "target" : "84",
        "EdgeBetweenness" : 135.5761904761905,
        "shared_name" : "Geppetto (cut6) Sora",
        "shared_interaction" : "cut6",
        "name" : "Geppetto (cut6) Sora",
        "interaction" : "cut6",
        "SUID" : 1593,
        "BEND_MAP_ID" : 1593,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1592",
        "source" : "432",
        "target" : "96",
        "EdgeBetweenness" : 22.62380952380952,
        "shared_name" : "Geppetto (cut6) Riku",
        "shared_interaction" : "cut6",
        "name" : "Geppetto (cut6) Riku",
        "interaction" : "cut6",
        "SUID" : 1592,
        "BEND_MAP_ID" : 1592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1591",
        "source" : "424",
        "target" : "84",
        "EdgeBetweenness" : 153.66666666666669,
        "shared_name" : "???????? (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "???????? (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1591,
        "BEND_MAP_ID" : 1591,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1590",
        "source" : "424",
        "target" : "84",
        "EdgeBetweenness" : 153.66666666666669,
        "shared_name" : "???????? (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "???????? (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1590,
        "BEND_MAP_ID" : 1590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1589",
        "source" : "424",
        "target" : "387",
        "EdgeBetweenness" : 10.333333333333334,
        "shared_name" : "???????? (cut2) Pinocchio",
        "shared_interaction" : "cut2",
        "name" : "???????? (cut2) Pinocchio",
        "interaction" : "cut2",
        "SUID" : 1589,
        "BEND_MAP_ID" : 1589,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1588",
        "source" : "412",
        "target" : "441",
        "EdgeBetweenness" : 5.519047619047619,
        "shared_name" : "Piglet (cut19) Tigger",
        "shared_interaction" : "cut19",
        "name" : "Piglet (cut19) Tigger",
        "interaction" : "cut19",
        "SUID" : 1588,
        "BEND_MAP_ID" : 1588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1587",
        "source" : "412",
        "target" : "94",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Piglet (cut17) Pooh",
        "shared_interaction" : "cut17",
        "name" : "Piglet (cut17) Pooh",
        "interaction" : "cut17",
        "SUID" : 1587,
        "BEND_MAP_ID" : 1587,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1586",
        "source" : "412",
        "target" : "441",
        "EdgeBetweenness" : 5.519047619047619,
        "shared_name" : "Piglet (cut17) Tigger",
        "shared_interaction" : "cut17",
        "name" : "Piglet (cut17) Tigger",
        "interaction" : "cut17",
        "SUID" : 1586,
        "BEND_MAP_ID" : 1586,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1585",
        "source" : "412",
        "target" : "94",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Piglet (cut14) Pooh",
        "shared_interaction" : "cut14",
        "name" : "Piglet (cut14) Pooh",
        "interaction" : "cut14",
        "SUID" : 1585,
        "BEND_MAP_ID" : 1585,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1584",
        "source" : "412",
        "target" : "591",
        "EdgeBetweenness" : 4.519047619047619,
        "shared_name" : "Piglet (cut12) Eeyore",
        "shared_interaction" : "cut12",
        "name" : "Piglet (cut12) Eeyore",
        "interaction" : "cut12",
        "SUID" : 1584,
        "BEND_MAP_ID" : 1584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1583",
        "source" : "412",
        "target" : "94",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Piglet (cut11) Pooh",
        "shared_interaction" : "cut11",
        "name" : "Piglet (cut11) Pooh",
        "interaction" : "cut11",
        "SUID" : 1583,
        "BEND_MAP_ID" : 1583,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1582",
        "source" : "412",
        "target" : "1421",
        "EdgeBetweenness" : 51.32597402597413,
        "shared_name" : "Piglet (cut10) Rabbit",
        "shared_interaction" : "cut10",
        "name" : "Piglet (cut10) Rabbit",
        "interaction" : "cut10",
        "SUID" : 1582,
        "BEND_MAP_ID" : 1582,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1581",
        "source" : "412",
        "target" : "94",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Piglet (cut10) Pooh",
        "shared_interaction" : "cut10",
        "name" : "Piglet (cut10) Pooh",
        "interaction" : "cut10",
        "SUID" : 1581,
        "BEND_MAP_ID" : 1581,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1580",
        "source" : "412",
        "target" : "222",
        "EdgeBetweenness" : 17.165367965367967,
        "shared_name" : "Piglet (cut8) ??????",
        "shared_interaction" : "cut8",
        "name" : "Piglet (cut8) ??????",
        "interaction" : "cut8",
        "SUID" : 1580,
        "BEND_MAP_ID" : 1580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1579",
        "source" : "412",
        "target" : "94",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Piglet (cut8) Pooh",
        "shared_interaction" : "cut8",
        "name" : "Piglet (cut8) Pooh",
        "interaction" : "cut8",
        "SUID" : 1579,
        "BEND_MAP_ID" : 1579,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1578",
        "source" : "412",
        "target" : "94",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Piglet (cut7) Pooh",
        "shared_interaction" : "cut7",
        "name" : "Piglet (cut7) Pooh",
        "interaction" : "cut7",
        "SUID" : 1578,
        "BEND_MAP_ID" : 1578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1577",
        "source" : "412",
        "target" : "94",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Piglet (cut6) Pooh",
        "shared_interaction" : "cut6",
        "name" : "Piglet (cut6) Pooh",
        "interaction" : "cut6",
        "SUID" : 1577,
        "BEND_MAP_ID" : 1577,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1576",
        "source" : "412",
        "target" : "94",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Piglet (cut5) Pooh",
        "shared_interaction" : "cut5",
        "name" : "Piglet (cut5) Pooh",
        "interaction" : "cut5",
        "SUID" : 1576,
        "BEND_MAP_ID" : 1576,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1575",
        "source" : "412",
        "target" : "84",
        "EdgeBetweenness" : 182.73203463203487,
        "shared_name" : "Piglet (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Piglet (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1575,
        "BEND_MAP_ID" : 1575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1574",
        "source" : "400",
        "target" : "395",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Genie (cut25) Aladdin",
        "shared_interaction" : "cut25",
        "name" : "Genie (cut25) Aladdin",
        "interaction" : "cut25",
        "SUID" : 1574,
        "BEND_MAP_ID" : 1574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1573",
        "source" : "400",
        "target" : "395",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Genie (cut22) Aladdin",
        "shared_interaction" : "cut22",
        "name" : "Genie (cut22) Aladdin",
        "interaction" : "cut22",
        "SUID" : 1573,
        "BEND_MAP_ID" : 1573,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1572",
        "source" : "400",
        "target" : "395",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Genie (cut21) Aladdin",
        "shared_interaction" : "cut21",
        "name" : "Genie (cut21) Aladdin",
        "interaction" : "cut21",
        "SUID" : 1572,
        "BEND_MAP_ID" : 1572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1571",
        "source" : "400",
        "target" : "84",
        "EdgeBetweenness" : 87.56666666666663,
        "shared_name" : "Genie (cut21) Sora",
        "shared_interaction" : "cut21",
        "name" : "Genie (cut21) Sora",
        "interaction" : "cut21",
        "SUID" : 1571,
        "BEND_MAP_ID" : 1571,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1570",
        "source" : "400",
        "target" : "114",
        "EdgeBetweenness" : 28.399999999999984,
        "shared_name" : "Genie (cut21) Donald",
        "shared_interaction" : "cut21",
        "name" : "Genie (cut21) Donald",
        "interaction" : "cut21",
        "SUID" : 1570,
        "BEND_MAP_ID" : 1570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1569",
        "source" : "400",
        "target" : "106",
        "EdgeBetweenness" : 38.36666666666666,
        "shared_name" : "Genie (cut21) Goofy",
        "shared_interaction" : "cut21",
        "name" : "Genie (cut21) Goofy",
        "interaction" : "cut21",
        "SUID" : 1569,
        "BEND_MAP_ID" : 1569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1568",
        "source" : "400",
        "target" : "395",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Genie (cut19) Aladdin",
        "shared_interaction" : "cut19",
        "name" : "Genie (cut19) Aladdin",
        "interaction" : "cut19",
        "SUID" : 1568,
        "BEND_MAP_ID" : 1568,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1567",
        "source" : "400",
        "target" : "123",
        "EdgeBetweenness" : 6.166666666666667,
        "shared_name" : "Genie (cut17) Jafar",
        "shared_interaction" : "cut17",
        "name" : "Genie (cut17) Jafar",
        "interaction" : "cut17",
        "SUID" : 1567,
        "BEND_MAP_ID" : 1567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1566",
        "source" : "400",
        "target" : "84",
        "EdgeBetweenness" : 87.56666666666663,
        "shared_name" : "Genie (cut16) Sora",
        "shared_interaction" : "cut16",
        "name" : "Genie (cut16) Sora",
        "interaction" : "cut16",
        "SUID" : 1566,
        "BEND_MAP_ID" : 1566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1565",
        "source" : "400",
        "target" : "114",
        "EdgeBetweenness" : 28.399999999999984,
        "shared_name" : "Genie (cut16) Donald",
        "shared_interaction" : "cut16",
        "name" : "Genie (cut16) Donald",
        "interaction" : "cut16",
        "SUID" : 1565,
        "BEND_MAP_ID" : 1565,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1564",
        "source" : "400",
        "target" : "395",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Genie (cut16) Aladdin",
        "shared_interaction" : "cut16",
        "name" : "Genie (cut16) Aladdin",
        "interaction" : "cut16",
        "SUID" : 1564,
        "BEND_MAP_ID" : 1564,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1563",
        "source" : "400",
        "target" : "395",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Genie (cut15) Aladdin",
        "shared_interaction" : "cut15",
        "name" : "Genie (cut15) Aladdin",
        "interaction" : "cut15",
        "SUID" : 1563,
        "BEND_MAP_ID" : 1563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1562",
        "source" : "400",
        "target" : "84",
        "EdgeBetweenness" : 87.56666666666663,
        "shared_name" : "Genie (cut15) Sora",
        "shared_interaction" : "cut15",
        "name" : "Genie (cut15) Sora",
        "interaction" : "cut15",
        "SUID" : 1562,
        "BEND_MAP_ID" : 1562,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1561",
        "source" : "400",
        "target" : "106",
        "EdgeBetweenness" : 38.36666666666666,
        "shared_name" : "Genie (cut14) Goofy",
        "shared_interaction" : "cut14",
        "name" : "Genie (cut14) Goofy",
        "interaction" : "cut14",
        "SUID" : 1561,
        "BEND_MAP_ID" : 1561,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1560",
        "source" : "400",
        "target" : "395",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Genie (cut14) Aladdin",
        "shared_interaction" : "cut14",
        "name" : "Genie (cut14) Aladdin",
        "interaction" : "cut14",
        "SUID" : 1560,
        "BEND_MAP_ID" : 1560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1559",
        "source" : "400",
        "target" : "395",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Genie (cut11) Aladdin",
        "shared_interaction" : "cut11",
        "name" : "Genie (cut11) Aladdin",
        "interaction" : "cut11",
        "SUID" : 1559,
        "BEND_MAP_ID" : 1559,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1558",
        "source" : "400",
        "target" : "114",
        "EdgeBetweenness" : 28.399999999999984,
        "shared_name" : "Genie (cut5) Donald",
        "shared_interaction" : "cut5",
        "name" : "Genie (cut5) Donald",
        "interaction" : "cut5",
        "SUID" : 1558,
        "BEND_MAP_ID" : 1558,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1557",
        "source" : "400",
        "target" : "395",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Genie (cut2) Aladdin",
        "shared_interaction" : "cut2",
        "name" : "Genie (cut2) Aladdin",
        "interaction" : "cut2",
        "SUID" : 1557,
        "BEND_MAP_ID" : 1557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1556",
        "source" : "395",
        "target" : "400",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Aladdin (cut23) Genie",
        "shared_interaction" : "cut23",
        "name" : "Aladdin (cut23) Genie",
        "interaction" : "cut23",
        "SUID" : 1556,
        "BEND_MAP_ID" : 1556,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1555",
        "source" : "395",
        "target" : "400",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Aladdin (cut21) Genie",
        "shared_interaction" : "cut21",
        "name" : "Aladdin (cut21) Genie",
        "interaction" : "cut21",
        "SUID" : 1555,
        "BEND_MAP_ID" : 1555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1554",
        "source" : "395",
        "target" : "400",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Aladdin (cut20) Genie",
        "shared_interaction" : "cut20",
        "name" : "Aladdin (cut20) Genie",
        "interaction" : "cut20",
        "SUID" : 1554,
        "BEND_MAP_ID" : 1554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1553",
        "source" : "395",
        "target" : "84",
        "EdgeBetweenness" : 118.15173160173158,
        "shared_name" : "Aladdin (cut20) Sora",
        "shared_interaction" : "cut20",
        "name" : "Aladdin (cut20) Sora",
        "interaction" : "cut20",
        "SUID" : 1553,
        "BEND_MAP_ID" : 1553,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1552",
        "source" : "395",
        "target" : "114",
        "EdgeBetweenness" : 40.246103896103904,
        "shared_name" : "Aladdin (cut20) Donald",
        "shared_interaction" : "cut20",
        "name" : "Aladdin (cut20) Donald",
        "interaction" : "cut20",
        "SUID" : 1552,
        "BEND_MAP_ID" : 1552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1551",
        "source" : "395",
        "target" : "106",
        "EdgeBetweenness" : 52.69458874458875,
        "shared_name" : "Aladdin (cut20) Goofy",
        "shared_interaction" : "cut20",
        "name" : "Aladdin (cut20) Goofy",
        "interaction" : "cut20",
        "SUID" : 1551,
        "BEND_MAP_ID" : 1551,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1550",
        "source" : "395",
        "target" : "84",
        "EdgeBetweenness" : 118.15173160173158,
        "shared_name" : "Aladdin (cut19) Sora",
        "shared_interaction" : "cut19",
        "name" : "Aladdin (cut19) Sora",
        "interaction" : "cut19",
        "SUID" : 1550,
        "BEND_MAP_ID" : 1550,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1549",
        "source" : "395",
        "target" : "106",
        "EdgeBetweenness" : 52.69458874458875,
        "shared_name" : "Aladdin (cut18) Goofy",
        "shared_interaction" : "cut18",
        "name" : "Aladdin (cut18) Goofy",
        "interaction" : "cut18",
        "SUID" : 1549,
        "BEND_MAP_ID" : 1549,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1548",
        "source" : "395",
        "target" : "1450",
        "EdgeBetweenness" : 69.79242424242425,
        "shared_name" : "Aladdin (cut16) Iago",
        "shared_interaction" : "cut16",
        "name" : "Aladdin (cut16) Iago",
        "interaction" : "cut16",
        "SUID" : 1548,
        "BEND_MAP_ID" : 1548,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1547",
        "source" : "395",
        "target" : "123",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Aladdin (cut16) Jafar",
        "shared_interaction" : "cut16",
        "name" : "Aladdin (cut16) Jafar",
        "interaction" : "cut16",
        "SUID" : 1547,
        "BEND_MAP_ID" : 1547,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1546",
        "source" : "395",
        "target" : "400",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Aladdin (cut15) Genie",
        "shared_interaction" : "cut15",
        "name" : "Aladdin (cut15) Genie",
        "interaction" : "cut15",
        "SUID" : 1546,
        "BEND_MAP_ID" : 1546,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1545",
        "source" : "395",
        "target" : "123",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Aladdin (cut14) Jafar",
        "shared_interaction" : "cut14",
        "name" : "Aladdin (cut14) Jafar",
        "interaction" : "cut14",
        "SUID" : 1545,
        "BEND_MAP_ID" : 1545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1544",
        "source" : "395",
        "target" : "120",
        "EdgeBetweenness" : 12.299999999999999,
        "shared_name" : "Aladdin (cut10) Jasmine",
        "shared_interaction" : "cut10",
        "name" : "Aladdin (cut10) Jasmine",
        "interaction" : "cut10",
        "SUID" : 1544,
        "BEND_MAP_ID" : 1544,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1543",
        "source" : "395",
        "target" : "123",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Aladdin (cut10) Jafar",
        "shared_interaction" : "cut10",
        "name" : "Aladdin (cut10) Jafar",
        "interaction" : "cut10",
        "SUID" : 1543,
        "BEND_MAP_ID" : 1543,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1542",
        "source" : "395",
        "target" : "84",
        "EdgeBetweenness" : 118.15173160173158,
        "shared_name" : "Aladdin (cut9) Sora",
        "shared_interaction" : "cut9",
        "name" : "Aladdin (cut9) Sora",
        "interaction" : "cut9",
        "SUID" : 1542,
        "BEND_MAP_ID" : 1542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1541",
        "source" : "395",
        "target" : "114",
        "EdgeBetweenness" : 40.246103896103904,
        "shared_name" : "Aladdin (cut9) Donald",
        "shared_interaction" : "cut9",
        "name" : "Aladdin (cut9) Donald",
        "interaction" : "cut9",
        "SUID" : 1541,
        "BEND_MAP_ID" : 1541,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1540",
        "source" : "395",
        "target" : "400",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Aladdin (cut9) Genie",
        "shared_interaction" : "cut9",
        "name" : "Aladdin (cut9) Genie",
        "interaction" : "cut9",
        "SUID" : 1540,
        "BEND_MAP_ID" : 1540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1539",
        "source" : "395",
        "target" : "84",
        "EdgeBetweenness" : 118.15173160173158,
        "shared_name" : "Aladdin (cut8) Sora",
        "shared_interaction" : "cut8",
        "name" : "Aladdin (cut8) Sora",
        "interaction" : "cut8",
        "SUID" : 1539,
        "BEND_MAP_ID" : 1539,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1538",
        "source" : "395",
        "target" : "400",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Aladdin (cut8) Genie",
        "shared_interaction" : "cut8",
        "name" : "Aladdin (cut8) Genie",
        "interaction" : "cut8",
        "SUID" : 1538,
        "BEND_MAP_ID" : 1538,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1537",
        "source" : "395",
        "target" : "84",
        "EdgeBetweenness" : 118.15173160173158,
        "shared_name" : "Aladdin (cut7) Sora",
        "shared_interaction" : "cut7",
        "name" : "Aladdin (cut7) Sora",
        "interaction" : "cut7",
        "SUID" : 1537,
        "BEND_MAP_ID" : 1537,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1536",
        "source" : "395",
        "target" : "106",
        "EdgeBetweenness" : 52.69458874458875,
        "shared_name" : "Aladdin (cut7) Goofy",
        "shared_interaction" : "cut7",
        "name" : "Aladdin (cut7) Goofy",
        "interaction" : "cut7",
        "SUID" : 1536,
        "BEND_MAP_ID" : 1536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1535",
        "source" : "395",
        "target" : "114",
        "EdgeBetweenness" : 40.246103896103904,
        "shared_name" : "Aladdin (cut7) Donald",
        "shared_interaction" : "cut7",
        "name" : "Aladdin (cut7) Donald",
        "interaction" : "cut7",
        "SUID" : 1535,
        "BEND_MAP_ID" : 1535,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1534",
        "source" : "395",
        "target" : "106",
        "EdgeBetweenness" : 52.69458874458875,
        "shared_name" : "Aladdin (cut6) Goofy",
        "shared_interaction" : "cut6",
        "name" : "Aladdin (cut6) Goofy",
        "interaction" : "cut6",
        "SUID" : 1534,
        "BEND_MAP_ID" : 1534,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1533",
        "source" : "395",
        "target" : "400",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Aladdin (cut6) Genie",
        "shared_interaction" : "cut6",
        "name" : "Aladdin (cut6) Genie",
        "interaction" : "cut6",
        "SUID" : 1533,
        "BEND_MAP_ID" : 1533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1532",
        "source" : "395",
        "target" : "400",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Aladdin (cut5) Genie",
        "shared_interaction" : "cut5",
        "name" : "Aladdin (cut5) Genie",
        "interaction" : "cut5",
        "SUID" : 1532,
        "BEND_MAP_ID" : 1532,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1531",
        "source" : "395",
        "target" : "400",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Aladdin (cut4) Genie",
        "shared_interaction" : "cut4",
        "name" : "Aladdin (cut4) Genie",
        "interaction" : "cut4",
        "SUID" : 1531,
        "BEND_MAP_ID" : 1531,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1530",
        "source" : "395",
        "target" : "84",
        "EdgeBetweenness" : 118.15173160173158,
        "shared_name" : "Aladdin (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Aladdin (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1530,
        "BEND_MAP_ID" : 1530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1482",
        "source" : "387",
        "target" : "432",
        "EdgeBetweenness" : 5.8,
        "shared_name" : "Pinocchio (cut12) Geppetto",
        "shared_interaction" : "cut12",
        "name" : "Pinocchio (cut12) Geppetto",
        "interaction" : "cut12",
        "SUID" : 1482,
        "BEND_MAP_ID" : 1482,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1481",
        "source" : "387",
        "target" : "84",
        "EdgeBetweenness" : 103.76666666666667,
        "shared_name" : "Pinocchio (cut12) Sora",
        "shared_interaction" : "cut12",
        "name" : "Pinocchio (cut12) Sora",
        "interaction" : "cut12",
        "SUID" : 1481,
        "BEND_MAP_ID" : 1481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1480",
        "source" : "387",
        "target" : "432",
        "EdgeBetweenness" : 5.8,
        "shared_name" : "Pinocchio (cut11) Geppetto",
        "shared_interaction" : "cut11",
        "name" : "Pinocchio (cut11) Geppetto",
        "interaction" : "cut11",
        "SUID" : 1480,
        "BEND_MAP_ID" : 1480,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1479",
        "source" : "387",
        "target" : "84",
        "EdgeBetweenness" : 103.76666666666667,
        "shared_name" : "Pinocchio (cut11) Sora",
        "shared_interaction" : "cut11",
        "name" : "Pinocchio (cut11) Sora",
        "interaction" : "cut11",
        "SUID" : 1479,
        "BEND_MAP_ID" : 1479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1478",
        "source" : "387",
        "target" : "253",
        "EdgeBetweenness" : 4.666666666666666,
        "shared_name" : "Pinocchio (cut9) Jiminy",
        "shared_interaction" : "cut9",
        "name" : "Pinocchio (cut9) Jiminy",
        "interaction" : "cut9",
        "SUID" : 1478,
        "BEND_MAP_ID" : 1478,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1477",
        "source" : "387",
        "target" : "96",
        "EdgeBetweenness" : 18.833333333333336,
        "shared_name" : "Pinocchio (cut9) Riku",
        "shared_interaction" : "cut9",
        "name" : "Pinocchio (cut9) Riku",
        "interaction" : "cut9",
        "SUID" : 1477,
        "BEND_MAP_ID" : 1477,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1476",
        "source" : "387",
        "target" : "84",
        "EdgeBetweenness" : 103.76666666666667,
        "shared_name" : "Pinocchio (cut9) Sora",
        "shared_interaction" : "cut9",
        "name" : "Pinocchio (cut9) Sora",
        "interaction" : "cut9",
        "SUID" : 1476,
        "BEND_MAP_ID" : 1476,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1475",
        "source" : "387",
        "target" : "84",
        "EdgeBetweenness" : 103.76666666666667,
        "shared_name" : "Pinocchio (cut7) Sora",
        "shared_interaction" : "cut7",
        "name" : "Pinocchio (cut7) Sora",
        "interaction" : "cut7",
        "SUID" : 1475,
        "BEND_MAP_ID" : 1475,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1474",
        "source" : "387",
        "target" : "84",
        "EdgeBetweenness" : 103.76666666666667,
        "shared_name" : "Pinocchio (cut6) Sora",
        "shared_interaction" : "cut6",
        "name" : "Pinocchio (cut6) Sora",
        "interaction" : "cut6",
        "SUID" : 1474,
        "BEND_MAP_ID" : 1474,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1473",
        "source" : "387",
        "target" : "424",
        "EdgeBetweenness" : 10.333333333333334,
        "shared_name" : "Pinocchio (cut6) ????????",
        "shared_interaction" : "cut6",
        "name" : "Pinocchio (cut6) ????????",
        "interaction" : "cut6",
        "SUID" : 1473,
        "BEND_MAP_ID" : 1473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1472",
        "source" : "387",
        "target" : "114",
        "EdgeBetweenness" : 42.86666666666667,
        "shared_name" : "Pinocchio (cut5) Donald",
        "shared_interaction" : "cut5",
        "name" : "Pinocchio (cut5) Donald",
        "interaction" : "cut5",
        "SUID" : 1472,
        "BEND_MAP_ID" : 1472,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1471",
        "source" : "387",
        "target" : "84",
        "EdgeBetweenness" : 103.76666666666667,
        "shared_name" : "Pinocchio (cut4) Sora",
        "shared_interaction" : "cut4",
        "name" : "Pinocchio (cut4) Sora",
        "interaction" : "cut4",
        "SUID" : 1471,
        "BEND_MAP_ID" : 1471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1470",
        "source" : "387",
        "target" : "253",
        "EdgeBetweenness" : 4.666666666666666,
        "shared_name" : "Pinocchio (cut4) Jiminy",
        "shared_interaction" : "cut4",
        "name" : "Pinocchio (cut4) Jiminy",
        "interaction" : "cut4",
        "SUID" : 1470,
        "BEND_MAP_ID" : 1470,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1469",
        "source" : "387",
        "target" : "253",
        "EdgeBetweenness" : 4.666666666666666,
        "shared_name" : "Pinocchio (cut3) Jiminy",
        "shared_interaction" : "cut3",
        "name" : "Pinocchio (cut3) Jiminy",
        "interaction" : "cut3",
        "SUID" : 1469,
        "BEND_MAP_ID" : 1469,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1468",
        "source" : "387",
        "target" : "253",
        "EdgeBetweenness" : 4.666666666666666,
        "shared_name" : "Pinocchio (cut2) Jiminy",
        "shared_interaction" : "cut2",
        "name" : "Pinocchio (cut2) Jiminy",
        "interaction" : "cut2",
        "SUID" : 1468,
        "BEND_MAP_ID" : 1468,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1467",
        "source" : "387",
        "target" : "253",
        "EdgeBetweenness" : 4.666666666666666,
        "shared_name" : "Pinocchio (cut1) Jiminy",
        "shared_interaction" : "cut1",
        "name" : "Pinocchio (cut1) Jiminy",
        "interaction" : "cut1",
        "SUID" : 1467,
        "BEND_MAP_ID" : 1467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1409",
        "source" : "361",
        "target" : "84",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Fairy Godmother (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Fairy Godmother (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1409,
        "BEND_MAP_ID" : 1409,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1408",
        "source" : "361",
        "target" : "84",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Fairy Godmother (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Fairy Godmother (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1408,
        "BEND_MAP_ID" : 1408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1402",
        "source" : "345",
        "target" : "106",
        "EdgeBetweenness" : 39.68205128205129,
        "shared_name" : "Sora, Donald & Goofy (cut1) Goofy",
        "shared_interaction" : "cut1",
        "name" : "Sora, Donald & Goofy (cut1) Goofy",
        "interaction" : "cut1",
        "SUID" : 1402,
        "BEND_MAP_ID" : 1402,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1401",
        "source" : "345",
        "target" : "114",
        "EdgeBetweenness" : 28.54871794871794,
        "shared_name" : "Sora, Donald & Goofy (cut1) Donald",
        "shared_interaction" : "cut1",
        "name" : "Sora, Donald & Goofy (cut1) Donald",
        "interaction" : "cut1",
        "SUID" : 1401,
        "BEND_MAP_ID" : 1401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1400",
        "source" : "345",
        "target" : "179",
        "EdgeBetweenness" : 3.2,
        "shared_name" : "Sora, Donald & Goofy (cut1) Aerith",
        "shared_interaction" : "cut1",
        "name" : "Sora, Donald & Goofy (cut1) Aerith",
        "interaction" : "cut1",
        "SUID" : 1400,
        "BEND_MAP_ID" : 1400,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1399",
        "source" : "345",
        "target" : "84",
        "EdgeBetweenness" : 88.7025641025641,
        "shared_name" : "Sora, Donald & Goofy (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Sora, Donald & Goofy (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1399,
        "BEND_MAP_ID" : 1399,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1398",
        "source" : "345",
        "target" : "175",
        "EdgeBetweenness" : 3.8666666666666667,
        "shared_name" : "Sora, Donald & Goofy (cut1) Leon",
        "shared_interaction" : "cut1",
        "name" : "Sora, Donald & Goofy (cut1) Leon",
        "interaction" : "cut1",
        "SUID" : 1398,
        "BEND_MAP_ID" : 1398,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1372",
        "source" : "328",
        "target" : "114",
        "EdgeBetweenness" : 32.34871794871795,
        "shared_name" : "Tarzan (cut13) Donald",
        "shared_interaction" : "cut13",
        "name" : "Tarzan (cut13) Donald",
        "interaction" : "cut13",
        "SUID" : 1372,
        "BEND_MAP_ID" : 1372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1371",
        "source" : "328",
        "target" : "117",
        "EdgeBetweenness" : 3.3333333333333335,
        "shared_name" : "Tarzan (cut13) Jane",
        "shared_interaction" : "cut13",
        "name" : "Tarzan (cut13) Jane",
        "interaction" : "cut13",
        "SUID" : 1371,
        "BEND_MAP_ID" : 1371,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1370",
        "source" : "328",
        "target" : "84",
        "EdgeBetweenness" : 87.8358974358974,
        "shared_name" : "Tarzan (cut13) Sora",
        "shared_interaction" : "cut13",
        "name" : "Tarzan (cut13) Sora",
        "interaction" : "cut13",
        "SUID" : 1370,
        "BEND_MAP_ID" : 1370,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1369",
        "source" : "328",
        "target" : "106",
        "EdgeBetweenness" : 42.482051282051295,
        "shared_name" : "Tarzan (cut12) Goofy",
        "shared_interaction" : "cut12",
        "name" : "Tarzan (cut12) Goofy",
        "interaction" : "cut12",
        "SUID" : 1369,
        "BEND_MAP_ID" : 1369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1368",
        "source" : "328",
        "target" : "114",
        "EdgeBetweenness" : 32.34871794871795,
        "shared_name" : "Tarzan (cut12) Donald",
        "shared_interaction" : "cut12",
        "name" : "Tarzan (cut12) Donald",
        "interaction" : "cut12",
        "SUID" : 1368,
        "BEND_MAP_ID" : 1368,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1367",
        "source" : "328",
        "target" : "84",
        "EdgeBetweenness" : 87.8358974358974,
        "shared_name" : "Tarzan (cut12) Sora",
        "shared_interaction" : "cut12",
        "name" : "Tarzan (cut12) Sora",
        "interaction" : "cut12",
        "SUID" : 1367,
        "BEND_MAP_ID" : 1367,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1366",
        "source" : "328",
        "target" : "117",
        "EdgeBetweenness" : 3.3333333333333335,
        "shared_name" : "Tarzan (cut12) Jane",
        "shared_interaction" : "cut12",
        "name" : "Tarzan (cut12) Jane",
        "interaction" : "cut12",
        "SUID" : 1366,
        "BEND_MAP_ID" : 1366,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1365",
        "source" : "328",
        "target" : "84",
        "EdgeBetweenness" : 87.8358974358974,
        "shared_name" : "Tarzan (cut9) Sora",
        "shared_interaction" : "cut9",
        "name" : "Tarzan (cut9) Sora",
        "interaction" : "cut9",
        "SUID" : 1365,
        "BEND_MAP_ID" : 1365,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1364",
        "source" : "328",
        "target" : "84",
        "EdgeBetweenness" : 87.8358974358974,
        "shared_name" : "Tarzan (cut8) Sora",
        "shared_interaction" : "cut8",
        "name" : "Tarzan (cut8) Sora",
        "interaction" : "cut8",
        "SUID" : 1364,
        "BEND_MAP_ID" : 1364,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1363",
        "source" : "328",
        "target" : "117",
        "EdgeBetweenness" : 3.3333333333333335,
        "shared_name" : "Tarzan (cut8) Jane",
        "shared_interaction" : "cut8",
        "name" : "Tarzan (cut8) Jane",
        "interaction" : "cut8",
        "SUID" : 1363,
        "BEND_MAP_ID" : 1363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1362",
        "source" : "328",
        "target" : "114",
        "EdgeBetweenness" : 32.34871794871795,
        "shared_name" : "Tarzan (cut7) Donald",
        "shared_interaction" : "cut7",
        "name" : "Tarzan (cut7) Donald",
        "interaction" : "cut7",
        "SUID" : 1362,
        "BEND_MAP_ID" : 1362,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1361",
        "source" : "328",
        "target" : "106",
        "EdgeBetweenness" : 42.482051282051295,
        "shared_name" : "Tarzan (cut7) Goofy",
        "shared_interaction" : "cut7",
        "name" : "Tarzan (cut7) Goofy",
        "interaction" : "cut7",
        "SUID" : 1361,
        "BEND_MAP_ID" : 1361,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1360",
        "source" : "328",
        "target" : "84",
        "EdgeBetweenness" : 87.8358974358974,
        "shared_name" : "Tarzan (cut7) Sora",
        "shared_interaction" : "cut7",
        "name" : "Tarzan (cut7) Sora",
        "interaction" : "cut7",
        "SUID" : 1360,
        "BEND_MAP_ID" : 1360,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1359",
        "source" : "328",
        "target" : "114",
        "EdgeBetweenness" : 32.34871794871795,
        "shared_name" : "Tarzan (cut6) Donald",
        "shared_interaction" : "cut6",
        "name" : "Tarzan (cut6) Donald",
        "interaction" : "cut6",
        "SUID" : 1359,
        "BEND_MAP_ID" : 1359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1358",
        "source" : "328",
        "target" : "114",
        "EdgeBetweenness" : 32.34871794871795,
        "shared_name" : "Tarzan (cut4) Donald",
        "shared_interaction" : "cut4",
        "name" : "Tarzan (cut4) Donald",
        "interaction" : "cut4",
        "SUID" : 1358,
        "BEND_MAP_ID" : 1358,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1357",
        "source" : "328",
        "target" : "106",
        "EdgeBetweenness" : 42.482051282051295,
        "shared_name" : "Tarzan (cut4) Goofy",
        "shared_interaction" : "cut4",
        "name" : "Tarzan (cut4) Goofy",
        "interaction" : "cut4",
        "SUID" : 1357,
        "BEND_MAP_ID" : 1357,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1356",
        "source" : "328",
        "target" : "325",
        "EdgeBetweenness" : 5.999999999999999,
        "shared_name" : "Tarzan (cut2) Clayton",
        "shared_interaction" : "cut2",
        "name" : "Tarzan (cut2) Clayton",
        "interaction" : "cut2",
        "SUID" : 1356,
        "BEND_MAP_ID" : 1356,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1355",
        "source" : "328",
        "target" : "117",
        "EdgeBetweenness" : 3.3333333333333335,
        "shared_name" : "Tarzan (cut2) Jane",
        "shared_interaction" : "cut2",
        "name" : "Tarzan (cut2) Jane",
        "interaction" : "cut2",
        "SUID" : 1355,
        "BEND_MAP_ID" : 1355,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1397",
        "source" : "325",
        "target" : "117",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "Clayton (cut7) Jane",
        "shared_interaction" : "cut7",
        "name" : "Clayton (cut7) Jane",
        "interaction" : "cut7",
        "SUID" : 1397,
        "BEND_MAP_ID" : 1397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1396",
        "source" : "325",
        "target" : "328",
        "EdgeBetweenness" : 5.999999999999999,
        "shared_name" : "Clayton (cut5) Tarzan",
        "shared_interaction" : "cut5",
        "name" : "Clayton (cut5) Tarzan",
        "interaction" : "cut5",
        "SUID" : 1396,
        "BEND_MAP_ID" : 1396,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1395",
        "source" : "325",
        "target" : "117",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "Clayton (cut5) Jane",
        "shared_interaction" : "cut5",
        "name" : "Clayton (cut5) Jane",
        "interaction" : "cut5",
        "SUID" : 1395,
        "BEND_MAP_ID" : 1395,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1394",
        "source" : "325",
        "target" : "117",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "Clayton (cut3) Jane",
        "shared_interaction" : "cut3",
        "name" : "Clayton (cut3) Jane",
        "interaction" : "cut3",
        "SUID" : 1394,
        "BEND_MAP_ID" : 1394,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1393",
        "source" : "325",
        "target" : "84",
        "EdgeBetweenness" : 150.00000000000003,
        "shared_name" : "Clayton (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Clayton (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1393,
        "BEND_MAP_ID" : 1393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1895",
        "source" : "317",
        "target" : "106",
        "EdgeBetweenness" : 53.41269841269842,
        "shared_name" : "Donald & Sora (cut1) Goofy",
        "shared_interaction" : "cut1",
        "name" : "Donald & Sora (cut1) Goofy",
        "interaction" : "cut1",
        "SUID" : 1895,
        "BEND_MAP_ID" : 1895,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1894",
        "source" : "317",
        "target" : "84",
        "EdgeBetweenness" : 104.92063492063492,
        "shared_name" : "Donald & Sora (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Donald & Sora (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1894,
        "BEND_MAP_ID" : 1894,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1893",
        "source" : "317",
        "target" : "117",
        "EdgeBetweenness" : 5.666666666666665,
        "shared_name" : "Donald & Sora (cut1) Jane",
        "shared_interaction" : "cut1",
        "name" : "Donald & Sora (cut1) Jane",
        "interaction" : "cut1",
        "SUID" : 1893,
        "BEND_MAP_ID" : 1893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1340",
        "source" : "302",
        "target" : "1339",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Cloud (cut9) Sephiroth",
        "shared_interaction" : "cut9",
        "name" : "Cloud (cut9) Sephiroth",
        "interaction" : "cut9",
        "SUID" : 1340,
        "BEND_MAP_ID" : 1340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1338",
        "source" : "302",
        "target" : "84",
        "EdgeBetweenness" : 298.6666666666667,
        "shared_name" : "Cloud (cut5) Sora",
        "shared_interaction" : "cut5",
        "name" : "Cloud (cut5) Sora",
        "interaction" : "cut5",
        "SUID" : 1338,
        "BEND_MAP_ID" : 1338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1337",
        "source" : "302",
        "target" : "84",
        "EdgeBetweenness" : 298.6666666666667,
        "shared_name" : "Cloud (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Cloud (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1337,
        "BEND_MAP_ID" : 1337,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1336",
        "source" : "302",
        "target" : "296",
        "EdgeBetweenness" : 25.333333333333336,
        "shared_name" : "Cloud (cut1) Hades",
        "shared_interaction" : "cut1",
        "name" : "Cloud (cut1) Hades",
        "interaction" : "cut1",
        "SUID" : 1336,
        "BEND_MAP_ID" : 1336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1335",
        "source" : "296",
        "target" : "98",
        "EdgeBetweenness" : 29.139460539460533,
        "shared_name" : "Hades (cut17) Maleficent",
        "shared_interaction" : "cut17",
        "name" : "Hades (cut17) Maleficent",
        "interaction" : "cut17",
        "SUID" : 1335,
        "BEND_MAP_ID" : 1335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1334",
        "source" : "296",
        "target" : "96",
        "EdgeBetweenness" : 20.913919413919412,
        "shared_name" : "Hades (cut17) Riku",
        "shared_interaction" : "cut17",
        "name" : "Hades (cut17) Riku",
        "interaction" : "cut17",
        "SUID" : 1334,
        "BEND_MAP_ID" : 1334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1333",
        "source" : "296",
        "target" : "89",
        "EdgeBetweenness" : 34.76931956931956,
        "shared_name" : "Hades (cut15) ??????????",
        "shared_interaction" : "cut15",
        "name" : "Hades (cut15) ??????????",
        "interaction" : "cut15",
        "SUID" : 1333,
        "BEND_MAP_ID" : 1333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1332",
        "source" : "296",
        "target" : "302",
        "EdgeBetweenness" : 25.333333333333336,
        "shared_name" : "Hades (cut6) Cloud",
        "shared_interaction" : "cut6",
        "name" : "Hades (cut6) Cloud",
        "interaction" : "cut6",
        "SUID" : 1332,
        "BEND_MAP_ID" : 1332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1331",
        "source" : "296",
        "target" : "84",
        "EdgeBetweenness" : 129.62123987123988,
        "shared_name" : "Hades (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Hades (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1331,
        "BEND_MAP_ID" : 1331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1330",
        "source" : "296",
        "target" : "114",
        "EdgeBetweenness" : 53.26568431568431,
        "shared_name" : "Hades (cut1) Donald",
        "shared_interaction" : "cut1",
        "name" : "Hades (cut1) Donald",
        "interaction" : "cut1",
        "SUID" : 1330,
        "BEND_MAP_ID" : 1330,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1329",
        "source" : "292",
        "target" : "443",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Philoctetes (cut33) Hercules",
        "shared_interaction" : "cut33",
        "name" : "Philoctetes (cut33) Hercules",
        "interaction" : "cut33",
        "SUID" : 1329,
        "BEND_MAP_ID" : 1329,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1328",
        "source" : "292",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Philoctetes (cut33) Sora",
        "shared_interaction" : "cut33",
        "name" : "Philoctetes (cut33) Sora",
        "interaction" : "cut33",
        "SUID" : 1328,
        "BEND_MAP_ID" : 1328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1327",
        "source" : "292",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Philoctetes (cut32) Sora",
        "shared_interaction" : "cut32",
        "name" : "Philoctetes (cut32) Sora",
        "interaction" : "cut32",
        "SUID" : 1327,
        "BEND_MAP_ID" : 1327,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1326",
        "source" : "292",
        "target" : "443",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Philoctetes (cut32) Hercules",
        "shared_interaction" : "cut32",
        "name" : "Philoctetes (cut32) Hercules",
        "interaction" : "cut32",
        "SUID" : 1326,
        "BEND_MAP_ID" : 1326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1325",
        "source" : "292",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Philoctetes (cut31) Sora",
        "shared_interaction" : "cut31",
        "name" : "Philoctetes (cut31) Sora",
        "interaction" : "cut31",
        "SUID" : 1325,
        "BEND_MAP_ID" : 1325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1324",
        "source" : "292",
        "target" : "443",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Philoctetes (cut31) Hercules",
        "shared_interaction" : "cut31",
        "name" : "Philoctetes (cut31) Hercules",
        "interaction" : "cut31",
        "SUID" : 1324,
        "BEND_MAP_ID" : 1324,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1323",
        "source" : "292",
        "target" : "443",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Philoctetes (cut30) Hercules",
        "shared_interaction" : "cut30",
        "name" : "Philoctetes (cut30) Hercules",
        "interaction" : "cut30",
        "SUID" : 1323,
        "BEND_MAP_ID" : 1323,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1322",
        "source" : "292",
        "target" : "443",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Philoctetes (cut28) Hercules",
        "shared_interaction" : "cut28",
        "name" : "Philoctetes (cut28) Hercules",
        "interaction" : "cut28",
        "SUID" : 1322,
        "BEND_MAP_ID" : 1322,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1321",
        "source" : "292",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Philoctetes (cut27) Sora",
        "shared_interaction" : "cut27",
        "name" : "Philoctetes (cut27) Sora",
        "interaction" : "cut27",
        "SUID" : 1321,
        "BEND_MAP_ID" : 1321,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1320",
        "source" : "292",
        "target" : "443",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Philoctetes (cut25) Hercules",
        "shared_interaction" : "cut25",
        "name" : "Philoctetes (cut25) Hercules",
        "interaction" : "cut25",
        "SUID" : 1320,
        "BEND_MAP_ID" : 1320,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1319",
        "source" : "292",
        "target" : "106",
        "EdgeBetweenness" : 41.14871794871795,
        "shared_name" : "Philoctetes (cut25) Goofy",
        "shared_interaction" : "cut25",
        "name" : "Philoctetes (cut25) Goofy",
        "interaction" : "cut25",
        "SUID" : 1319,
        "BEND_MAP_ID" : 1319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1318",
        "source" : "292",
        "target" : "114",
        "EdgeBetweenness" : 30.348717948717933,
        "shared_name" : "Philoctetes (cut25) Donald",
        "shared_interaction" : "cut25",
        "name" : "Philoctetes (cut25) Donald",
        "interaction" : "cut25",
        "SUID" : 1318,
        "BEND_MAP_ID" : 1318,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1317",
        "source" : "292",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Philoctetes (cut23) Sora",
        "shared_interaction" : "cut23",
        "name" : "Philoctetes (cut23) Sora",
        "interaction" : "cut23",
        "SUID" : 1317,
        "BEND_MAP_ID" : 1317,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1316",
        "source" : "292",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Philoctetes (cut20) Sora",
        "shared_interaction" : "cut20",
        "name" : "Philoctetes (cut20) Sora",
        "interaction" : "cut20",
        "SUID" : 1316,
        "BEND_MAP_ID" : 1316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1315",
        "source" : "292",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Philoctetes (cut17) Sora",
        "shared_interaction" : "cut17",
        "name" : "Philoctetes (cut17) Sora",
        "interaction" : "cut17",
        "SUID" : 1315,
        "BEND_MAP_ID" : 1315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1314",
        "source" : "292",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Philoctetes (cut16) Sora",
        "shared_interaction" : "cut16",
        "name" : "Philoctetes (cut16) Sora",
        "interaction" : "cut16",
        "SUID" : 1314,
        "BEND_MAP_ID" : 1314,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1313",
        "source" : "292",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Philoctetes (cut15) Sora",
        "shared_interaction" : "cut15",
        "name" : "Philoctetes (cut15) Sora",
        "interaction" : "cut15",
        "SUID" : 1313,
        "BEND_MAP_ID" : 1313,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1312",
        "source" : "292",
        "target" : "84",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Philoctetes (cut10) Sora",
        "shared_interaction" : "cut10",
        "name" : "Philoctetes (cut10) Sora",
        "interaction" : "cut10",
        "SUID" : 1312,
        "BEND_MAP_ID" : 1312,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1311",
        "source" : "292",
        "target" : "114",
        "EdgeBetweenness" : 30.348717948717933,
        "shared_name" : "Philoctetes (cut5) Donald",
        "shared_interaction" : "cut5",
        "name" : "Philoctetes (cut5) Donald",
        "interaction" : "cut5",
        "SUID" : 1311,
        "BEND_MAP_ID" : 1311,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1310",
        "source" : "292",
        "target" : "106",
        "EdgeBetweenness" : 41.14871794871795,
        "shared_name" : "Philoctetes (cut5) Goofy",
        "shared_interaction" : "cut5",
        "name" : "Philoctetes (cut5) Goofy",
        "interaction" : "cut5",
        "SUID" : 1310,
        "BEND_MAP_ID" : 1310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1309",
        "source" : "292",
        "target" : "114",
        "EdgeBetweenness" : 30.348717948717933,
        "shared_name" : "Philoctetes (cut4) Donald",
        "shared_interaction" : "cut4",
        "name" : "Philoctetes (cut4) Donald",
        "interaction" : "cut4",
        "SUID" : 1309,
        "BEND_MAP_ID" : 1309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1308",
        "source" : "275",
        "target" : "84",
        "EdgeBetweenness" : 91.16923076923075,
        "shared_name" : "Cheshire Cat (cut7) Sora",
        "shared_interaction" : "cut7",
        "name" : "Cheshire Cat (cut7) Sora",
        "interaction" : "cut7",
        "SUID" : 1308,
        "BEND_MAP_ID" : 1308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1307",
        "source" : "275",
        "target" : "106",
        "EdgeBetweenness" : 41.815384615384616,
        "shared_name" : "Cheshire Cat (cut5) Goofy",
        "shared_interaction" : "cut5",
        "name" : "Cheshire Cat (cut5) Goofy",
        "interaction" : "cut5",
        "SUID" : 1307,
        "BEND_MAP_ID" : 1307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1306",
        "source" : "275",
        "target" : "84",
        "EdgeBetweenness" : 91.16923076923075,
        "shared_name" : "Cheshire Cat (cut5) Sora",
        "shared_interaction" : "cut5",
        "name" : "Cheshire Cat (cut5) Sora",
        "interaction" : "cut5",
        "SUID" : 1306,
        "BEND_MAP_ID" : 1306,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1305",
        "source" : "275",
        "target" : "84",
        "EdgeBetweenness" : 91.16923076923075,
        "shared_name" : "Cheshire Cat (cut4) Sora",
        "shared_interaction" : "cut4",
        "name" : "Cheshire Cat (cut4) Sora",
        "interaction" : "cut4",
        "SUID" : 1305,
        "BEND_MAP_ID" : 1305,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1304",
        "source" : "275",
        "target" : "114",
        "EdgeBetweenness" : 31.015384615384598,
        "shared_name" : "Cheshire Cat (cut2) Donald",
        "shared_interaction" : "cut2",
        "name" : "Cheshire Cat (cut2) Donald",
        "interaction" : "cut2",
        "SUID" : 1304,
        "BEND_MAP_ID" : 1304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1303",
        "source" : "275",
        "target" : "84",
        "EdgeBetweenness" : 91.16923076923075,
        "shared_name" : "Cheshire Cat (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Cheshire Cat (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1303,
        "BEND_MAP_ID" : 1303,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1302",
        "source" : "275",
        "target" : "84",
        "EdgeBetweenness" : 91.16923076923075,
        "shared_name" : "Cheshire Cat (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Cheshire Cat (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1302,
        "BEND_MAP_ID" : 1302,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1301",
        "source" : "275",
        "target" : "114",
        "EdgeBetweenness" : 31.015384615384598,
        "shared_name" : "Cheshire Cat (cut1) Donald",
        "shared_interaction" : "cut1",
        "name" : "Cheshire Cat (cut1) Donald",
        "interaction" : "cut1",
        "SUID" : 1301,
        "BEND_MAP_ID" : 1301,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1300",
        "source" : "272",
        "target" : "84",
        "EdgeBetweenness" : 85.33589743589742,
        "shared_name" : "Card Soldier (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Card Soldier (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1300,
        "BEND_MAP_ID" : 1300,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1299",
        "source" : "272",
        "target" : "114",
        "EdgeBetweenness" : 29.515384615384598,
        "shared_name" : "Card Soldier (cut1) Donald",
        "shared_interaction" : "cut1",
        "name" : "Card Soldier (cut1) Donald",
        "interaction" : "cut1",
        "SUID" : 1299,
        "BEND_MAP_ID" : 1299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1298",
        "source" : "272",
        "target" : "106",
        "EdgeBetweenness" : 39.98205128205128,
        "shared_name" : "Card Soldier (cut1) Goofy",
        "shared_interaction" : "cut1",
        "name" : "Card Soldier (cut1) Goofy",
        "interaction" : "cut1",
        "SUID" : 1298,
        "BEND_MAP_ID" : 1298,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1297",
        "source" : "272",
        "target" : "84",
        "EdgeBetweenness" : 85.33589743589742,
        "shared_name" : "Card Soldier (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Card Soldier (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1297,
        "BEND_MAP_ID" : 1297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1296",
        "source" : "272",
        "target" : "265",
        "EdgeBetweenness" : 9.166666666666668,
        "shared_name" : "Card Soldier (cut1) Alice",
        "shared_interaction" : "cut1",
        "name" : "Card Soldier (cut1) Alice",
        "interaction" : "cut1",
        "SUID" : 1296,
        "BEND_MAP_ID" : 1296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1283",
        "source" : "265",
        "target" : "120",
        "EdgeBetweenness" : 10.752380952380951,
        "shared_name" : "Alice (cut10) Jasmine",
        "shared_interaction" : "cut10",
        "name" : "Alice (cut10) Jasmine",
        "interaction" : "cut10",
        "SUID" : 1283,
        "BEND_MAP_ID" : 1283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1282",
        "source" : "265",
        "target" : "558",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Alice (cut10) Aurora",
        "shared_interaction" : "cut10",
        "name" : "Alice (cut10) Aurora",
        "interaction" : "cut10",
        "SUID" : 1282,
        "BEND_MAP_ID" : 1282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1281",
        "source" : "265",
        "target" : "562",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Alice (cut10) Snow White",
        "shared_interaction" : "cut10",
        "name" : "Alice (cut10) Snow White",
        "interaction" : "cut10",
        "SUID" : 1281,
        "BEND_MAP_ID" : 1281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1280",
        "source" : "265",
        "target" : "556",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Alice (cut10) Cinderella",
        "shared_interaction" : "cut10",
        "name" : "Alice (cut10) Cinderella",
        "interaction" : "cut10",
        "SUID" : 1280,
        "BEND_MAP_ID" : 1280,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1279",
        "source" : "265",
        "target" : "120",
        "EdgeBetweenness" : 10.752380952380951,
        "shared_name" : "Alice (cut9) Jasmine",
        "shared_interaction" : "cut9",
        "name" : "Alice (cut9) Jasmine",
        "interaction" : "cut9",
        "SUID" : 1279,
        "BEND_MAP_ID" : 1279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1278",
        "source" : "265",
        "target" : "581",
        "EdgeBetweenness" : 10.933333333333334,
        "shared_name" : "Alice (cut9) Snow Whtie",
        "shared_interaction" : "cut9",
        "name" : "Alice (cut9) Snow Whtie",
        "interaction" : "cut9",
        "SUID" : 1278,
        "BEND_MAP_ID" : 1278,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1277",
        "source" : "265",
        "target" : "556",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Alice (cut9) Cinderella",
        "shared_interaction" : "cut9",
        "name" : "Alice (cut9) Cinderella",
        "interaction" : "cut9",
        "SUID" : 1277,
        "BEND_MAP_ID" : 1277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1276",
        "source" : "265",
        "target" : "84",
        "EdgeBetweenness" : 158.5619047619048,
        "shared_name" : "Alice (cut9) Sora",
        "shared_interaction" : "cut9",
        "name" : "Alice (cut9) Sora",
        "interaction" : "cut9",
        "SUID" : 1276,
        "BEND_MAP_ID" : 1276,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1275",
        "source" : "265",
        "target" : "558",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Alice (cut9) Aurora",
        "shared_interaction" : "cut9",
        "name" : "Alice (cut9) Aurora",
        "interaction" : "cut9",
        "SUID" : 1275,
        "BEND_MAP_ID" : 1275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1274",
        "source" : "265",
        "target" : "562",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Alice (cut9) Snow White",
        "shared_interaction" : "cut9",
        "name" : "Alice (cut9) Snow White",
        "interaction" : "cut9",
        "SUID" : 1274,
        "BEND_MAP_ID" : 1274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1273",
        "source" : "265",
        "target" : "556",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Alice (cut8) Cinderella",
        "shared_interaction" : "cut8",
        "name" : "Alice (cut8) Cinderella",
        "interaction" : "cut8",
        "SUID" : 1273,
        "BEND_MAP_ID" : 1273,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1272",
        "source" : "265",
        "target" : "84",
        "EdgeBetweenness" : 158.5619047619048,
        "shared_name" : "Alice (cut8) Sora",
        "shared_interaction" : "cut8",
        "name" : "Alice (cut8) Sora",
        "interaction" : "cut8",
        "SUID" : 1272,
        "BEND_MAP_ID" : 1272,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1271",
        "source" : "265",
        "target" : "558",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Alice (cut8) Aurora",
        "shared_interaction" : "cut8",
        "name" : "Alice (cut8) Aurora",
        "interaction" : "cut8",
        "SUID" : 1271,
        "BEND_MAP_ID" : 1271,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1270",
        "source" : "265",
        "target" : "120",
        "EdgeBetweenness" : 10.752380952380951,
        "shared_name" : "Alice (cut8) Jasmine",
        "shared_interaction" : "cut8",
        "name" : "Alice (cut8) Jasmine",
        "interaction" : "cut8",
        "SUID" : 1270,
        "BEND_MAP_ID" : 1270,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1269",
        "source" : "265",
        "target" : "556",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Alice (cut7) Cinderella",
        "shared_interaction" : "cut7",
        "name" : "Alice (cut7) Cinderella",
        "interaction" : "cut7",
        "SUID" : 1269,
        "BEND_MAP_ID" : 1269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1268",
        "source" : "265",
        "target" : "558",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Alice (cut7) Aurora",
        "shared_interaction" : "cut7",
        "name" : "Alice (cut7) Aurora",
        "interaction" : "cut7",
        "SUID" : 1268,
        "BEND_MAP_ID" : 1268,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1267",
        "source" : "265",
        "target" : "84",
        "EdgeBetweenness" : 158.5619047619048,
        "shared_name" : "Alice (cut7) Sora",
        "shared_interaction" : "cut7",
        "name" : "Alice (cut7) Sora",
        "interaction" : "cut7",
        "SUID" : 1267,
        "BEND_MAP_ID" : 1267,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1266",
        "source" : "265",
        "target" : "562",
        "EdgeBetweenness" : 10.933333333333335,
        "shared_name" : "Alice (cut7) Snow White",
        "shared_interaction" : "cut7",
        "name" : "Alice (cut7) Snow White",
        "interaction" : "cut7",
        "SUID" : 1266,
        "BEND_MAP_ID" : 1266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1265",
        "source" : "265",
        "target" : "120",
        "EdgeBetweenness" : 10.752380952380951,
        "shared_name" : "Alice (cut7) Jasmine",
        "shared_interaction" : "cut7",
        "name" : "Alice (cut7) Jasmine",
        "interaction" : "cut7",
        "SUID" : 1265,
        "BEND_MAP_ID" : 1265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1264",
        "source" : "265",
        "target" : "272",
        "EdgeBetweenness" : 9.166666666666668,
        "shared_name" : "Alice (cut6) Card Soldier",
        "shared_interaction" : "cut6",
        "name" : "Alice (cut6) Card Soldier",
        "interaction" : "cut6",
        "SUID" : 1264,
        "BEND_MAP_ID" : 1264,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1263",
        "source" : "265",
        "target" : "114",
        "EdgeBetweenness" : 68.94285714285712,
        "shared_name" : "Alice (cut6) Donald",
        "shared_interaction" : "cut6",
        "name" : "Alice (cut6) Donald",
        "interaction" : "cut6",
        "SUID" : 1263,
        "BEND_MAP_ID" : 1263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1262",
        "source" : "265",
        "target" : "106",
        "EdgeBetweenness" : 84.40952380952379,
        "shared_name" : "Alice (cut6) Goofy",
        "shared_interaction" : "cut6",
        "name" : "Alice (cut6) Goofy",
        "interaction" : "cut6",
        "SUID" : 1262,
        "BEND_MAP_ID" : 1262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1261",
        "source" : "265",
        "target" : "84",
        "EdgeBetweenness" : 158.5619047619048,
        "shared_name" : "Alice (cut6) Sora",
        "shared_interaction" : "cut6",
        "name" : "Alice (cut6) Sora",
        "interaction" : "cut6",
        "SUID" : 1261,
        "BEND_MAP_ID" : 1261,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1260",
        "source" : "265",
        "target" : "84",
        "EdgeBetweenness" : 158.5619047619048,
        "shared_name" : "Alice (cut5) Sora",
        "shared_interaction" : "cut5",
        "name" : "Alice (cut5) Sora",
        "interaction" : "cut5",
        "SUID" : 1260,
        "BEND_MAP_ID" : 1260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1259",
        "source" : "265",
        "target" : "263",
        "EdgeBetweenness" : 9.166666666666668,
        "shared_name" : "Alice (cut3) Queen of Hearts",
        "shared_interaction" : "cut3",
        "name" : "Alice (cut3) Queen of Hearts",
        "interaction" : "cut3",
        "SUID" : 1259,
        "BEND_MAP_ID" : 1259,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1258",
        "source" : "265",
        "target" : "263",
        "EdgeBetweenness" : 9.166666666666668,
        "shared_name" : "Alice (cut2) Queen of Hearts",
        "shared_interaction" : "cut2",
        "name" : "Alice (cut2) Queen of Hearts",
        "interaction" : "cut2",
        "SUID" : 1258,
        "BEND_MAP_ID" : 1258,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1257",
        "source" : "265",
        "target" : "1252",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Alice (cut1) White Rabbit",
        "shared_interaction" : "cut1",
        "name" : "Alice (cut1) White Rabbit",
        "interaction" : "cut1",
        "SUID" : 1257,
        "BEND_MAP_ID" : 1257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1295",
        "source" : "263",
        "target" : "114",
        "EdgeBetweenness" : 29.515384615384594,
        "shared_name" : "Queen of Hearts (cut20) Donald",
        "shared_interaction" : "cut20",
        "name" : "Queen of Hearts (cut20) Donald",
        "interaction" : "cut20",
        "SUID" : 1295,
        "BEND_MAP_ID" : 1295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1294",
        "source" : "263",
        "target" : "114",
        "EdgeBetweenness" : 29.515384615384594,
        "shared_name" : "Queen of Hearts (cut16) Donald",
        "shared_interaction" : "cut16",
        "name" : "Queen of Hearts (cut16) Donald",
        "interaction" : "cut16",
        "SUID" : 1294,
        "BEND_MAP_ID" : 1294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1293",
        "source" : "263",
        "target" : "84",
        "EdgeBetweenness" : 85.33589743589744,
        "shared_name" : "Queen of Hearts (cut15) Sora",
        "shared_interaction" : "cut15",
        "name" : "Queen of Hearts (cut15) Sora",
        "interaction" : "cut15",
        "SUID" : 1293,
        "BEND_MAP_ID" : 1293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1292",
        "source" : "263",
        "target" : "84",
        "EdgeBetweenness" : 85.33589743589744,
        "shared_name" : "Queen of Hearts (cut14) Sora",
        "shared_interaction" : "cut14",
        "name" : "Queen of Hearts (cut14) Sora",
        "interaction" : "cut14",
        "SUID" : 1292,
        "BEND_MAP_ID" : 1292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1291",
        "source" : "263",
        "target" : "84",
        "EdgeBetweenness" : 85.33589743589744,
        "shared_name" : "Queen of Hearts (cut13) Sora",
        "shared_interaction" : "cut13",
        "name" : "Queen of Hearts (cut13) Sora",
        "interaction" : "cut13",
        "SUID" : 1291,
        "BEND_MAP_ID" : 1291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1290",
        "source" : "263",
        "target" : "106",
        "EdgeBetweenness" : 39.98205128205127,
        "shared_name" : "Queen of Hearts (cut8) Goofy",
        "shared_interaction" : "cut8",
        "name" : "Queen of Hearts (cut8) Goofy",
        "interaction" : "cut8",
        "SUID" : 1290,
        "BEND_MAP_ID" : 1290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1289",
        "source" : "263",
        "target" : "84",
        "EdgeBetweenness" : 85.33589743589744,
        "shared_name" : "Queen of Hearts (cut8) Sora",
        "shared_interaction" : "cut8",
        "name" : "Queen of Hearts (cut8) Sora",
        "interaction" : "cut8",
        "SUID" : 1289,
        "BEND_MAP_ID" : 1289,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1288",
        "source" : "263",
        "target" : "106",
        "EdgeBetweenness" : 39.98205128205127,
        "shared_name" : "Queen of Hearts (cut4) Goofy",
        "shared_interaction" : "cut4",
        "name" : "Queen of Hearts (cut4) Goofy",
        "interaction" : "cut4",
        "SUID" : 1288,
        "BEND_MAP_ID" : 1288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1287",
        "source" : "263",
        "target" : "114",
        "EdgeBetweenness" : 29.515384615384594,
        "shared_name" : "Queen of Hearts (cut4) Donald",
        "shared_interaction" : "cut4",
        "name" : "Queen of Hearts (cut4) Donald",
        "interaction" : "cut4",
        "SUID" : 1287,
        "BEND_MAP_ID" : 1287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1286",
        "source" : "263",
        "target" : "84",
        "EdgeBetweenness" : 85.33589743589744,
        "shared_name" : "Queen of Hearts (cut4) Sora",
        "shared_interaction" : "cut4",
        "name" : "Queen of Hearts (cut4) Sora",
        "interaction" : "cut4",
        "SUID" : 1286,
        "BEND_MAP_ID" : 1286,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1285",
        "source" : "263",
        "target" : "265",
        "EdgeBetweenness" : 9.166666666666668,
        "shared_name" : "Queen of Hearts (cut2) Alice",
        "shared_interaction" : "cut2",
        "name" : "Queen of Hearts (cut2) Alice",
        "interaction" : "cut2",
        "SUID" : 1285,
        "BEND_MAP_ID" : 1285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1284",
        "source" : "263",
        "target" : "265",
        "EdgeBetweenness" : 9.166666666666668,
        "shared_name" : "Queen of Hearts (cut1) Alice",
        "shared_interaction" : "cut1",
        "name" : "Queen of Hearts (cut1) Alice",
        "interaction" : "cut1",
        "SUID" : 1284,
        "BEND_MAP_ID" : 1284,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1256",
        "source" : "258",
        "target" : "84",
        "EdgeBetweenness" : 108.25396825396825,
        "shared_name" : "Doorknob (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Doorknob (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1256,
        "BEND_MAP_ID" : 1256,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1255",
        "source" : "258",
        "target" : "106",
        "EdgeBetweenness" : 55.74603174603175,
        "shared_name" : "Doorknob (cut2) Goofy",
        "shared_interaction" : "cut2",
        "name" : "Doorknob (cut2) Goofy",
        "interaction" : "cut2",
        "SUID" : 1255,
        "BEND_MAP_ID" : 1255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1254",
        "source" : "258",
        "target" : "84",
        "EdgeBetweenness" : 108.25396825396825,
        "shared_name" : "Doorknob (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Doorknob (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1254,
        "BEND_MAP_ID" : 1254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1098",
        "source" : "253",
        "target" : "387",
        "EdgeBetweenness" : 4.666666666666666,
        "shared_name" : "Jiminy (cut14) Pinocchio",
        "shared_interaction" : "cut14",
        "name" : "Jiminy (cut14) Pinocchio",
        "interaction" : "cut14",
        "SUID" : 1098,
        "BEND_MAP_ID" : 1098,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1097",
        "source" : "253",
        "target" : "96",
        "EdgeBetweenness" : 13.947252747252747,
        "shared_name" : "Jiminy (cut14) Riku",
        "shared_interaction" : "cut14",
        "name" : "Jiminy (cut14) Riku",
        "interaction" : "cut14",
        "SUID" : 1097,
        "BEND_MAP_ID" : 1097,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1096",
        "source" : "253",
        "target" : "84",
        "EdgeBetweenness" : 82.72014652014653,
        "shared_name" : "Jiminy (cut14) Sora",
        "shared_interaction" : "cut14",
        "name" : "Jiminy (cut14) Sora",
        "interaction" : "cut14",
        "SUID" : 1096,
        "BEND_MAP_ID" : 1096,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1095",
        "source" : "253",
        "target" : "106",
        "EdgeBetweenness" : 38.23296703296703,
        "shared_name" : "Jiminy (cut11) Goofy",
        "shared_interaction" : "cut11",
        "name" : "Jiminy (cut11) Goofy",
        "interaction" : "cut11",
        "SUID" : 1095,
        "BEND_MAP_ID" : 1095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1094",
        "source" : "253",
        "target" : "84",
        "EdgeBetweenness" : 82.72014652014653,
        "shared_name" : "Jiminy (cut10) Sora",
        "shared_interaction" : "cut10",
        "name" : "Jiminy (cut10) Sora",
        "interaction" : "cut10",
        "SUID" : 1094,
        "BEND_MAP_ID" : 1094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1093",
        "source" : "253",
        "target" : "84",
        "EdgeBetweenness" : 82.72014652014653,
        "shared_name" : "Jiminy (cut9) Sora",
        "shared_interaction" : "cut9",
        "name" : "Jiminy (cut9) Sora",
        "interaction" : "cut9",
        "SUID" : 1093,
        "BEND_MAP_ID" : 1093,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1092",
        "source" : "253",
        "target" : "387",
        "EdgeBetweenness" : 4.666666666666666,
        "shared_name" : "Jiminy (cut9) Pinocchio",
        "shared_interaction" : "cut9",
        "name" : "Jiminy (cut9) Pinocchio",
        "interaction" : "cut9",
        "SUID" : 1092,
        "BEND_MAP_ID" : 1092,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1091",
        "source" : "253",
        "target" : "387",
        "EdgeBetweenness" : 4.666666666666666,
        "shared_name" : "Jiminy (cut8) Pinocchio",
        "shared_interaction" : "cut8",
        "name" : "Jiminy (cut8) Pinocchio",
        "interaction" : "cut8",
        "SUID" : 1091,
        "BEND_MAP_ID" : 1091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1090",
        "source" : "253",
        "target" : "387",
        "EdgeBetweenness" : 4.666666666666666,
        "shared_name" : "Jiminy (cut7) Pinocchio",
        "shared_interaction" : "cut7",
        "name" : "Jiminy (cut7) Pinocchio",
        "interaction" : "cut7",
        "SUID" : 1090,
        "BEND_MAP_ID" : 1090,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1089",
        "source" : "253",
        "target" : "387",
        "EdgeBetweenness" : 4.666666666666666,
        "shared_name" : "Jiminy (cut4) Pinocchio",
        "shared_interaction" : "cut4",
        "name" : "Jiminy (cut4) Pinocchio",
        "interaction" : "cut4",
        "SUID" : 1089,
        "BEND_MAP_ID" : 1089,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1088",
        "source" : "253",
        "target" : "114",
        "EdgeBetweenness" : 26.432967032967017,
        "shared_name" : "Jiminy (cut2) Donald",
        "shared_interaction" : "cut2",
        "name" : "Jiminy (cut2) Donald",
        "interaction" : "cut2",
        "SUID" : 1088,
        "BEND_MAP_ID" : 1088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1087",
        "source" : "253",
        "target" : "84",
        "EdgeBetweenness" : 82.72014652014653,
        "shared_name" : "Jiminy (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Jiminy (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1087,
        "BEND_MAP_ID" : 1087,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1086",
        "source" : "253",
        "target" : "106",
        "EdgeBetweenness" : 38.23296703296703,
        "shared_name" : "Jiminy (cut2) Goofy",
        "shared_interaction" : "cut2",
        "name" : "Jiminy (cut2) Goofy",
        "interaction" : "cut2",
        "SUID" : 1086,
        "BEND_MAP_ID" : 1086,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1085",
        "source" : "253",
        "target" : "114",
        "EdgeBetweenness" : 26.432967032967017,
        "shared_name" : "Jiminy (cut1) Donald",
        "shared_interaction" : "cut1",
        "name" : "Jiminy (cut1) Donald",
        "interaction" : "cut1",
        "SUID" : 1085,
        "BEND_MAP_ID" : 1085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1084",
        "source" : "253",
        "target" : "106",
        "EdgeBetweenness" : 38.23296703296703,
        "shared_name" : "Jiminy (cut1) Goofy",
        "shared_interaction" : "cut1",
        "name" : "Jiminy (cut1) Goofy",
        "interaction" : "cut1",
        "SUID" : 1084,
        "BEND_MAP_ID" : 1084,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1083",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut35) Sora",
        "shared_interaction" : "cut35",
        "name" : "?????? (cut35) Sora",
        "interaction" : "cut35",
        "SUID" : 1083,
        "BEND_MAP_ID" : 1083,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1082",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut33) Sora",
        "shared_interaction" : "cut33",
        "name" : "?????? (cut33) Sora",
        "interaction" : "cut33",
        "SUID" : 1082,
        "BEND_MAP_ID" : 1082,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1081",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut29) Sora",
        "shared_interaction" : "cut29",
        "name" : "?????? (cut29) Sora",
        "interaction" : "cut29",
        "SUID" : 1081,
        "BEND_MAP_ID" : 1081,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1080",
        "source" : "222",
        "target" : "106",
        "EdgeBetweenness" : 54.951004551004544,
        "shared_name" : "?????? (cut28) Goofy",
        "shared_interaction" : "cut28",
        "name" : "?????? (cut28) Goofy",
        "interaction" : "cut28",
        "SUID" : 1080,
        "BEND_MAP_ID" : 1080,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1079",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut28) Sora",
        "shared_interaction" : "cut28",
        "name" : "?????? (cut28) Sora",
        "interaction" : "cut28",
        "SUID" : 1079,
        "BEND_MAP_ID" : 1079,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1078",
        "source" : "222",
        "target" : "94",
        "EdgeBetweenness" : 17.82886002886003,
        "shared_name" : "?????? (cut26) Pooh",
        "shared_interaction" : "cut26",
        "name" : "?????? (cut26) Pooh",
        "interaction" : "cut26",
        "SUID" : 1078,
        "BEND_MAP_ID" : 1078,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1077",
        "source" : "222",
        "target" : "94",
        "EdgeBetweenness" : 17.82886002886003,
        "shared_name" : "?????? (cut25) Pooh",
        "shared_interaction" : "cut25",
        "name" : "?????? (cut25) Pooh",
        "interaction" : "cut25",
        "SUID" : 1077,
        "BEND_MAP_ID" : 1077,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1076",
        "source" : "222",
        "target" : "412",
        "EdgeBetweenness" : 17.165367965367967,
        "shared_name" : "?????? (cut25) Piglet",
        "shared_interaction" : "cut25",
        "name" : "?????? (cut25) Piglet",
        "interaction" : "cut25",
        "SUID" : 1076,
        "BEND_MAP_ID" : 1076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1075",
        "source" : "222",
        "target" : "133",
        "EdgeBetweenness" : 6.311111111111111,
        "shared_name" : "?????? (cut21) Merlin",
        "shared_interaction" : "cut21",
        "name" : "?????? (cut21) Merlin",
        "interaction" : "cut21",
        "SUID" : 1075,
        "BEND_MAP_ID" : 1075,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1074",
        "source" : "222",
        "target" : "106",
        "EdgeBetweenness" : 54.951004551004544,
        "shared_name" : "?????? (cut21) Goofy",
        "shared_interaction" : "cut21",
        "name" : "?????? (cut21) Goofy",
        "interaction" : "cut21",
        "SUID" : 1074,
        "BEND_MAP_ID" : 1074,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1073",
        "source" : "222",
        "target" : "114",
        "EdgeBetweenness" : 43.45814740814741,
        "shared_name" : "?????? (cut21) Donald",
        "shared_interaction" : "cut21",
        "name" : "?????? (cut21) Donald",
        "interaction" : "cut21",
        "SUID" : 1073,
        "BEND_MAP_ID" : 1073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1072",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut21) Sora",
        "shared_interaction" : "cut21",
        "name" : "?????? (cut21) Sora",
        "interaction" : "cut21",
        "SUID" : 1072,
        "BEND_MAP_ID" : 1072,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1071",
        "source" : "222",
        "target" : "89",
        "EdgeBetweenness" : 43.63786213786214,
        "shared_name" : "?????? (cut19) ??????????",
        "shared_interaction" : "cut19",
        "name" : "?????? (cut19) ??????????",
        "interaction" : "cut19",
        "SUID" : 1071,
        "BEND_MAP_ID" : 1071,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1070",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut18) Sora",
        "shared_interaction" : "cut18",
        "name" : "?????? (cut18) Sora",
        "interaction" : "cut18",
        "SUID" : 1070,
        "BEND_MAP_ID" : 1070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1069",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut17) Sora",
        "shared_interaction" : "cut17",
        "name" : "?????? (cut17) Sora",
        "interaction" : "cut17",
        "SUID" : 1069,
        "BEND_MAP_ID" : 1069,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1068",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut16) Sora",
        "shared_interaction" : "cut16",
        "name" : "?????? (cut16) Sora",
        "interaction" : "cut16",
        "SUID" : 1068,
        "BEND_MAP_ID" : 1068,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1067",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut15) Sora",
        "shared_interaction" : "cut15",
        "name" : "?????? (cut15) Sora",
        "interaction" : "cut15",
        "SUID" : 1067,
        "BEND_MAP_ID" : 1067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1066",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut14) Sora",
        "shared_interaction" : "cut14",
        "name" : "?????? (cut14) Sora",
        "interaction" : "cut14",
        "SUID" : 1066,
        "BEND_MAP_ID" : 1066,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1065",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut13) Sora",
        "shared_interaction" : "cut13",
        "name" : "?????? (cut13) Sora",
        "interaction" : "cut13",
        "SUID" : 1065,
        "BEND_MAP_ID" : 1065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1064",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut12) Sora",
        "shared_interaction" : "cut12",
        "name" : "?????? (cut12) Sora",
        "interaction" : "cut12",
        "SUID" : 1064,
        "BEND_MAP_ID" : 1064,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1063",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut9) Sora",
        "shared_interaction" : "cut9",
        "name" : "?????? (cut9) Sora",
        "interaction" : "cut9",
        "SUID" : 1063,
        "BEND_MAP_ID" : 1063,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1062",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut6) Sora",
        "shared_interaction" : "cut6",
        "name" : "?????? (cut6) Sora",
        "interaction" : "cut6",
        "SUID" : 1062,
        "BEND_MAP_ID" : 1062,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1061",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut5) Sora",
        "shared_interaction" : "cut5",
        "name" : "?????? (cut5) Sora",
        "interaction" : "cut5",
        "SUID" : 1061,
        "BEND_MAP_ID" : 1061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1060",
        "source" : "222",
        "target" : "84",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "?????? (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "?????? (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1060,
        "BEND_MAP_ID" : 1060,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1116",
        "source" : "220",
        "target" : "84",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Cid (cut17) Sora",
        "shared_interaction" : "cut17",
        "name" : "Cid (cut17) Sora",
        "interaction" : "cut17",
        "SUID" : 1116,
        "BEND_MAP_ID" : 1116,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1115",
        "source" : "220",
        "target" : "84",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Cid (cut12) Sora",
        "shared_interaction" : "cut12",
        "name" : "Cid (cut12) Sora",
        "interaction" : "cut12",
        "SUID" : 1115,
        "BEND_MAP_ID" : 1115,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1114",
        "source" : "220",
        "target" : "177",
        "EdgeBetweenness" : 2.3333333333333335,
        "shared_name" : "Cid (cut9) Yuffie",
        "shared_interaction" : "cut9",
        "name" : "Cid (cut9) Yuffie",
        "interaction" : "cut9",
        "SUID" : 1114,
        "BEND_MAP_ID" : 1114,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1113",
        "source" : "220",
        "target" : "84",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Cid (cut9) Sora",
        "shared_interaction" : "cut9",
        "name" : "Cid (cut9) Sora",
        "interaction" : "cut9",
        "SUID" : 1113,
        "BEND_MAP_ID" : 1113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1112",
        "source" : "220",
        "target" : "179",
        "EdgeBetweenness" : 2.7333333333333334,
        "shared_name" : "Cid (cut9) Aerith",
        "shared_interaction" : "cut9",
        "name" : "Cid (cut9) Aerith",
        "interaction" : "cut9",
        "SUID" : 1112,
        "BEND_MAP_ID" : 1112,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1111",
        "source" : "220",
        "target" : "114",
        "EdgeBetweenness" : 28.082051282051275,
        "shared_name" : "Cid (cut8) Donald",
        "shared_interaction" : "cut8",
        "name" : "Cid (cut8) Donald",
        "interaction" : "cut8",
        "SUID" : 1111,
        "BEND_MAP_ID" : 1111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1110",
        "source" : "220",
        "target" : "179",
        "EdgeBetweenness" : 2.7333333333333334,
        "shared_name" : "Cid (cut8) Aerith",
        "shared_interaction" : "cut8",
        "name" : "Cid (cut8) Aerith",
        "interaction" : "cut8",
        "SUID" : 1110,
        "BEND_MAP_ID" : 1110,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1109",
        "source" : "220",
        "target" : "175",
        "EdgeBetweenness" : 3.4,
        "shared_name" : "Cid (cut8) Leon",
        "shared_interaction" : "cut8",
        "name" : "Cid (cut8) Leon",
        "interaction" : "cut8",
        "SUID" : 1109,
        "BEND_MAP_ID" : 1109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1108",
        "source" : "220",
        "target" : "84",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Cid (cut8) Sora",
        "shared_interaction" : "cut8",
        "name" : "Cid (cut8) Sora",
        "interaction" : "cut8",
        "SUID" : 1108,
        "BEND_MAP_ID" : 1108,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1107",
        "source" : "220",
        "target" : "84",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Cid (cut6) Sora",
        "shared_interaction" : "cut6",
        "name" : "Cid (cut6) Sora",
        "interaction" : "cut6",
        "SUID" : 1107,
        "BEND_MAP_ID" : 1107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1106",
        "source" : "220",
        "target" : "84",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Cid (cut5) Sora",
        "shared_interaction" : "cut5",
        "name" : "Cid (cut5) Sora",
        "interaction" : "cut5",
        "SUID" : 1106,
        "BEND_MAP_ID" : 1106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1105",
        "source" : "220",
        "target" : "84",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Cid (cut4) Sora",
        "shared_interaction" : "cut4",
        "name" : "Cid (cut4) Sora",
        "interaction" : "cut4",
        "SUID" : 1105,
        "BEND_MAP_ID" : 1105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1104",
        "source" : "220",
        "target" : "84",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Cid (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Cid (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1104,
        "BEND_MAP_ID" : 1104,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1103",
        "source" : "220",
        "target" : "106",
        "EdgeBetweenness" : 39.21538461538462,
        "shared_name" : "Cid (cut3) Goofy",
        "shared_interaction" : "cut3",
        "name" : "Cid (cut3) Goofy",
        "interaction" : "cut3",
        "SUID" : 1103,
        "BEND_MAP_ID" : 1103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1102",
        "source" : "220",
        "target" : "114",
        "EdgeBetweenness" : 28.082051282051275,
        "shared_name" : "Cid (cut3) Donald",
        "shared_interaction" : "cut3",
        "name" : "Cid (cut3) Donald",
        "interaction" : "cut3",
        "SUID" : 1102,
        "BEND_MAP_ID" : 1102,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1101",
        "source" : "220",
        "target" : "84",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Cid (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Cid (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1101,
        "BEND_MAP_ID" : 1101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1100",
        "source" : "217",
        "target" : "84",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "??? (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "??? (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1100,
        "BEND_MAP_ID" : 1100,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1099",
        "source" : "217",
        "target" : "84",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "??? (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "??? (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1099,
        "BEND_MAP_ID" : 1099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1242",
        "source" : "179",
        "target" : "84",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Aerith (cut23) Sora",
        "shared_interaction" : "cut23",
        "name" : "Aerith (cut23) Sora",
        "interaction" : "cut23",
        "SUID" : 1242,
        "BEND_MAP_ID" : 1242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1241",
        "source" : "179",
        "target" : "114",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Aerith (cut22) Donald",
        "shared_interaction" : "cut22",
        "name" : "Aerith (cut22) Donald",
        "interaction" : "cut22",
        "SUID" : 1241,
        "BEND_MAP_ID" : 1241,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1240",
        "source" : "179",
        "target" : "84",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Aerith (cut22) Sora",
        "shared_interaction" : "cut22",
        "name" : "Aerith (cut22) Sora",
        "interaction" : "cut22",
        "SUID" : 1240,
        "BEND_MAP_ID" : 1240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1239",
        "source" : "179",
        "target" : "177",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Aerith (cut22) Yuffie",
        "shared_interaction" : "cut22",
        "name" : "Aerith (cut22) Yuffie",
        "interaction" : "cut22",
        "SUID" : 1239,
        "BEND_MAP_ID" : 1239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1238",
        "source" : "179",
        "target" : "175",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Aerith (cut22) Leon",
        "shared_interaction" : "cut22",
        "name" : "Aerith (cut22) Leon",
        "interaction" : "cut22",
        "SUID" : 1238,
        "BEND_MAP_ID" : 1238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1237",
        "source" : "179",
        "target" : "175",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Aerith (cut21) Leon",
        "shared_interaction" : "cut21",
        "name" : "Aerith (cut21) Leon",
        "interaction" : "cut21",
        "SUID" : 1237,
        "BEND_MAP_ID" : 1237,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1236",
        "source" : "179",
        "target" : "177",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Aerith (cut21) Yuffie",
        "shared_interaction" : "cut21",
        "name" : "Aerith (cut21) Yuffie",
        "interaction" : "cut21",
        "SUID" : 1236,
        "BEND_MAP_ID" : 1236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1235",
        "source" : "179",
        "target" : "84",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Aerith (cut21) Sora",
        "shared_interaction" : "cut21",
        "name" : "Aerith (cut21) Sora",
        "interaction" : "cut21",
        "SUID" : 1235,
        "BEND_MAP_ID" : 1235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1234",
        "source" : "179",
        "target" : "84",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Aerith (cut20) Sora",
        "shared_interaction" : "cut20",
        "name" : "Aerith (cut20) Sora",
        "interaction" : "cut20",
        "SUID" : 1234,
        "BEND_MAP_ID" : 1234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1233",
        "source" : "179",
        "target" : "82",
        "EdgeBetweenness" : 6.586580086580087,
        "shared_name" : "Aerith (cut19) Kairi",
        "shared_interaction" : "cut19",
        "name" : "Aerith (cut19) Kairi",
        "interaction" : "cut19",
        "SUID" : 1233,
        "BEND_MAP_ID" : 1233,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1232",
        "source" : "179",
        "target" : "177",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Aerith (cut19) Yuffie",
        "shared_interaction" : "cut19",
        "name" : "Aerith (cut19) Yuffie",
        "interaction" : "cut19",
        "SUID" : 1232,
        "BEND_MAP_ID" : 1232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1231",
        "source" : "179",
        "target" : "175",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Aerith (cut19) Leon",
        "shared_interaction" : "cut19",
        "name" : "Aerith (cut19) Leon",
        "interaction" : "cut19",
        "SUID" : 1231,
        "BEND_MAP_ID" : 1231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1230",
        "source" : "179",
        "target" : "84",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Aerith (cut18) Sora",
        "shared_interaction" : "cut18",
        "name" : "Aerith (cut18) Sora",
        "interaction" : "cut18",
        "SUID" : 1230,
        "BEND_MAP_ID" : 1230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1229",
        "source" : "179",
        "target" : "175",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Aerith (cut18) Leon",
        "shared_interaction" : "cut18",
        "name" : "Aerith (cut18) Leon",
        "interaction" : "cut18",
        "SUID" : 1229,
        "BEND_MAP_ID" : 1229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1228",
        "source" : "179",
        "target" : "177",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Aerith (cut17) Yuffie",
        "shared_interaction" : "cut17",
        "name" : "Aerith (cut17) Yuffie",
        "interaction" : "cut17",
        "SUID" : 1228,
        "BEND_MAP_ID" : 1228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1227",
        "source" : "179",
        "target" : "84",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Aerith (cut17) Sora",
        "shared_interaction" : "cut17",
        "name" : "Aerith (cut17) Sora",
        "interaction" : "cut17",
        "SUID" : 1227,
        "BEND_MAP_ID" : 1227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1226",
        "source" : "179",
        "target" : "220",
        "EdgeBetweenness" : 2.7333333333333334,
        "shared_name" : "Aerith (cut17) Cid",
        "shared_interaction" : "cut17",
        "name" : "Aerith (cut17) Cid",
        "interaction" : "cut17",
        "SUID" : 1226,
        "BEND_MAP_ID" : 1226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1225",
        "source" : "179",
        "target" : "114",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Aerith (cut16) Donald",
        "shared_interaction" : "cut16",
        "name" : "Aerith (cut16) Donald",
        "interaction" : "cut16",
        "SUID" : 1225,
        "BEND_MAP_ID" : 1225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1224",
        "source" : "179",
        "target" : "175",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Aerith (cut16) Leon",
        "shared_interaction" : "cut16",
        "name" : "Aerith (cut16) Leon",
        "interaction" : "cut16",
        "SUID" : 1224,
        "BEND_MAP_ID" : 1224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1223",
        "source" : "179",
        "target" : "84",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Aerith (cut16) Sora",
        "shared_interaction" : "cut16",
        "name" : "Aerith (cut16) Sora",
        "interaction" : "cut16",
        "SUID" : 1223,
        "BEND_MAP_ID" : 1223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1222",
        "source" : "179",
        "target" : "220",
        "EdgeBetweenness" : 2.7333333333333334,
        "shared_name" : "Aerith (cut16) Cid",
        "shared_interaction" : "cut16",
        "name" : "Aerith (cut16) Cid",
        "interaction" : "cut16",
        "SUID" : 1222,
        "BEND_MAP_ID" : 1222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1221",
        "source" : "179",
        "target" : "175",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Aerith (cut15) Leon",
        "shared_interaction" : "cut15",
        "name" : "Aerith (cut15) Leon",
        "interaction" : "cut15",
        "SUID" : 1221,
        "BEND_MAP_ID" : 1221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1220",
        "source" : "179",
        "target" : "106",
        "EdgeBetweenness" : 37.11688311688311,
        "shared_name" : "Aerith (cut14) Goofy",
        "shared_interaction" : "cut14",
        "name" : "Aerith (cut14) Goofy",
        "interaction" : "cut14",
        "SUID" : 1220,
        "BEND_MAP_ID" : 1220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1219",
        "source" : "179",
        "target" : "114",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Aerith (cut14) Donald",
        "shared_interaction" : "cut14",
        "name" : "Aerith (cut14) Donald",
        "interaction" : "cut14",
        "SUID" : 1219,
        "BEND_MAP_ID" : 1219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1218",
        "source" : "179",
        "target" : "345",
        "EdgeBetweenness" : 3.2,
        "shared_name" : "Aerith (cut14) Sora, Donald & Goofy",
        "shared_interaction" : "cut14",
        "name" : "Aerith (cut14) Sora, Donald & Goofy",
        "interaction" : "cut14",
        "SUID" : 1218,
        "BEND_MAP_ID" : 1218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1217",
        "source" : "179",
        "target" : "84",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Aerith (cut14) Sora",
        "shared_interaction" : "cut14",
        "name" : "Aerith (cut14) Sora",
        "interaction" : "cut14",
        "SUID" : 1217,
        "BEND_MAP_ID" : 1217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1216",
        "source" : "179",
        "target" : "175",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Aerith (cut14) Leon",
        "shared_interaction" : "cut14",
        "name" : "Aerith (cut14) Leon",
        "interaction" : "cut14",
        "SUID" : 1216,
        "BEND_MAP_ID" : 1216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1215",
        "source" : "179",
        "target" : "177",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Aerith (cut13) Yuffie",
        "shared_interaction" : "cut13",
        "name" : "Aerith (cut13) Yuffie",
        "interaction" : "cut13",
        "SUID" : 1215,
        "BEND_MAP_ID" : 1215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1214",
        "source" : "179",
        "target" : "84",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Aerith (cut13) Sora",
        "shared_interaction" : "cut13",
        "name" : "Aerith (cut13) Sora",
        "interaction" : "cut13",
        "SUID" : 1214,
        "BEND_MAP_ID" : 1214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1213",
        "source" : "179",
        "target" : "175",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Aerith (cut13) Leon",
        "shared_interaction" : "cut13",
        "name" : "Aerith (cut13) Leon",
        "interaction" : "cut13",
        "SUID" : 1213,
        "BEND_MAP_ID" : 1213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1212",
        "source" : "179",
        "target" : "175",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Aerith (cut12) Leon",
        "shared_interaction" : "cut12",
        "name" : "Aerith (cut12) Leon",
        "interaction" : "cut12",
        "SUID" : 1212,
        "BEND_MAP_ID" : 1212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1211",
        "source" : "179",
        "target" : "177",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Aerith (cut12) Yuffie",
        "shared_interaction" : "cut12",
        "name" : "Aerith (cut12) Yuffie",
        "interaction" : "cut12",
        "SUID" : 1211,
        "BEND_MAP_ID" : 1211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1210",
        "source" : "179",
        "target" : "177",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Aerith (cut10) Yuffie",
        "shared_interaction" : "cut10",
        "name" : "Aerith (cut10) Yuffie",
        "interaction" : "cut10",
        "SUID" : 1210,
        "BEND_MAP_ID" : 1210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1209",
        "source" : "179",
        "target" : "175",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Aerith (cut10) Leon",
        "shared_interaction" : "cut10",
        "name" : "Aerith (cut10) Leon",
        "interaction" : "cut10",
        "SUID" : 1209,
        "BEND_MAP_ID" : 1209,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1208",
        "source" : "179",
        "target" : "84",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Aerith (cut8) Sora",
        "shared_interaction" : "cut8",
        "name" : "Aerith (cut8) Sora",
        "interaction" : "cut8",
        "SUID" : 1208,
        "BEND_MAP_ID" : 1208,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1207",
        "source" : "179",
        "target" : "114",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Aerith (cut8) Donald",
        "shared_interaction" : "cut8",
        "name" : "Aerith (cut8) Donald",
        "interaction" : "cut8",
        "SUID" : 1207,
        "BEND_MAP_ID" : 1207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1206",
        "source" : "179",
        "target" : "114",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Aerith (cut7) Donald",
        "shared_interaction" : "cut7",
        "name" : "Aerith (cut7) Donald",
        "interaction" : "cut7",
        "SUID" : 1206,
        "BEND_MAP_ID" : 1206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1205",
        "source" : "179",
        "target" : "106",
        "EdgeBetweenness" : 37.11688311688311,
        "shared_name" : "Aerith (cut7) Goofy",
        "shared_interaction" : "cut7",
        "name" : "Aerith (cut7) Goofy",
        "interaction" : "cut7",
        "SUID" : 1205,
        "BEND_MAP_ID" : 1205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1204",
        "source" : "179",
        "target" : "106",
        "EdgeBetweenness" : 37.11688311688311,
        "shared_name" : "Aerith (cut6) Goofy",
        "shared_interaction" : "cut6",
        "name" : "Aerith (cut6) Goofy",
        "interaction" : "cut6",
        "SUID" : 1204,
        "BEND_MAP_ID" : 1204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1203",
        "source" : "179",
        "target" : "114",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Aerith (cut5) Donald",
        "shared_interaction" : "cut5",
        "name" : "Aerith (cut5) Donald",
        "interaction" : "cut5",
        "SUID" : 1203,
        "BEND_MAP_ID" : 1203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1202",
        "source" : "179",
        "target" : "106",
        "EdgeBetweenness" : 37.11688311688311,
        "shared_name" : "Aerith (cut5) Goofy",
        "shared_interaction" : "cut5",
        "name" : "Aerith (cut5) Goofy",
        "interaction" : "cut5",
        "SUID" : 1202,
        "BEND_MAP_ID" : 1202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1201",
        "source" : "179",
        "target" : "175",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Aerith (cut3) Leon",
        "shared_interaction" : "cut3",
        "name" : "Aerith (cut3) Leon",
        "interaction" : "cut3",
        "SUID" : 1201,
        "BEND_MAP_ID" : 1201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1200",
        "source" : "179",
        "target" : "177",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Aerith (cut3) Yuffie",
        "shared_interaction" : "cut3",
        "name" : "Aerith (cut3) Yuffie",
        "interaction" : "cut3",
        "SUID" : 1200,
        "BEND_MAP_ID" : 1200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1199",
        "source" : "179",
        "target" : "84",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Aerith (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Aerith (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1199,
        "BEND_MAP_ID" : 1199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1198",
        "source" : "179",
        "target" : "106",
        "EdgeBetweenness" : 37.11688311688311,
        "shared_name" : "Aerith (cut1) Goofy",
        "shared_interaction" : "cut1",
        "name" : "Aerith (cut1) Goofy",
        "interaction" : "cut1",
        "SUID" : 1198,
        "BEND_MAP_ID" : 1198,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1197",
        "source" : "179",
        "target" : "114",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Aerith (cut1) Donald",
        "shared_interaction" : "cut1",
        "name" : "Aerith (cut1) Donald",
        "interaction" : "cut1",
        "SUID" : 1197,
        "BEND_MAP_ID" : 1197,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1196",
        "source" : "177",
        "target" : "175",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Yuffie (cut18) Leon",
        "shared_interaction" : "cut18",
        "name" : "Yuffie (cut18) Leon",
        "interaction" : "cut18",
        "SUID" : 1196,
        "BEND_MAP_ID" : 1196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1195",
        "source" : "177",
        "target" : "114",
        "EdgeBetweenness" : 26.99783549783549,
        "shared_name" : "Yuffie (cut17) Donald",
        "shared_interaction" : "cut17",
        "name" : "Yuffie (cut17) Donald",
        "interaction" : "cut17",
        "SUID" : 1195,
        "BEND_MAP_ID" : 1195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1194",
        "source" : "177",
        "target" : "84",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Yuffie (cut17) Sora",
        "shared_interaction" : "cut17",
        "name" : "Yuffie (cut17) Sora",
        "interaction" : "cut17",
        "SUID" : 1194,
        "BEND_MAP_ID" : 1194,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1193",
        "source" : "177",
        "target" : "179",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Yuffie (cut17) Aerith",
        "shared_interaction" : "cut17",
        "name" : "Yuffie (cut17) Aerith",
        "interaction" : "cut17",
        "SUID" : 1193,
        "BEND_MAP_ID" : 1193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1192",
        "source" : "177",
        "target" : "175",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Yuffie (cut17) Leon",
        "shared_interaction" : "cut17",
        "name" : "Yuffie (cut17) Leon",
        "interaction" : "cut17",
        "SUID" : 1192,
        "BEND_MAP_ID" : 1192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1191",
        "source" : "177",
        "target" : "175",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Yuffie (cut16) Leon",
        "shared_interaction" : "cut16",
        "name" : "Yuffie (cut16) Leon",
        "interaction" : "cut16",
        "SUID" : 1191,
        "BEND_MAP_ID" : 1191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1190",
        "source" : "177",
        "target" : "179",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Yuffie (cut16) Aerith",
        "shared_interaction" : "cut16",
        "name" : "Yuffie (cut16) Aerith",
        "interaction" : "cut16",
        "SUID" : 1190,
        "BEND_MAP_ID" : 1190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1189",
        "source" : "177",
        "target" : "84",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Yuffie (cut16) Sora",
        "shared_interaction" : "cut16",
        "name" : "Yuffie (cut16) Sora",
        "interaction" : "cut16",
        "SUID" : 1189,
        "BEND_MAP_ID" : 1189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1188",
        "source" : "177",
        "target" : "179",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Yuffie (cut15) Aerith",
        "shared_interaction" : "cut15",
        "name" : "Yuffie (cut15) Aerith",
        "interaction" : "cut15",
        "SUID" : 1188,
        "BEND_MAP_ID" : 1188,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1187",
        "source" : "177",
        "target" : "82",
        "EdgeBetweenness" : 6.186580086580087,
        "shared_name" : "Yuffie (cut15) Kairi",
        "shared_interaction" : "cut15",
        "name" : "Yuffie (cut15) Kairi",
        "interaction" : "cut15",
        "SUID" : 1187,
        "BEND_MAP_ID" : 1187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1186",
        "source" : "177",
        "target" : "175",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Yuffie (cut15) Leon",
        "shared_interaction" : "cut15",
        "name" : "Yuffie (cut15) Leon",
        "interaction" : "cut15",
        "SUID" : 1186,
        "BEND_MAP_ID" : 1186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1185",
        "source" : "177",
        "target" : "84",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Yuffie (cut14) Sora",
        "shared_interaction" : "cut14",
        "name" : "Yuffie (cut14) Sora",
        "interaction" : "cut14",
        "SUID" : 1185,
        "BEND_MAP_ID" : 1185,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1184",
        "source" : "177",
        "target" : "179",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Yuffie (cut14) Aerith",
        "shared_interaction" : "cut14",
        "name" : "Yuffie (cut14) Aerith",
        "interaction" : "cut14",
        "SUID" : 1184,
        "BEND_MAP_ID" : 1184,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1183",
        "source" : "177",
        "target" : "220",
        "EdgeBetweenness" : 2.3333333333333335,
        "shared_name" : "Yuffie (cut14) Cid",
        "shared_interaction" : "cut14",
        "name" : "Yuffie (cut14) Cid",
        "interaction" : "cut14",
        "SUID" : 1183,
        "BEND_MAP_ID" : 1183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1182",
        "source" : "177",
        "target" : "179",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Yuffie (cut11) Aerith",
        "shared_interaction" : "cut11",
        "name" : "Yuffie (cut11) Aerith",
        "interaction" : "cut11",
        "SUID" : 1182,
        "BEND_MAP_ID" : 1182,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1181",
        "source" : "177",
        "target" : "84",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Yuffie (cut11) Sora",
        "shared_interaction" : "cut11",
        "name" : "Yuffie (cut11) Sora",
        "interaction" : "cut11",
        "SUID" : 1181,
        "BEND_MAP_ID" : 1181,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1180",
        "source" : "177",
        "target" : "175",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Yuffie (cut11) Leon",
        "shared_interaction" : "cut11",
        "name" : "Yuffie (cut11) Leon",
        "interaction" : "cut11",
        "SUID" : 1180,
        "BEND_MAP_ID" : 1180,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1179",
        "source" : "177",
        "target" : "175",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Yuffie (cut10) Leon",
        "shared_interaction" : "cut10",
        "name" : "Yuffie (cut10) Leon",
        "interaction" : "cut10",
        "SUID" : 1179,
        "BEND_MAP_ID" : 1179,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1178",
        "source" : "177",
        "target" : "179",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Yuffie (cut10) Aerith",
        "shared_interaction" : "cut10",
        "name" : "Yuffie (cut10) Aerith",
        "interaction" : "cut10",
        "SUID" : 1178,
        "BEND_MAP_ID" : 1178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1177",
        "source" : "177",
        "target" : "179",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Yuffie (cut9) Aerith",
        "shared_interaction" : "cut9",
        "name" : "Yuffie (cut9) Aerith",
        "interaction" : "cut9",
        "SUID" : 1177,
        "BEND_MAP_ID" : 1177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1176",
        "source" : "177",
        "target" : "175",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Yuffie (cut9) Leon",
        "shared_interaction" : "cut9",
        "name" : "Yuffie (cut9) Leon",
        "interaction" : "cut9",
        "SUID" : 1176,
        "BEND_MAP_ID" : 1176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1175",
        "source" : "177",
        "target" : "84",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Yuffie (cut7) Sora",
        "shared_interaction" : "cut7",
        "name" : "Yuffie (cut7) Sora",
        "interaction" : "cut7",
        "SUID" : 1175,
        "BEND_MAP_ID" : 1175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1174",
        "source" : "177",
        "target" : "175",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Yuffie (cut7) Leon",
        "shared_interaction" : "cut7",
        "name" : "Yuffie (cut7) Leon",
        "interaction" : "cut7",
        "SUID" : 1174,
        "BEND_MAP_ID" : 1174,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1173",
        "source" : "177",
        "target" : "84",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Yuffie (cut6) Sora",
        "shared_interaction" : "cut6",
        "name" : "Yuffie (cut6) Sora",
        "interaction" : "cut6",
        "SUID" : 1173,
        "BEND_MAP_ID" : 1173,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1172",
        "source" : "177",
        "target" : "175",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Yuffie (cut6) Leon",
        "shared_interaction" : "cut6",
        "name" : "Yuffie (cut6) Leon",
        "interaction" : "cut6",
        "SUID" : 1172,
        "BEND_MAP_ID" : 1172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1171",
        "source" : "177",
        "target" : "175",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Yuffie (cut5) Leon",
        "shared_interaction" : "cut5",
        "name" : "Yuffie (cut5) Leon",
        "interaction" : "cut5",
        "SUID" : 1171,
        "BEND_MAP_ID" : 1171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1170",
        "source" : "177",
        "target" : "106",
        "EdgeBetweenness" : 37.516883116883115,
        "shared_name" : "Yuffie (cut4) Goofy",
        "shared_interaction" : "cut4",
        "name" : "Yuffie (cut4) Goofy",
        "interaction" : "cut4",
        "SUID" : 1170,
        "BEND_MAP_ID" : 1170,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1169",
        "source" : "177",
        "target" : "175",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Yuffie (cut3) Leon",
        "shared_interaction" : "cut3",
        "name" : "Yuffie (cut3) Leon",
        "interaction" : "cut3",
        "SUID" : 1169,
        "BEND_MAP_ID" : 1169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1168",
        "source" : "177",
        "target" : "84",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Yuffie (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Yuffie (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1168,
        "BEND_MAP_ID" : 1168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1167",
        "source" : "177",
        "target" : "179",
        "EdgeBetweenness" : 2.4000000000000004,
        "shared_name" : "Yuffie (cut3) Aerith",
        "shared_interaction" : "cut3",
        "name" : "Yuffie (cut3) Aerith",
        "interaction" : "cut3",
        "SUID" : 1167,
        "BEND_MAP_ID" : 1167,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1166",
        "source" : "177",
        "target" : "175",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Yuffie (cut2) Leon",
        "shared_interaction" : "cut2",
        "name" : "Yuffie (cut2) Leon",
        "interaction" : "cut2",
        "SUID" : 1166,
        "BEND_MAP_ID" : 1166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1165",
        "source" : "177",
        "target" : "84",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Yuffie (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Yuffie (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1165,
        "BEND_MAP_ID" : 1165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1164",
        "source" : "175",
        "target" : "177",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Leon (cut29) Yuffie",
        "shared_interaction" : "cut29",
        "name" : "Leon (cut29) Yuffie",
        "interaction" : "cut29",
        "SUID" : 1164,
        "BEND_MAP_ID" : 1164,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1163",
        "source" : "175",
        "target" : "106",
        "EdgeBetweenness" : 38.116883116883116,
        "shared_name" : "Leon (cut28) Goofy",
        "shared_interaction" : "cut28",
        "name" : "Leon (cut28) Goofy",
        "interaction" : "cut28",
        "SUID" : 1163,
        "BEND_MAP_ID" : 1163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1162",
        "source" : "175",
        "target" : "114",
        "EdgeBetweenness" : 26.09783549783549,
        "shared_name" : "Leon (cut27) Donald",
        "shared_interaction" : "cut27",
        "name" : "Leon (cut27) Donald",
        "interaction" : "cut27",
        "SUID" : 1162,
        "BEND_MAP_ID" : 1162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1161",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut27) Sora",
        "shared_interaction" : "cut27",
        "name" : "Leon (cut27) Sora",
        "interaction" : "cut27",
        "SUID" : 1161,
        "BEND_MAP_ID" : 1161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1160",
        "source" : "175",
        "target" : "177",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Leon (cut27) Yuffie",
        "shared_interaction" : "cut27",
        "name" : "Leon (cut27) Yuffie",
        "interaction" : "cut27",
        "SUID" : 1160,
        "BEND_MAP_ID" : 1160,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1159",
        "source" : "175",
        "target" : "179",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Leon (cut27) Aerith",
        "shared_interaction" : "cut27",
        "name" : "Leon (cut27) Aerith",
        "interaction" : "cut27",
        "SUID" : 1159,
        "BEND_MAP_ID" : 1159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1158",
        "source" : "175",
        "target" : "179",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Leon (cut26) Aerith",
        "shared_interaction" : "cut26",
        "name" : "Leon (cut26) Aerith",
        "interaction" : "cut26",
        "SUID" : 1158,
        "BEND_MAP_ID" : 1158,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1157",
        "source" : "175",
        "target" : "177",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Leon (cut26) Yuffie",
        "shared_interaction" : "cut26",
        "name" : "Leon (cut26) Yuffie",
        "interaction" : "cut26",
        "SUID" : 1157,
        "BEND_MAP_ID" : 1157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1156",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut26) Sora",
        "shared_interaction" : "cut26",
        "name" : "Leon (cut26) Sora",
        "interaction" : "cut26",
        "SUID" : 1156,
        "BEND_MAP_ID" : 1156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1155",
        "source" : "175",
        "target" : "179",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Leon (cut25) Aerith",
        "shared_interaction" : "cut25",
        "name" : "Leon (cut25) Aerith",
        "interaction" : "cut25",
        "SUID" : 1155,
        "BEND_MAP_ID" : 1155,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1154",
        "source" : "175",
        "target" : "82",
        "EdgeBetweenness" : 6.086580086580087,
        "shared_name" : "Leon (cut25) Kairi",
        "shared_interaction" : "cut25",
        "name" : "Leon (cut25) Kairi",
        "interaction" : "cut25",
        "SUID" : 1154,
        "BEND_MAP_ID" : 1154,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1153",
        "source" : "175",
        "target" : "177",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Leon (cut25) Yuffie",
        "shared_interaction" : "cut25",
        "name" : "Leon (cut25) Yuffie",
        "interaction" : "cut25",
        "SUID" : 1153,
        "BEND_MAP_ID" : 1153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1152",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut24) Sora",
        "shared_interaction" : "cut24",
        "name" : "Leon (cut24) Sora",
        "interaction" : "cut24",
        "SUID" : 1152,
        "BEND_MAP_ID" : 1152,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1151",
        "source" : "175",
        "target" : "179",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Leon (cut24) Aerith",
        "shared_interaction" : "cut24",
        "name" : "Leon (cut24) Aerith",
        "interaction" : "cut24",
        "SUID" : 1151,
        "BEND_MAP_ID" : 1151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1150",
        "source" : "175",
        "target" : "114",
        "EdgeBetweenness" : 26.09783549783549,
        "shared_name" : "Leon (cut22) Donald",
        "shared_interaction" : "cut22",
        "name" : "Leon (cut22) Donald",
        "interaction" : "cut22",
        "SUID" : 1150,
        "BEND_MAP_ID" : 1150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1149",
        "source" : "175",
        "target" : "179",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Leon (cut22) Aerith",
        "shared_interaction" : "cut22",
        "name" : "Leon (cut22) Aerith",
        "interaction" : "cut22",
        "SUID" : 1149,
        "BEND_MAP_ID" : 1149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1148",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut22) Sora",
        "shared_interaction" : "cut22",
        "name" : "Leon (cut22) Sora",
        "interaction" : "cut22",
        "SUID" : 1148,
        "BEND_MAP_ID" : 1148,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1147",
        "source" : "175",
        "target" : "220",
        "EdgeBetweenness" : 3.4,
        "shared_name" : "Leon (cut22) Cid",
        "shared_interaction" : "cut22",
        "name" : "Leon (cut22) Cid",
        "interaction" : "cut22",
        "SUID" : 1147,
        "BEND_MAP_ID" : 1147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1146",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut21) Sora",
        "shared_interaction" : "cut21",
        "name" : "Leon (cut21) Sora",
        "interaction" : "cut21",
        "SUID" : 1146,
        "BEND_MAP_ID" : 1146,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1145",
        "source" : "175",
        "target" : "179",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Leon (cut20) Aerith",
        "shared_interaction" : "cut20",
        "name" : "Leon (cut20) Aerith",
        "interaction" : "cut20",
        "SUID" : 1145,
        "BEND_MAP_ID" : 1145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1144",
        "source" : "175",
        "target" : "106",
        "EdgeBetweenness" : 38.116883116883116,
        "shared_name" : "Leon (cut19) Goofy",
        "shared_interaction" : "cut19",
        "name" : "Leon (cut19) Goofy",
        "interaction" : "cut19",
        "SUID" : 1144,
        "BEND_MAP_ID" : 1144,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1143",
        "source" : "175",
        "target" : "114",
        "EdgeBetweenness" : 26.09783549783549,
        "shared_name" : "Leon (cut19) Donald",
        "shared_interaction" : "cut19",
        "name" : "Leon (cut19) Donald",
        "interaction" : "cut19",
        "SUID" : 1143,
        "BEND_MAP_ID" : 1143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1142",
        "source" : "175",
        "target" : "345",
        "EdgeBetweenness" : 3.8666666666666667,
        "shared_name" : "Leon (cut19) Sora, Donald & Goofy",
        "shared_interaction" : "cut19",
        "name" : "Leon (cut19) Sora, Donald & Goofy",
        "interaction" : "cut19",
        "SUID" : 1142,
        "BEND_MAP_ID" : 1142,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1141",
        "source" : "175",
        "target" : "179",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Leon (cut19) Aerith",
        "shared_interaction" : "cut19",
        "name" : "Leon (cut19) Aerith",
        "interaction" : "cut19",
        "SUID" : 1141,
        "BEND_MAP_ID" : 1141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1140",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut19) Sora",
        "shared_interaction" : "cut19",
        "name" : "Leon (cut19) Sora",
        "interaction" : "cut19",
        "SUID" : 1140,
        "BEND_MAP_ID" : 1140,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1139",
        "source" : "175",
        "target" : "179",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Leon (cut18) Aerith",
        "shared_interaction" : "cut18",
        "name" : "Leon (cut18) Aerith",
        "interaction" : "cut18",
        "SUID" : 1139,
        "BEND_MAP_ID" : 1139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1138",
        "source" : "175",
        "target" : "177",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Leon (cut18) Yuffie",
        "shared_interaction" : "cut18",
        "name" : "Leon (cut18) Yuffie",
        "interaction" : "cut18",
        "SUID" : 1138,
        "BEND_MAP_ID" : 1138,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1137",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut18) Sora",
        "shared_interaction" : "cut18",
        "name" : "Leon (cut18) Sora",
        "interaction" : "cut18",
        "SUID" : 1137,
        "BEND_MAP_ID" : 1137,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1136",
        "source" : "175",
        "target" : "179",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Leon (cut17) Aerith",
        "shared_interaction" : "cut17",
        "name" : "Leon (cut17) Aerith",
        "interaction" : "cut17",
        "SUID" : 1136,
        "BEND_MAP_ID" : 1136,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1135",
        "source" : "175",
        "target" : "177",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Leon (cut17) Yuffie",
        "shared_interaction" : "cut17",
        "name" : "Leon (cut17) Yuffie",
        "interaction" : "cut17",
        "SUID" : 1135,
        "BEND_MAP_ID" : 1135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1134",
        "source" : "175",
        "target" : "179",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Leon (cut16) Aerith",
        "shared_interaction" : "cut16",
        "name" : "Leon (cut16) Aerith",
        "interaction" : "cut16",
        "SUID" : 1134,
        "BEND_MAP_ID" : 1134,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1133",
        "source" : "175",
        "target" : "177",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Leon (cut16) Yuffie",
        "shared_interaction" : "cut16",
        "name" : "Leon (cut16) Yuffie",
        "interaction" : "cut16",
        "SUID" : 1133,
        "BEND_MAP_ID" : 1133,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1132",
        "source" : "175",
        "target" : "114",
        "EdgeBetweenness" : 26.09783549783549,
        "shared_name" : "Leon (cut15) Donald",
        "shared_interaction" : "cut15",
        "name" : "Leon (cut15) Donald",
        "interaction" : "cut15",
        "SUID" : 1132,
        "BEND_MAP_ID" : 1132,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1131",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut15) Sora",
        "shared_interaction" : "cut15",
        "name" : "Leon (cut15) Sora",
        "interaction" : "cut15",
        "SUID" : 1131,
        "BEND_MAP_ID" : 1131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1130",
        "source" : "175",
        "target" : "173",
        "EdgeBetweenness" : 5.333333333333332,
        "shared_name" : "Leon (cut14) Donald & Goofy",
        "shared_interaction" : "cut14",
        "name" : "Leon (cut14) Donald & Goofy",
        "interaction" : "cut14",
        "SUID" : 1130,
        "BEND_MAP_ID" : 1130,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1129",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut14) Sora",
        "shared_interaction" : "cut14",
        "name" : "Leon (cut14) Sora",
        "interaction" : "cut14",
        "SUID" : 1129,
        "BEND_MAP_ID" : 1129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1128",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut10) Sora",
        "shared_interaction" : "cut10",
        "name" : "Leon (cut10) Sora",
        "interaction" : "cut10",
        "SUID" : 1128,
        "BEND_MAP_ID" : 1128,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1127",
        "source" : "175",
        "target" : "177",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Leon (cut10) Yuffie",
        "shared_interaction" : "cut10",
        "name" : "Leon (cut10) Yuffie",
        "interaction" : "cut10",
        "SUID" : 1127,
        "BEND_MAP_ID" : 1127,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1126",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut9) Sora",
        "shared_interaction" : "cut9",
        "name" : "Leon (cut9) Sora",
        "interaction" : "cut9",
        "SUID" : 1126,
        "BEND_MAP_ID" : 1126,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1125",
        "source" : "175",
        "target" : "177",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Leon (cut8) Yuffie",
        "shared_interaction" : "cut8",
        "name" : "Leon (cut8) Yuffie",
        "interaction" : "cut8",
        "SUID" : 1125,
        "BEND_MAP_ID" : 1125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1124",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut8) Sora",
        "shared_interaction" : "cut8",
        "name" : "Leon (cut8) Sora",
        "interaction" : "cut8",
        "SUID" : 1124,
        "BEND_MAP_ID" : 1124,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1123",
        "source" : "175",
        "target" : "177",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Leon (cut7) Yuffie",
        "shared_interaction" : "cut7",
        "name" : "Leon (cut7) Yuffie",
        "interaction" : "cut7",
        "SUID" : 1123,
        "BEND_MAP_ID" : 1123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1122",
        "source" : "175",
        "target" : "177",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Leon (cut6) Yuffie",
        "shared_interaction" : "cut6",
        "name" : "Leon (cut6) Yuffie",
        "interaction" : "cut6",
        "SUID" : 1122,
        "BEND_MAP_ID" : 1122,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1121",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut6) Sora",
        "shared_interaction" : "cut6",
        "name" : "Leon (cut6) Sora",
        "interaction" : "cut6",
        "SUID" : 1121,
        "BEND_MAP_ID" : 1121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1120",
        "source" : "175",
        "target" : "179",
        "EdgeBetweenness" : 2.5,
        "shared_name" : "Leon (cut6) Aerith",
        "shared_interaction" : "cut6",
        "name" : "Leon (cut6) Aerith",
        "interaction" : "cut6",
        "SUID" : 1120,
        "BEND_MAP_ID" : 1120,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1119",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut5) Sora",
        "shared_interaction" : "cut5",
        "name" : "Leon (cut5) Sora",
        "interaction" : "cut5",
        "SUID" : 1119,
        "BEND_MAP_ID" : 1119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1118",
        "source" : "175",
        "target" : "177",
        "EdgeBetweenness" : 2.9000000000000004,
        "shared_name" : "Leon (cut3) Yuffie",
        "shared_interaction" : "cut3",
        "name" : "Leon (cut3) Yuffie",
        "interaction" : "cut3",
        "SUID" : 1118,
        "BEND_MAP_ID" : 1118,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1117",
        "source" : "175",
        "target" : "84",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Leon (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Leon (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1117,
        "BEND_MAP_ID" : 1117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1246",
        "source" : "173",
        "target" : "114",
        "EdgeBetweenness" : 39.210606060606075,
        "shared_name" : "Donald & Goofy (cut4) Donald",
        "shared_interaction" : "cut4",
        "name" : "Donald & Goofy (cut4) Donald",
        "interaction" : "cut4",
        "SUID" : 1246,
        "BEND_MAP_ID" : 1246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1245",
        "source" : "173",
        "target" : "82",
        "EdgeBetweenness" : 8.746969696969696,
        "shared_name" : "Donald & Goofy (cut3) Kairi",
        "shared_interaction" : "cut3",
        "name" : "Donald & Goofy (cut3) Kairi",
        "interaction" : "cut3",
        "SUID" : 1245,
        "BEND_MAP_ID" : 1245,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1244",
        "source" : "173",
        "target" : "175",
        "EdgeBetweenness" : 5.333333333333332,
        "shared_name" : "Donald & Goofy (cut2) Leon",
        "shared_interaction" : "cut2",
        "name" : "Donald & Goofy (cut2) Leon",
        "interaction" : "cut2",
        "SUID" : 1244,
        "BEND_MAP_ID" : 1244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1243",
        "source" : "173",
        "target" : "84",
        "EdgeBetweenness" : 110.70909090909093,
        "shared_name" : "Donald & Goofy (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Donald & Goofy (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1243,
        "BEND_MAP_ID" : 1243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1628",
        "source" : "136",
        "target" : "447",
        "EdgeBetweenness" : 26.700000000000006,
        "shared_name" : "Sebastian (cut12) Ariel",
        "shared_interaction" : "cut12",
        "name" : "Sebastian (cut12) Ariel",
        "interaction" : "cut12",
        "SUID" : 1628,
        "BEND_MAP_ID" : 1628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1627",
        "source" : "136",
        "target" : "114",
        "EdgeBetweenness" : 55.86926406926408,
        "shared_name" : "Sebastian (cut11) Donald",
        "shared_interaction" : "cut11",
        "name" : "Sebastian (cut11) Donald",
        "interaction" : "cut11",
        "SUID" : 1627,
        "BEND_MAP_ID" : 1627,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1626",
        "source" : "136",
        "target" : "84",
        "EdgeBetweenness" : 121.80346320346314,
        "shared_name" : "Sebastian (cut10) Sora",
        "shared_interaction" : "cut10",
        "name" : "Sebastian (cut10) Sora",
        "interaction" : "cut10",
        "SUID" : 1626,
        "BEND_MAP_ID" : 1626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1625",
        "source" : "136",
        "target" : "450",
        "EdgeBetweenness" : 5.449999999999998,
        "shared_name" : "Sebastian (cut9) Triton",
        "shared_interaction" : "cut9",
        "name" : "Sebastian (cut9) Triton",
        "interaction" : "cut9",
        "SUID" : 1625,
        "BEND_MAP_ID" : 1625,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1624",
        "source" : "136",
        "target" : "450",
        "EdgeBetweenness" : 5.449999999999998,
        "shared_name" : "Sebastian (cut8) Triton",
        "shared_interaction" : "cut8",
        "name" : "Sebastian (cut8) Triton",
        "interaction" : "cut8",
        "SUID" : 1624,
        "BEND_MAP_ID" : 1624,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1623",
        "source" : "136",
        "target" : "450",
        "EdgeBetweenness" : 5.449999999999998,
        "shared_name" : "Sebastian (cut7) Triton",
        "shared_interaction" : "cut7",
        "name" : "Sebastian (cut7) Triton",
        "interaction" : "cut7",
        "SUID" : 1623,
        "BEND_MAP_ID" : 1623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1622",
        "source" : "136",
        "target" : "106",
        "EdgeBetweenness" : 48.30346320346322,
        "shared_name" : "Sebastian (cut6) Goofy",
        "shared_interaction" : "cut6",
        "name" : "Sebastian (cut6) Goofy",
        "interaction" : "cut6",
        "SUID" : 1622,
        "BEND_MAP_ID" : 1622,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1621",
        "source" : "136",
        "target" : "84",
        "EdgeBetweenness" : 121.80346320346314,
        "shared_name" : "Sebastian (cut6) Sora",
        "shared_interaction" : "cut6",
        "name" : "Sebastian (cut6) Sora",
        "interaction" : "cut6",
        "SUID" : 1621,
        "BEND_MAP_ID" : 1621,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1620",
        "source" : "136",
        "target" : "447",
        "EdgeBetweenness" : 26.700000000000006,
        "shared_name" : "Sebastian (cut6) Ariel",
        "shared_interaction" : "cut6",
        "name" : "Sebastian (cut6) Ariel",
        "interaction" : "cut6",
        "SUID" : 1620,
        "BEND_MAP_ID" : 1620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1619",
        "source" : "136",
        "target" : "450",
        "EdgeBetweenness" : 5.449999999999998,
        "shared_name" : "Sebastian (cut6) Triton",
        "shared_interaction" : "cut6",
        "name" : "Sebastian (cut6) Triton",
        "interaction" : "cut6",
        "SUID" : 1619,
        "BEND_MAP_ID" : 1619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1618",
        "source" : "136",
        "target" : "1617",
        "EdgeBetweenness" : 90.84545454545453,
        "shared_name" : "Sebastian (cut5) Flounder",
        "shared_interaction" : "cut5",
        "name" : "Sebastian (cut5) Flounder",
        "interaction" : "cut5",
        "SUID" : 1618,
        "BEND_MAP_ID" : 1618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1616",
        "source" : "136",
        "target" : "447",
        "EdgeBetweenness" : 26.700000000000006,
        "shared_name" : "Sebastian (cut5) Ariel",
        "shared_interaction" : "cut5",
        "name" : "Sebastian (cut5) Ariel",
        "interaction" : "cut5",
        "SUID" : 1616,
        "BEND_MAP_ID" : 1616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1615",
        "source" : "136",
        "target" : "447",
        "EdgeBetweenness" : 26.700000000000006,
        "shared_name" : "Sebastian (cut3) Ariel",
        "shared_interaction" : "cut3",
        "name" : "Sebastian (cut3) Ariel",
        "interaction" : "cut3",
        "SUID" : 1615,
        "BEND_MAP_ID" : 1615,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1614",
        "source" : "136",
        "target" : "447",
        "EdgeBetweenness" : 26.700000000000006,
        "shared_name" : "Sebastian (cut2) Ariel",
        "shared_interaction" : "cut2",
        "name" : "Sebastian (cut2) Ariel",
        "interaction" : "cut2",
        "SUID" : 1614,
        "BEND_MAP_ID" : 1614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1613",
        "source" : "136",
        "target" : "78",
        "EdgeBetweenness" : 27.019264069264075,
        "shared_name" : "Sebastian (cut1) ?????",
        "shared_interaction" : "cut1",
        "name" : "Sebastian (cut1) ?????",
        "interaction" : "cut1",
        "SUID" : 1613,
        "BEND_MAP_ID" : 1613,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1407",
        "source" : "133",
        "target" : "78",
        "EdgeBetweenness" : 10.201587301587304,
        "shared_name" : "Merlin (cut5) ?????",
        "shared_interaction" : "cut5",
        "name" : "Merlin (cut5) ?????",
        "interaction" : "cut5",
        "SUID" : 1407,
        "BEND_MAP_ID" : 1407,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1406",
        "source" : "133",
        "target" : "106",
        "EdgeBetweenness" : 37.64285714285713,
        "shared_name" : "Merlin (cut1) Goofy",
        "shared_interaction" : "cut1",
        "name" : "Merlin (cut1) Goofy",
        "interaction" : "cut1",
        "SUID" : 1406,
        "BEND_MAP_ID" : 1406,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1405",
        "source" : "133",
        "target" : "114",
        "EdgeBetweenness" : 27.357142857142836,
        "shared_name" : "Merlin (cut1) Donald",
        "shared_interaction" : "cut1",
        "name" : "Merlin (cut1) Donald",
        "interaction" : "cut1",
        "SUID" : 1405,
        "BEND_MAP_ID" : 1405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1404",
        "source" : "133",
        "target" : "84",
        "EdgeBetweenness" : 83.5095238095238,
        "shared_name" : "Merlin (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Merlin (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1404,
        "BEND_MAP_ID" : 1404,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1403",
        "source" : "133",
        "target" : "222",
        "EdgeBetweenness" : 6.311111111111111,
        "shared_name" : "Merlin (cut1) ??????",
        "shared_interaction" : "cut1",
        "name" : "Merlin (cut1) ??????",
        "interaction" : "cut1",
        "SUID" : 1403,
        "BEND_MAP_ID" : 1403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1504",
        "source" : "123",
        "target" : "1450",
        "EdgeBetweenness" : 71.07813852813854,
        "shared_name" : "Jafar (cut17) Iago",
        "shared_interaction" : "cut17",
        "name" : "Jafar (cut17) Iago",
        "interaction" : "cut17",
        "SUID" : 1504,
        "BEND_MAP_ID" : 1504,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1503",
        "source" : "123",
        "target" : "1450",
        "EdgeBetweenness" : 71.07813852813854,
        "shared_name" : "Jafar (cut16) Iago",
        "shared_interaction" : "cut16",
        "name" : "Jafar (cut16) Iago",
        "interaction" : "cut16",
        "SUID" : 1503,
        "BEND_MAP_ID" : 1503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1502",
        "source" : "123",
        "target" : "395",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Jafar (cut16) Aladdin",
        "shared_interaction" : "cut16",
        "name" : "Jafar (cut16) Aladdin",
        "interaction" : "cut16",
        "SUID" : 1502,
        "BEND_MAP_ID" : 1502,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1501",
        "source" : "123",
        "target" : "114",
        "EdgeBetweenness" : 43.98964368964369,
        "shared_name" : "Jafar (cut13) Donald",
        "shared_interaction" : "cut13",
        "name" : "Jafar (cut13) Donald",
        "interaction" : "cut13",
        "SUID" : 1501,
        "BEND_MAP_ID" : 1501,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1500",
        "source" : "123",
        "target" : "106",
        "EdgeBetweenness" : 56.0063103563104,
        "shared_name" : "Jafar (cut13) Goofy",
        "shared_interaction" : "cut13",
        "name" : "Jafar (cut13) Goofy",
        "interaction" : "cut13",
        "SUID" : 1500,
        "BEND_MAP_ID" : 1500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1499",
        "source" : "123",
        "target" : "395",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Jafar (cut12) Aladdin",
        "shared_interaction" : "cut12",
        "name" : "Jafar (cut12) Aladdin",
        "interaction" : "cut12",
        "SUID" : 1499,
        "BEND_MAP_ID" : 1499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1498",
        "source" : "123",
        "target" : "98",
        "EdgeBetweenness" : 36.11626151626152,
        "shared_name" : "Jafar (cut11) Maleficent",
        "shared_interaction" : "cut11",
        "name" : "Jafar (cut11) Maleficent",
        "interaction" : "cut11",
        "SUID" : 1498,
        "BEND_MAP_ID" : 1498,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1497",
        "source" : "123",
        "target" : "400",
        "EdgeBetweenness" : 6.166666666666667,
        "shared_name" : "Jafar (cut8) Genie",
        "shared_interaction" : "cut8",
        "name" : "Jafar (cut8) Genie",
        "interaction" : "cut8",
        "SUID" : 1497,
        "BEND_MAP_ID" : 1497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1496",
        "source" : "123",
        "target" : "120",
        "EdgeBetweenness" : 15.419047619047616,
        "shared_name" : "Jafar (cut7) Jasmine",
        "shared_interaction" : "cut7",
        "name" : "Jafar (cut7) Jasmine",
        "interaction" : "cut7",
        "SUID" : 1496,
        "BEND_MAP_ID" : 1496,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1495",
        "source" : "123",
        "target" : "395",
        "EdgeBetweenness" : 3.5,
        "shared_name" : "Jafar (cut7) Aladdin",
        "shared_interaction" : "cut7",
        "name" : "Jafar (cut7) Aladdin",
        "interaction" : "cut7",
        "SUID" : 1495,
        "BEND_MAP_ID" : 1495,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1494",
        "source" : "123",
        "target" : "84",
        "EdgeBetweenness" : 127.37701742701748,
        "shared_name" : "Jafar (cut5) Sora",
        "shared_interaction" : "cut5",
        "name" : "Jafar (cut5) Sora",
        "interaction" : "cut5",
        "SUID" : 1494,
        "BEND_MAP_ID" : 1494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1493",
        "source" : "123",
        "target" : "84",
        "EdgeBetweenness" : 127.37701742701748,
        "shared_name" : "Jafar (cut4) Sora",
        "shared_interaction" : "cut4",
        "name" : "Jafar (cut4) Sora",
        "interaction" : "cut4",
        "SUID" : 1493,
        "BEND_MAP_ID" : 1493,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1492",
        "source" : "123",
        "target" : "120",
        "EdgeBetweenness" : 15.419047619047616,
        "shared_name" : "Jafar (cut4) Jasmine",
        "shared_interaction" : "cut4",
        "name" : "Jafar (cut4) Jasmine",
        "interaction" : "cut4",
        "SUID" : 1492,
        "BEND_MAP_ID" : 1492,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1491",
        "source" : "123",
        "target" : "106",
        "EdgeBetweenness" : 56.0063103563104,
        "shared_name" : "Jafar (cut4) Goofy",
        "shared_interaction" : "cut4",
        "name" : "Jafar (cut4) Goofy",
        "interaction" : "cut4",
        "SUID" : 1491,
        "BEND_MAP_ID" : 1491,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1490",
        "source" : "123",
        "target" : "76",
        "EdgeBetweenness" : 9.478571428571428,
        "shared_name" : "Jafar (cut4) ???????",
        "shared_interaction" : "cut4",
        "name" : "Jafar (cut4) ???????",
        "interaction" : "cut4",
        "SUID" : 1490,
        "BEND_MAP_ID" : 1490,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1489",
        "source" : "123",
        "target" : "98",
        "EdgeBetweenness" : 36.11626151626152,
        "shared_name" : "Jafar (cut1) Maleficent",
        "shared_interaction" : "cut1",
        "name" : "Jafar (cut1) Maleficent",
        "interaction" : "cut1",
        "SUID" : 1489,
        "BEND_MAP_ID" : 1489,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1488",
        "source" : "123",
        "target" : "1450",
        "EdgeBetweenness" : 71.07813852813854,
        "shared_name" : "Jafar (cut1) Iago",
        "shared_interaction" : "cut1",
        "name" : "Jafar (cut1) Iago",
        "interaction" : "cut1",
        "SUID" : 1488,
        "BEND_MAP_ID" : 1488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1529",
        "source" : "120",
        "target" : "558",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Jasmine (cut6) Aurora",
        "shared_interaction" : "cut6",
        "name" : "Jasmine (cut6) Aurora",
        "interaction" : "cut6",
        "SUID" : 1529,
        "BEND_MAP_ID" : 1529,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1528",
        "source" : "120",
        "target" : "265",
        "EdgeBetweenness" : 10.752380952380951,
        "shared_name" : "Jasmine (cut6) Alice",
        "shared_interaction" : "cut6",
        "name" : "Jasmine (cut6) Alice",
        "interaction" : "cut6",
        "SUID" : 1528,
        "BEND_MAP_ID" : 1528,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1527",
        "source" : "120",
        "target" : "562",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Jasmine (cut6) Snow White",
        "shared_interaction" : "cut6",
        "name" : "Jasmine (cut6) Snow White",
        "interaction" : "cut6",
        "SUID" : 1527,
        "BEND_MAP_ID" : 1527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1526",
        "source" : "120",
        "target" : "556",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Jasmine (cut6) Cinderella",
        "shared_interaction" : "cut6",
        "name" : "Jasmine (cut6) Cinderella",
        "interaction" : "cut6",
        "SUID" : 1526,
        "BEND_MAP_ID" : 1526,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1525",
        "source" : "120",
        "target" : "581",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Jasmine (cut5) Snow Whtie",
        "shared_interaction" : "cut5",
        "name" : "Jasmine (cut5) Snow Whtie",
        "interaction" : "cut5",
        "SUID" : 1525,
        "BEND_MAP_ID" : 1525,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1524",
        "source" : "120",
        "target" : "265",
        "EdgeBetweenness" : 10.752380952380951,
        "shared_name" : "Jasmine (cut5) Alice",
        "shared_interaction" : "cut5",
        "name" : "Jasmine (cut5) Alice",
        "interaction" : "cut5",
        "SUID" : 1524,
        "BEND_MAP_ID" : 1524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1523",
        "source" : "120",
        "target" : "556",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Jasmine (cut5) Cinderella",
        "shared_interaction" : "cut5",
        "name" : "Jasmine (cut5) Cinderella",
        "interaction" : "cut5",
        "SUID" : 1523,
        "BEND_MAP_ID" : 1523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1522",
        "source" : "120",
        "target" : "84",
        "EdgeBetweenness" : 89.43333333333335,
        "shared_name" : "Jasmine (cut5) Sora",
        "shared_interaction" : "cut5",
        "name" : "Jasmine (cut5) Sora",
        "interaction" : "cut5",
        "SUID" : 1522,
        "BEND_MAP_ID" : 1522,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1521",
        "source" : "120",
        "target" : "558",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Jasmine (cut5) Aurora",
        "shared_interaction" : "cut5",
        "name" : "Jasmine (cut5) Aurora",
        "interaction" : "cut5",
        "SUID" : 1521,
        "BEND_MAP_ID" : 1521,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1520",
        "source" : "120",
        "target" : "562",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Jasmine (cut5) Snow White",
        "shared_interaction" : "cut5",
        "name" : "Jasmine (cut5) Snow White",
        "interaction" : "cut5",
        "SUID" : 1520,
        "BEND_MAP_ID" : 1520,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1519",
        "source" : "120",
        "target" : "556",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Jasmine (cut4) Cinderella",
        "shared_interaction" : "cut4",
        "name" : "Jasmine (cut4) Cinderella",
        "interaction" : "cut4",
        "SUID" : 1519,
        "BEND_MAP_ID" : 1519,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1518",
        "source" : "120",
        "target" : "84",
        "EdgeBetweenness" : 89.43333333333335,
        "shared_name" : "Jasmine (cut4) Sora",
        "shared_interaction" : "cut4",
        "name" : "Jasmine (cut4) Sora",
        "interaction" : "cut4",
        "SUID" : 1518,
        "BEND_MAP_ID" : 1518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1517",
        "source" : "120",
        "target" : "558",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Jasmine (cut4) Aurora",
        "shared_interaction" : "cut4",
        "name" : "Jasmine (cut4) Aurora",
        "interaction" : "cut4",
        "SUID" : 1517,
        "BEND_MAP_ID" : 1517,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1516",
        "source" : "120",
        "target" : "265",
        "EdgeBetweenness" : 10.752380952380951,
        "shared_name" : "Jasmine (cut4) Alice",
        "shared_interaction" : "cut4",
        "name" : "Jasmine (cut4) Alice",
        "interaction" : "cut4",
        "SUID" : 1516,
        "BEND_MAP_ID" : 1516,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1515",
        "source" : "120",
        "target" : "556",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Jasmine (cut3) Cinderella",
        "shared_interaction" : "cut3",
        "name" : "Jasmine (cut3) Cinderella",
        "interaction" : "cut3",
        "SUID" : 1515,
        "BEND_MAP_ID" : 1515,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1514",
        "source" : "120",
        "target" : "558",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Jasmine (cut3) Aurora",
        "shared_interaction" : "cut3",
        "name" : "Jasmine (cut3) Aurora",
        "interaction" : "cut3",
        "SUID" : 1514,
        "BEND_MAP_ID" : 1514,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1513",
        "source" : "120",
        "target" : "84",
        "EdgeBetweenness" : 89.43333333333335,
        "shared_name" : "Jasmine (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Jasmine (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 1513,
        "BEND_MAP_ID" : 1513,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1512",
        "source" : "120",
        "target" : "562",
        "EdgeBetweenness" : 8.466666666666667,
        "shared_name" : "Jasmine (cut3) Snow White",
        "shared_interaction" : "cut3",
        "name" : "Jasmine (cut3) Snow White",
        "interaction" : "cut3",
        "SUID" : 1512,
        "BEND_MAP_ID" : 1512,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1511",
        "source" : "120",
        "target" : "265",
        "EdgeBetweenness" : 10.752380952380951,
        "shared_name" : "Jasmine (cut3) Alice",
        "shared_interaction" : "cut3",
        "name" : "Jasmine (cut3) Alice",
        "interaction" : "cut3",
        "SUID" : 1511,
        "BEND_MAP_ID" : 1511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1510",
        "source" : "120",
        "target" : "395",
        "EdgeBetweenness" : 12.299999999999999,
        "shared_name" : "Jasmine (cut2) Aladdin",
        "shared_interaction" : "cut2",
        "name" : "Jasmine (cut2) Aladdin",
        "interaction" : "cut2",
        "SUID" : 1510,
        "BEND_MAP_ID" : 1510,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1509",
        "source" : "120",
        "target" : "123",
        "EdgeBetweenness" : 15.419047619047616,
        "shared_name" : "Jasmine (cut2) Jafar",
        "shared_interaction" : "cut2",
        "name" : "Jasmine (cut2) Jafar",
        "interaction" : "cut2",
        "SUID" : 1509,
        "BEND_MAP_ID" : 1509,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1508",
        "source" : "120",
        "target" : "123",
        "EdgeBetweenness" : 15.419047619047616,
        "shared_name" : "Jasmine (cut1) Jafar",
        "shared_interaction" : "cut1",
        "name" : "Jasmine (cut1) Jafar",
        "interaction" : "cut1",
        "SUID" : 1508,
        "BEND_MAP_ID" : 1508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1507",
        "source" : "120",
        "target" : "84",
        "EdgeBetweenness" : 89.43333333333335,
        "shared_name" : "Jasmine (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Jasmine (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1507,
        "BEND_MAP_ID" : 1507,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1506",
        "source" : "120",
        "target" : "106",
        "EdgeBetweenness" : 53.716666666666676,
        "shared_name" : "Jasmine (cut1) Goofy",
        "shared_interaction" : "cut1",
        "name" : "Jasmine (cut1) Goofy",
        "interaction" : "cut1",
        "SUID" : 1506,
        "BEND_MAP_ID" : 1506,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1505",
        "source" : "120",
        "target" : "76",
        "EdgeBetweenness" : 10.483333333333334,
        "shared_name" : "Jasmine (cut1) ???????",
        "shared_interaction" : "cut1",
        "name" : "Jasmine (cut1) ???????",
        "interaction" : "cut1",
        "SUID" : 1505,
        "BEND_MAP_ID" : 1505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1392",
        "source" : "117",
        "target" : "328",
        "EdgeBetweenness" : 3.3333333333333335,
        "shared_name" : "Jane (cut19) Tarzan",
        "shared_interaction" : "cut19",
        "name" : "Jane (cut19) Tarzan",
        "interaction" : "cut19",
        "SUID" : 1392,
        "BEND_MAP_ID" : 1392,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1391",
        "source" : "117",
        "target" : "114",
        "EdgeBetweenness" : 34.21688311688311,
        "shared_name" : "Jane (cut19) Donald",
        "shared_interaction" : "cut19",
        "name" : "Jane (cut19) Donald",
        "interaction" : "cut19",
        "SUID" : 1391,
        "BEND_MAP_ID" : 1391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1390",
        "source" : "117",
        "target" : "84",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Jane (cut19) Sora",
        "shared_interaction" : "cut19",
        "name" : "Jane (cut19) Sora",
        "interaction" : "cut19",
        "SUID" : 1390,
        "BEND_MAP_ID" : 1390,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1389",
        "source" : "117",
        "target" : "106",
        "EdgeBetweenness" : 39.616883116883116,
        "shared_name" : "Jane (cut17) Goofy",
        "shared_interaction" : "cut17",
        "name" : "Jane (cut17) Goofy",
        "interaction" : "cut17",
        "SUID" : 1389,
        "BEND_MAP_ID" : 1389,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1388",
        "source" : "117",
        "target" : "114",
        "EdgeBetweenness" : 34.21688311688311,
        "shared_name" : "Jane (cut17) Donald",
        "shared_interaction" : "cut17",
        "name" : "Jane (cut17) Donald",
        "interaction" : "cut17",
        "SUID" : 1388,
        "BEND_MAP_ID" : 1388,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1387",
        "source" : "117",
        "target" : "84",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Jane (cut17) Sora",
        "shared_interaction" : "cut17",
        "name" : "Jane (cut17) Sora",
        "interaction" : "cut17",
        "SUID" : 1387,
        "BEND_MAP_ID" : 1387,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1386",
        "source" : "117",
        "target" : "328",
        "EdgeBetweenness" : 3.3333333333333335,
        "shared_name" : "Jane (cut17) Tarzan",
        "shared_interaction" : "cut17",
        "name" : "Jane (cut17) Tarzan",
        "interaction" : "cut17",
        "SUID" : 1386,
        "BEND_MAP_ID" : 1386,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1385",
        "source" : "117",
        "target" : "328",
        "EdgeBetweenness" : 3.3333333333333335,
        "shared_name" : "Jane (cut15) Tarzan",
        "shared_interaction" : "cut15",
        "name" : "Jane (cut15) Tarzan",
        "interaction" : "cut15",
        "SUID" : 1385,
        "BEND_MAP_ID" : 1385,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1384",
        "source" : "117",
        "target" : "84",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Jane (cut15) Sora",
        "shared_interaction" : "cut15",
        "name" : "Jane (cut15) Sora",
        "interaction" : "cut15",
        "SUID" : 1384,
        "BEND_MAP_ID" : 1384,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1383",
        "source" : "117",
        "target" : "325",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "Jane (cut11) Clayton",
        "shared_interaction" : "cut11",
        "name" : "Jane (cut11) Clayton",
        "interaction" : "cut11",
        "SUID" : 1383,
        "BEND_MAP_ID" : 1383,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1382",
        "source" : "117",
        "target" : "325",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "Jane (cut10) Clayton",
        "shared_interaction" : "cut10",
        "name" : "Jane (cut10) Clayton",
        "interaction" : "cut10",
        "SUID" : 1382,
        "BEND_MAP_ID" : 1382,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1381",
        "source" : "117",
        "target" : "328",
        "EdgeBetweenness" : 3.3333333333333335,
        "shared_name" : "Jane (cut10) Tarzan",
        "shared_interaction" : "cut10",
        "name" : "Jane (cut10) Tarzan",
        "interaction" : "cut10",
        "SUID" : 1381,
        "BEND_MAP_ID" : 1381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1380",
        "source" : "117",
        "target" : "325",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "Jane (cut9) Clayton",
        "shared_interaction" : "cut9",
        "name" : "Jane (cut9) Clayton",
        "interaction" : "cut9",
        "SUID" : 1380,
        "BEND_MAP_ID" : 1380,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1379",
        "source" : "117",
        "target" : "84",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Jane (cut8) Sora",
        "shared_interaction" : "cut8",
        "name" : "Jane (cut8) Sora",
        "interaction" : "cut8",
        "SUID" : 1379,
        "BEND_MAP_ID" : 1379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1378",
        "source" : "117",
        "target" : "84",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Jane (cut7) Sora",
        "shared_interaction" : "cut7",
        "name" : "Jane (cut7) Sora",
        "interaction" : "cut7",
        "SUID" : 1378,
        "BEND_MAP_ID" : 1378,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1377",
        "source" : "117",
        "target" : "106",
        "EdgeBetweenness" : 39.616883116883116,
        "shared_name" : "Jane (cut6) Goofy",
        "shared_interaction" : "cut6",
        "name" : "Jane (cut6) Goofy",
        "interaction" : "cut6",
        "SUID" : 1377,
        "BEND_MAP_ID" : 1377,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1376",
        "source" : "117",
        "target" : "317",
        "EdgeBetweenness" : 5.666666666666665,
        "shared_name" : "Jane (cut6) Donald & Sora",
        "shared_interaction" : "cut6",
        "name" : "Jane (cut6) Donald & Sora",
        "interaction" : "cut6",
        "SUID" : 1376,
        "BEND_MAP_ID" : 1376,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1375",
        "source" : "117",
        "target" : "84",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Jane (cut6) Sora",
        "shared_interaction" : "cut6",
        "name" : "Jane (cut6) Sora",
        "interaction" : "cut6",
        "SUID" : 1375,
        "BEND_MAP_ID" : 1375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1374",
        "source" : "117",
        "target" : "76",
        "EdgeBetweenness" : 8.9008658008658,
        "shared_name" : "Jane (cut4) ???????",
        "shared_interaction" : "cut4",
        "name" : "Jane (cut4) ???????",
        "interaction" : "cut4",
        "SUID" : 1374,
        "BEND_MAP_ID" : 1374,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1373",
        "source" : "117",
        "target" : "84",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Jane (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Jane (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1373,
        "BEND_MAP_ID" : 1373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "880",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut130) Goofy",
        "shared_interaction" : "cut130",
        "name" : "Donald (cut130) Goofy",
        "interaction" : "cut130",
        "SUID" : 880,
        "BEND_MAP_ID" : 880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "879",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut130) Sora",
        "shared_interaction" : "cut130",
        "name" : "Donald (cut130) Sora",
        "interaction" : "cut130",
        "SUID" : 879,
        "BEND_MAP_ID" : 879,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "878",
        "source" : "114",
        "target" : "96",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Donald (cut127) Riku",
        "shared_interaction" : "cut127",
        "name" : "Donald (cut127) Riku",
        "interaction" : "cut127",
        "SUID" : 878,
        "BEND_MAP_ID" : 878,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "877",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut127) Goofy",
        "shared_interaction" : "cut127",
        "name" : "Donald (cut127) Goofy",
        "interaction" : "cut127",
        "SUID" : 877,
        "BEND_MAP_ID" : 877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "876",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut127) Sora",
        "shared_interaction" : "cut127",
        "name" : "Donald (cut127) Sora",
        "interaction" : "cut127",
        "SUID" : 876,
        "BEND_MAP_ID" : 876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "875",
        "source" : "114",
        "target" : "603",
        "EdgeBetweenness" : 27.099633699633696,
        "shared_name" : "Donald (cut127) Mickey",
        "shared_interaction" : "cut127",
        "name" : "Donald (cut127) Mickey",
        "interaction" : "cut127",
        "SUID" : 875,
        "BEND_MAP_ID" : 875,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "874",
        "source" : "114",
        "target" : "173",
        "EdgeBetweenness" : 39.210606060606075,
        "shared_name" : "Donald (cut125) Donald & Goofy",
        "shared_interaction" : "cut125",
        "name" : "Donald (cut125) Donald & Goofy",
        "interaction" : "cut125",
        "SUID" : 874,
        "BEND_MAP_ID" : 874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "873",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut122) Goofy",
        "shared_interaction" : "cut122",
        "name" : "Donald (cut122) Goofy",
        "interaction" : "cut122",
        "SUID" : 873,
        "BEND_MAP_ID" : 873,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "872",
        "source" : "114",
        "target" : "72",
        "EdgeBetweenness" : 39.16666666666667,
        "shared_name" : "Donald (cut120) Voice",
        "shared_interaction" : "cut120",
        "name" : "Donald (cut120) Voice",
        "interaction" : "cut120",
        "SUID" : 872,
        "BEND_MAP_ID" : 872,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "871",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut120) Sora",
        "shared_interaction" : "cut120",
        "name" : "Donald (cut120) Sora",
        "interaction" : "cut120",
        "SUID" : 871,
        "BEND_MAP_ID" : 871,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "870",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut119) Goofy",
        "shared_interaction" : "cut119",
        "name" : "Donald (cut119) Goofy",
        "interaction" : "cut119",
        "SUID" : 870,
        "BEND_MAP_ID" : 870,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "869",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut118) Sora",
        "shared_interaction" : "cut118",
        "name" : "Donald (cut118) Sora",
        "interaction" : "cut118",
        "SUID" : 869,
        "BEND_MAP_ID" : 869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "868",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut118) Goofy",
        "shared_interaction" : "cut118",
        "name" : "Donald (cut118) Goofy",
        "interaction" : "cut118",
        "SUID" : 868,
        "BEND_MAP_ID" : 868,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "867",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut117) Sora",
        "shared_interaction" : "cut117",
        "name" : "Donald (cut117) Sora",
        "interaction" : "cut117",
        "SUID" : 867,
        "BEND_MAP_ID" : 867,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "866",
        "source" : "114",
        "target" : "177",
        "EdgeBetweenness" : 26.99783549783549,
        "shared_name" : "Donald (cut117) Yuffie",
        "shared_interaction" : "cut117",
        "name" : "Donald (cut117) Yuffie",
        "interaction" : "cut117",
        "SUID" : 866,
        "BEND_MAP_ID" : 866,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "865",
        "source" : "114",
        "target" : "179",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Donald (cut117) Aerith",
        "shared_interaction" : "cut117",
        "name" : "Donald (cut117) Aerith",
        "interaction" : "cut117",
        "SUID" : 865,
        "BEND_MAP_ID" : 865,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "864",
        "source" : "114",
        "target" : "175",
        "EdgeBetweenness" : 26.09783549783549,
        "shared_name" : "Donald (cut117) Leon",
        "shared_interaction" : "cut117",
        "name" : "Donald (cut117) Leon",
        "interaction" : "cut117",
        "SUID" : 864,
        "BEND_MAP_ID" : 864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "863",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut116) Goofy",
        "shared_interaction" : "cut116",
        "name" : "Donald (cut116) Goofy",
        "interaction" : "cut116",
        "SUID" : 863,
        "BEND_MAP_ID" : 863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "862",
        "source" : "114",
        "target" : "534",
        "EdgeBetweenness" : 27.09963369963369,
        "shared_name" : "Donald (cut116) Beast",
        "shared_interaction" : "cut116",
        "name" : "Donald (cut116) Beast",
        "interaction" : "cut116",
        "SUID" : 862,
        "BEND_MAP_ID" : 862,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "861",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut116) Sora",
        "shared_interaction" : "cut116",
        "name" : "Donald (cut116) Sora",
        "interaction" : "cut116",
        "SUID" : 861,
        "BEND_MAP_ID" : 861,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "860",
        "source" : "114",
        "target" : "82",
        "EdgeBetweenness" : 23.699999999999996,
        "shared_name" : "Donald (cut111) Kairi",
        "shared_interaction" : "cut111",
        "name" : "Donald (cut111) Kairi",
        "interaction" : "cut111",
        "SUID" : 860,
        "BEND_MAP_ID" : 860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "859",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut111) Goofy",
        "shared_interaction" : "cut111",
        "name" : "Donald (cut111) Goofy",
        "interaction" : "cut111",
        "SUID" : 859,
        "BEND_MAP_ID" : 859,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "858",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut110) Goofy",
        "shared_interaction" : "cut110",
        "name" : "Donald (cut110) Goofy",
        "interaction" : "cut110",
        "SUID" : 858,
        "BEND_MAP_ID" : 858,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "857",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut109) Goofy",
        "shared_interaction" : "cut109",
        "name" : "Donald (cut109) Goofy",
        "interaction" : "cut109",
        "SUID" : 857,
        "BEND_MAP_ID" : 857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "856",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut106) Goofy",
        "shared_interaction" : "cut106",
        "name" : "Donald (cut106) Goofy",
        "interaction" : "cut106",
        "SUID" : 856,
        "BEND_MAP_ID" : 856,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "855",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut105) Goofy",
        "shared_interaction" : "cut105",
        "name" : "Donald (cut105) Goofy",
        "interaction" : "cut105",
        "SUID" : 855,
        "BEND_MAP_ID" : 855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "854",
        "source" : "114",
        "target" : "96",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Donald (cut104) Riku",
        "shared_interaction" : "cut104",
        "name" : "Donald (cut104) Riku",
        "interaction" : "cut104",
        "SUID" : 854,
        "BEND_MAP_ID" : 854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "853",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut104) Sora",
        "shared_interaction" : "cut104",
        "name" : "Donald (cut104) Sora",
        "interaction" : "cut104",
        "SUID" : 853,
        "BEND_MAP_ID" : 853,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "852",
        "source" : "114",
        "target" : "96",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Donald (cut103) Riku",
        "shared_interaction" : "cut103",
        "name" : "Donald (cut103) Riku",
        "interaction" : "cut103",
        "SUID" : 852,
        "BEND_MAP_ID" : 852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "851",
        "source" : "114",
        "target" : "96",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Donald (cut102) Riku",
        "shared_interaction" : "cut102",
        "name" : "Donald (cut102) Riku",
        "interaction" : "cut102",
        "SUID" : 851,
        "BEND_MAP_ID" : 851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "850",
        "source" : "114",
        "target" : "96",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Donald (cut101) Riku",
        "shared_interaction" : "cut101",
        "name" : "Donald (cut101) Riku",
        "interaction" : "cut101",
        "SUID" : 850,
        "BEND_MAP_ID" : 850,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "849",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut101) Sora",
        "shared_interaction" : "cut101",
        "name" : "Donald (cut101) Sora",
        "interaction" : "cut101",
        "SUID" : 849,
        "BEND_MAP_ID" : 849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "848",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut101) Goofy",
        "shared_interaction" : "cut101",
        "name" : "Donald (cut101) Goofy",
        "interaction" : "cut101",
        "SUID" : 848,
        "BEND_MAP_ID" : 848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "847",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut100) Goofy",
        "shared_interaction" : "cut100",
        "name" : "Donald (cut100) Goofy",
        "interaction" : "cut100",
        "SUID" : 847,
        "BEND_MAP_ID" : 847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "846",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut98) Goofy",
        "shared_interaction" : "cut98",
        "name" : "Donald (cut98) Goofy",
        "interaction" : "cut98",
        "SUID" : 846,
        "BEND_MAP_ID" : 846,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "845",
        "source" : "114",
        "target" : "844",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Donald (cut97) Sora & Goofy",
        "shared_interaction" : "cut97",
        "name" : "Donald (cut97) Sora & Goofy",
        "interaction" : "cut97",
        "SUID" : 845,
        "BEND_MAP_ID" : 845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "843",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut96) Sora",
        "shared_interaction" : "cut96",
        "name" : "Donald (cut96) Sora",
        "interaction" : "cut96",
        "SUID" : 843,
        "BEND_MAP_ID" : 843,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "842",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut95) Goofy",
        "shared_interaction" : "cut95",
        "name" : "Donald (cut95) Goofy",
        "interaction" : "cut95",
        "SUID" : 842,
        "BEND_MAP_ID" : 842,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "841",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut95) Sora",
        "shared_interaction" : "cut95",
        "name" : "Donald (cut95) Sora",
        "interaction" : "cut95",
        "SUID" : 841,
        "BEND_MAP_ID" : 841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "840",
        "source" : "114",
        "target" : "443",
        "EdgeBetweenness" : 30.34871794871794,
        "shared_name" : "Donald (cut95) Hercules",
        "shared_interaction" : "cut95",
        "name" : "Donald (cut95) Hercules",
        "interaction" : "cut95",
        "SUID" : 840,
        "BEND_MAP_ID" : 840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "839",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut94) Sora",
        "shared_interaction" : "cut94",
        "name" : "Donald (cut94) Sora",
        "interaction" : "cut94",
        "SUID" : 839,
        "BEND_MAP_ID" : 839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "838",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut94) Goofy",
        "shared_interaction" : "cut94",
        "name" : "Donald (cut94) Goofy",
        "interaction" : "cut94",
        "SUID" : 838,
        "BEND_MAP_ID" : 838,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "837",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut93) Sora",
        "shared_interaction" : "cut93",
        "name" : "Donald (cut93) Sora",
        "interaction" : "cut93",
        "SUID" : 837,
        "BEND_MAP_ID" : 837,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "836",
        "source" : "114",
        "target" : "78",
        "EdgeBetweenness" : 34.23235098235098,
        "shared_name" : "Donald (cut91) ?????",
        "shared_interaction" : "cut91",
        "name" : "Donald (cut91) ?????",
        "interaction" : "cut91",
        "SUID" : 836,
        "BEND_MAP_ID" : 836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "835",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut90) Sora",
        "shared_interaction" : "cut90",
        "name" : "Donald (cut90) Sora",
        "interaction" : "cut90",
        "SUID" : 835,
        "BEND_MAP_ID" : 835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "834",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut90) Goofy",
        "shared_interaction" : "cut90",
        "name" : "Donald (cut90) Goofy",
        "interaction" : "cut90",
        "SUID" : 834,
        "BEND_MAP_ID" : 834,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "833",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut88) Sora",
        "shared_interaction" : "cut88",
        "name" : "Donald (cut88) Sora",
        "interaction" : "cut88",
        "SUID" : 833,
        "BEND_MAP_ID" : 833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "832",
        "source" : "114",
        "target" : "471",
        "EdgeBetweenness" : 58.412698412698404,
        "shared_name" : "Donald (cut88) Finkelstein",
        "shared_interaction" : "cut88",
        "name" : "Donald (cut88) Finkelstein",
        "interaction" : "cut88",
        "SUID" : 832,
        "BEND_MAP_ID" : 832,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "831",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut87) Goofy",
        "shared_interaction" : "cut87",
        "name" : "Donald (cut87) Goofy",
        "interaction" : "cut87",
        "SUID" : 831,
        "BEND_MAP_ID" : 831,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "830",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut86) Goofy",
        "shared_interaction" : "cut86",
        "name" : "Donald (cut86) Goofy",
        "interaction" : "cut86",
        "SUID" : 830,
        "BEND_MAP_ID" : 830,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "829",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut86) Sora",
        "shared_interaction" : "cut86",
        "name" : "Donald (cut86) Sora",
        "interaction" : "cut86",
        "SUID" : 829,
        "BEND_MAP_ID" : 829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "828",
        "source" : "114",
        "target" : "136",
        "EdgeBetweenness" : 55.86926406926408,
        "shared_name" : "Donald (cut85) Sebastian",
        "shared_interaction" : "cut85",
        "name" : "Donald (cut85) Sebastian",
        "interaction" : "cut85",
        "SUID" : 828,
        "BEND_MAP_ID" : 828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "827",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut84) Sora",
        "shared_interaction" : "cut84",
        "name" : "Donald (cut84) Sora",
        "interaction" : "cut84",
        "SUID" : 827,
        "BEND_MAP_ID" : 827,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "826",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut83) Sora",
        "shared_interaction" : "cut83",
        "name" : "Donald (cut83) Sora",
        "interaction" : "cut83",
        "SUID" : 826,
        "BEND_MAP_ID" : 826,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "825",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut83) Goofy",
        "shared_interaction" : "cut83",
        "name" : "Donald (cut83) Goofy",
        "interaction" : "cut83",
        "SUID" : 825,
        "BEND_MAP_ID" : 825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "824",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut82) Sora",
        "shared_interaction" : "cut82",
        "name" : "Donald (cut82) Sora",
        "interaction" : "cut82",
        "SUID" : 824,
        "BEND_MAP_ID" : 824,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "823",
        "source" : "114",
        "target" : "387",
        "EdgeBetweenness" : 42.86666666666667,
        "shared_name" : "Donald (cut81) Pinocchio",
        "shared_interaction" : "cut81",
        "name" : "Donald (cut81) Pinocchio",
        "interaction" : "cut81",
        "SUID" : 823,
        "BEND_MAP_ID" : 823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "822",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut77) Sora",
        "shared_interaction" : "cut77",
        "name" : "Donald (cut77) Sora",
        "interaction" : "cut77",
        "SUID" : 822,
        "BEND_MAP_ID" : 822,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "821",
        "source" : "114",
        "target" : "395",
        "EdgeBetweenness" : 40.246103896103904,
        "shared_name" : "Donald (cut76) Aladdin",
        "shared_interaction" : "cut76",
        "name" : "Donald (cut76) Aladdin",
        "interaction" : "cut76",
        "SUID" : 821,
        "BEND_MAP_ID" : 821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "820",
        "source" : "114",
        "target" : "400",
        "EdgeBetweenness" : 28.399999999999984,
        "shared_name" : "Donald (cut76) Genie",
        "shared_interaction" : "cut76",
        "name" : "Donald (cut76) Genie",
        "interaction" : "cut76",
        "SUID" : 820,
        "BEND_MAP_ID" : 820,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "819",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut76) Sora",
        "shared_interaction" : "cut76",
        "name" : "Donald (cut76) Sora",
        "interaction" : "cut76",
        "SUID" : 819,
        "BEND_MAP_ID" : 819,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "818",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut76) Goofy",
        "shared_interaction" : "cut76",
        "name" : "Donald (cut76) Goofy",
        "interaction" : "cut76",
        "SUID" : 818,
        "BEND_MAP_ID" : 818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "817",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut75) Goofy",
        "shared_interaction" : "cut75",
        "name" : "Donald (cut75) Goofy",
        "interaction" : "cut75",
        "SUID" : 817,
        "BEND_MAP_ID" : 817,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "816",
        "source" : "114",
        "target" : "123",
        "EdgeBetweenness" : 43.98964368964369,
        "shared_name" : "Donald (cut75) Jafar",
        "shared_interaction" : "cut75",
        "name" : "Donald (cut75) Jafar",
        "interaction" : "cut75",
        "SUID" : 816,
        "BEND_MAP_ID" : 816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "815",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut74) Sora",
        "shared_interaction" : "cut74",
        "name" : "Donald (cut74) Sora",
        "interaction" : "cut74",
        "SUID" : 815,
        "BEND_MAP_ID" : 815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "814",
        "source" : "114",
        "target" : "400",
        "EdgeBetweenness" : 28.399999999999984,
        "shared_name" : "Donald (cut74) Genie",
        "shared_interaction" : "cut74",
        "name" : "Donald (cut74) Genie",
        "interaction" : "cut74",
        "SUID" : 814,
        "BEND_MAP_ID" : 814,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "813",
        "source" : "114",
        "target" : "395",
        "EdgeBetweenness" : 40.246103896103904,
        "shared_name" : "Donald (cut74) Aladdin",
        "shared_interaction" : "cut74",
        "name" : "Donald (cut74) Aladdin",
        "interaction" : "cut74",
        "SUID" : 813,
        "BEND_MAP_ID" : 813,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "812",
        "source" : "114",
        "target" : "395",
        "EdgeBetweenness" : 40.246103896103904,
        "shared_name" : "Donald (cut73) Aladdin",
        "shared_interaction" : "cut73",
        "name" : "Donald (cut73) Aladdin",
        "interaction" : "cut73",
        "SUID" : 812,
        "BEND_MAP_ID" : 812,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "811",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut73) Sora",
        "shared_interaction" : "cut73",
        "name" : "Donald (cut73) Sora",
        "interaction" : "cut73",
        "SUID" : 811,
        "BEND_MAP_ID" : 811,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "810",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut73) Goofy",
        "shared_interaction" : "cut73",
        "name" : "Donald (cut73) Goofy",
        "interaction" : "cut73",
        "SUID" : 810,
        "BEND_MAP_ID" : 810,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "809",
        "source" : "114",
        "target" : "400",
        "EdgeBetweenness" : 28.399999999999984,
        "shared_name" : "Donald (cut72) Genie",
        "shared_interaction" : "cut72",
        "name" : "Donald (cut72) Genie",
        "interaction" : "cut72",
        "SUID" : 809,
        "BEND_MAP_ID" : 809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "808",
        "source" : "114",
        "target" : "179",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Donald (cut70) Aerith",
        "shared_interaction" : "cut70",
        "name" : "Donald (cut70) Aerith",
        "interaction" : "cut70",
        "SUID" : 808,
        "BEND_MAP_ID" : 808,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "807",
        "source" : "114",
        "target" : "175",
        "EdgeBetweenness" : 26.09783549783549,
        "shared_name" : "Donald (cut70) Leon",
        "shared_interaction" : "cut70",
        "name" : "Donald (cut70) Leon",
        "interaction" : "cut70",
        "SUID" : 807,
        "BEND_MAP_ID" : 807,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "806",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut70) Sora",
        "shared_interaction" : "cut70",
        "name" : "Donald (cut70) Sora",
        "interaction" : "cut70",
        "SUID" : 806,
        "BEND_MAP_ID" : 806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "805",
        "source" : "114",
        "target" : "220",
        "EdgeBetweenness" : 28.082051282051275,
        "shared_name" : "Donald (cut70) Cid",
        "shared_interaction" : "cut70",
        "name" : "Donald (cut70) Cid",
        "interaction" : "cut70",
        "SUID" : 805,
        "BEND_MAP_ID" : 805,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "804",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut69) Sora",
        "shared_interaction" : "cut69",
        "name" : "Donald (cut69) Sora",
        "interaction" : "cut69",
        "SUID" : 804,
        "BEND_MAP_ID" : 804,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "803",
        "source" : "114",
        "target" : "96",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Donald (cut68) Riku",
        "shared_interaction" : "cut68",
        "name" : "Donald (cut68) Riku",
        "interaction" : "cut68",
        "SUID" : 803,
        "BEND_MAP_ID" : 803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "802",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut68) Sora",
        "shared_interaction" : "cut68",
        "name" : "Donald (cut68) Sora",
        "interaction" : "cut68",
        "SUID" : 802,
        "BEND_MAP_ID" : 802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "801",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut68) Goofy",
        "shared_interaction" : "cut68",
        "name" : "Donald (cut68) Goofy",
        "interaction" : "cut68",
        "SUID" : 801,
        "BEND_MAP_ID" : 801,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "800",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut67) Sora",
        "shared_interaction" : "cut67",
        "name" : "Donald (cut67) Sora",
        "interaction" : "cut67",
        "SUID" : 800,
        "BEND_MAP_ID" : 800,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "799",
        "source" : "114",
        "target" : "96",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Donald (cut67) Riku",
        "shared_interaction" : "cut67",
        "name" : "Donald (cut67) Riku",
        "interaction" : "cut67",
        "SUID" : 799,
        "BEND_MAP_ID" : 799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "798",
        "source" : "114",
        "target" : "133",
        "EdgeBetweenness" : 27.357142857142836,
        "shared_name" : "Donald (cut66) Merlin",
        "shared_interaction" : "cut66",
        "name" : "Donald (cut66) Merlin",
        "interaction" : "cut66",
        "SUID" : 798,
        "BEND_MAP_ID" : 798,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "797",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut66) Goofy",
        "shared_interaction" : "cut66",
        "name" : "Donald (cut66) Goofy",
        "interaction" : "cut66",
        "SUID" : 797,
        "BEND_MAP_ID" : 797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "796",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut66) Sora",
        "shared_interaction" : "cut66",
        "name" : "Donald (cut66) Sora",
        "interaction" : "cut66",
        "SUID" : 796,
        "BEND_MAP_ID" : 796,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "795",
        "source" : "114",
        "target" : "222",
        "EdgeBetweenness" : 43.45814740814741,
        "shared_name" : "Donald (cut66) ??????",
        "shared_interaction" : "cut66",
        "name" : "Donald (cut66) ??????",
        "interaction" : "cut66",
        "SUID" : 795,
        "BEND_MAP_ID" : 795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "794",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut65) Sora",
        "shared_interaction" : "cut65",
        "name" : "Donald (cut65) Sora",
        "interaction" : "cut65",
        "SUID" : 794,
        "BEND_MAP_ID" : 794,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "793",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut65) Goofy",
        "shared_interaction" : "cut65",
        "name" : "Donald (cut65) Goofy",
        "interaction" : "cut65",
        "SUID" : 793,
        "BEND_MAP_ID" : 793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "792",
        "source" : "114",
        "target" : "220",
        "EdgeBetweenness" : 28.082051282051275,
        "shared_name" : "Donald (cut65) Cid",
        "shared_interaction" : "cut65",
        "name" : "Donald (cut65) Cid",
        "interaction" : "cut65",
        "SUID" : 792,
        "BEND_MAP_ID" : 792,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "791",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut64) Goofy",
        "shared_interaction" : "cut64",
        "name" : "Donald (cut64) Goofy",
        "interaction" : "cut64",
        "SUID" : 791,
        "BEND_MAP_ID" : 791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "790",
        "source" : "114",
        "target" : "345",
        "EdgeBetweenness" : 28.54871794871794,
        "shared_name" : "Donald (cut64) Sora, Donald & Goofy",
        "shared_interaction" : "cut64",
        "name" : "Donald (cut64) Sora, Donald & Goofy",
        "interaction" : "cut64",
        "SUID" : 790,
        "BEND_MAP_ID" : 790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "789",
        "source" : "114",
        "target" : "179",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Donald (cut64) Aerith",
        "shared_interaction" : "cut64",
        "name" : "Donald (cut64) Aerith",
        "interaction" : "cut64",
        "SUID" : 789,
        "BEND_MAP_ID" : 789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "788",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut64) Sora",
        "shared_interaction" : "cut64",
        "name" : "Donald (cut64) Sora",
        "interaction" : "cut64",
        "SUID" : 788,
        "BEND_MAP_ID" : 788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "787",
        "source" : "114",
        "target" : "175",
        "EdgeBetweenness" : 26.09783549783549,
        "shared_name" : "Donald (cut64) Leon",
        "shared_interaction" : "cut64",
        "name" : "Donald (cut64) Leon",
        "interaction" : "cut64",
        "SUID" : 787,
        "BEND_MAP_ID" : 787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "786",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut63) Goofy",
        "shared_interaction" : "cut63",
        "name" : "Donald (cut63) Goofy",
        "interaction" : "cut63",
        "SUID" : 786,
        "BEND_MAP_ID" : 786,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "785",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut63) Sora",
        "shared_interaction" : "cut63",
        "name" : "Donald (cut63) Sora",
        "interaction" : "cut63",
        "SUID" : 785,
        "BEND_MAP_ID" : 785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "784",
        "source" : "114",
        "target" : "328",
        "EdgeBetweenness" : 32.34871794871795,
        "shared_name" : "Donald (cut62) Tarzan",
        "shared_interaction" : "cut62",
        "name" : "Donald (cut62) Tarzan",
        "interaction" : "cut62",
        "SUID" : 784,
        "BEND_MAP_ID" : 784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "783",
        "source" : "114",
        "target" : "117",
        "EdgeBetweenness" : 34.21688311688311,
        "shared_name" : "Donald (cut62) Jane",
        "shared_interaction" : "cut62",
        "name" : "Donald (cut62) Jane",
        "interaction" : "cut62",
        "SUID" : 783,
        "BEND_MAP_ID" : 783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "782",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut62) Sora",
        "shared_interaction" : "cut62",
        "name" : "Donald (cut62) Sora",
        "interaction" : "cut62",
        "SUID" : 782,
        "BEND_MAP_ID" : 782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "781",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut60) Goofy",
        "shared_interaction" : "cut60",
        "name" : "Donald (cut60) Goofy",
        "interaction" : "cut60",
        "SUID" : 781,
        "BEND_MAP_ID" : 781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "780",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut59) Goofy",
        "shared_interaction" : "cut59",
        "name" : "Donald (cut59) Goofy",
        "interaction" : "cut59",
        "SUID" : 780,
        "BEND_MAP_ID" : 780,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "779",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut59) Sora",
        "shared_interaction" : "cut59",
        "name" : "Donald (cut59) Sora",
        "interaction" : "cut59",
        "SUID" : 779,
        "BEND_MAP_ID" : 779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "778",
        "source" : "114",
        "target" : "117",
        "EdgeBetweenness" : 34.21688311688311,
        "shared_name" : "Donald (cut59) Jane",
        "shared_interaction" : "cut59",
        "name" : "Donald (cut59) Jane",
        "interaction" : "cut59",
        "SUID" : 778,
        "BEND_MAP_ID" : 778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "777",
        "source" : "114",
        "target" : "328",
        "EdgeBetweenness" : 32.34871794871795,
        "shared_name" : "Donald (cut59) Tarzan",
        "shared_interaction" : "cut59",
        "name" : "Donald (cut59) Tarzan",
        "interaction" : "cut59",
        "SUID" : 777,
        "BEND_MAP_ID" : 777,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "776",
        "source" : "114",
        "target" : "328",
        "EdgeBetweenness" : 32.34871794871795,
        "shared_name" : "Donald (cut58) Tarzan",
        "shared_interaction" : "cut58",
        "name" : "Donald (cut58) Tarzan",
        "interaction" : "cut58",
        "SUID" : 776,
        "BEND_MAP_ID" : 776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "775",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut58) Goofy",
        "shared_interaction" : "cut58",
        "name" : "Donald (cut58) Goofy",
        "interaction" : "cut58",
        "SUID" : 775,
        "BEND_MAP_ID" : 775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "774",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut58) Sora",
        "shared_interaction" : "cut58",
        "name" : "Donald (cut58) Sora",
        "interaction" : "cut58",
        "SUID" : 774,
        "BEND_MAP_ID" : 774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "773",
        "source" : "114",
        "target" : "328",
        "EdgeBetweenness" : 32.34871794871795,
        "shared_name" : "Donald (cut57) Tarzan",
        "shared_interaction" : "cut57",
        "name" : "Donald (cut57) Tarzan",
        "interaction" : "cut57",
        "SUID" : 773,
        "BEND_MAP_ID" : 773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "772",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut56) Goofy",
        "shared_interaction" : "cut56",
        "name" : "Donald (cut56) Goofy",
        "interaction" : "cut56",
        "SUID" : 772,
        "BEND_MAP_ID" : 772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "771",
        "source" : "114",
        "target" : "328",
        "EdgeBetweenness" : 32.34871794871795,
        "shared_name" : "Donald (cut55) Tarzan",
        "shared_interaction" : "cut55",
        "name" : "Donald (cut55) Tarzan",
        "interaction" : "cut55",
        "SUID" : 771,
        "BEND_MAP_ID" : 771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "770",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut55) Goofy",
        "shared_interaction" : "cut55",
        "name" : "Donald (cut55) Goofy",
        "interaction" : "cut55",
        "SUID" : 770,
        "BEND_MAP_ID" : 770,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "769",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut54) Goofy",
        "shared_interaction" : "cut54",
        "name" : "Donald (cut54) Goofy",
        "interaction" : "cut54",
        "SUID" : 769,
        "BEND_MAP_ID" : 769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "768",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut54) Sora",
        "shared_interaction" : "cut54",
        "name" : "Donald (cut54) Sora",
        "interaction" : "cut54",
        "SUID" : 768,
        "BEND_MAP_ID" : 768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut52) Goofy",
        "shared_interaction" : "cut52",
        "name" : "Donald (cut52) Goofy",
        "interaction" : "cut52",
        "SUID" : 767,
        "BEND_MAP_ID" : 767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "766",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut50) Sora",
        "shared_interaction" : "cut50",
        "name" : "Donald (cut50) Sora",
        "interaction" : "cut50",
        "SUID" : 766,
        "BEND_MAP_ID" : 766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "765",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut49) Sora",
        "shared_interaction" : "cut49",
        "name" : "Donald (cut49) Sora",
        "interaction" : "cut49",
        "SUID" : 765,
        "BEND_MAP_ID" : 765,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "764",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut49) Goofy",
        "shared_interaction" : "cut49",
        "name" : "Donald (cut49) Goofy",
        "interaction" : "cut49",
        "SUID" : 764,
        "BEND_MAP_ID" : 764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "763",
        "source" : "114",
        "target" : "443",
        "EdgeBetweenness" : 30.34871794871794,
        "shared_name" : "Donald (cut48) Hercules",
        "shared_interaction" : "cut48",
        "name" : "Donald (cut48) Hercules",
        "interaction" : "cut48",
        "SUID" : 763,
        "BEND_MAP_ID" : 763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "762",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut48) Goofy",
        "shared_interaction" : "cut48",
        "name" : "Donald (cut48) Goofy",
        "interaction" : "cut48",
        "SUID" : 762,
        "BEND_MAP_ID" : 762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "761",
        "source" : "114",
        "target" : "292",
        "EdgeBetweenness" : 30.348717948717933,
        "shared_name" : "Donald (cut48) Philoctetes",
        "shared_interaction" : "cut48",
        "name" : "Donald (cut48) Philoctetes",
        "interaction" : "cut48",
        "SUID" : 761,
        "BEND_MAP_ID" : 761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "760",
        "source" : "114",
        "target" : "296",
        "EdgeBetweenness" : 53.26568431568431,
        "shared_name" : "Donald (cut47) Hades",
        "shared_interaction" : "cut47",
        "name" : "Donald (cut47) Hades",
        "interaction" : "cut47",
        "SUID" : 760,
        "BEND_MAP_ID" : 760,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "759",
        "source" : "114",
        "target" : "292",
        "EdgeBetweenness" : 30.348717948717933,
        "shared_name" : "Donald (cut46) Philoctetes",
        "shared_interaction" : "cut46",
        "name" : "Donald (cut46) Philoctetes",
        "interaction" : "cut46",
        "SUID" : 759,
        "BEND_MAP_ID" : 759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "758",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut46) Goofy",
        "shared_interaction" : "cut46",
        "name" : "Donald (cut46) Goofy",
        "interaction" : "cut46",
        "SUID" : 758,
        "BEND_MAP_ID" : 758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "757",
        "source" : "114",
        "target" : "292",
        "EdgeBetweenness" : 30.348717948717933,
        "shared_name" : "Donald (cut45) Philoctetes",
        "shared_interaction" : "cut45",
        "name" : "Donald (cut45) Philoctetes",
        "interaction" : "cut45",
        "SUID" : 757,
        "BEND_MAP_ID" : 757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "756",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut44) Goofy",
        "shared_interaction" : "cut44",
        "name" : "Donald (cut44) Goofy",
        "interaction" : "cut44",
        "SUID" : 756,
        "BEND_MAP_ID" : 756,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "755",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut44) Sora",
        "shared_interaction" : "cut44",
        "name" : "Donald (cut44) Sora",
        "interaction" : "cut44",
        "SUID" : 755,
        "BEND_MAP_ID" : 755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "754",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut43) Goofy",
        "shared_interaction" : "cut43",
        "name" : "Donald (cut43) Goofy",
        "interaction" : "cut43",
        "SUID" : 754,
        "BEND_MAP_ID" : 754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "753",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut42) Sora",
        "shared_interaction" : "cut42",
        "name" : "Donald (cut42) Sora",
        "interaction" : "cut42",
        "SUID" : 753,
        "BEND_MAP_ID" : 753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "752",
        "source" : "114",
        "target" : "263",
        "EdgeBetweenness" : 29.515384615384594,
        "shared_name" : "Donald (cut41) Queen of Hearts",
        "shared_interaction" : "cut41",
        "name" : "Donald (cut41) Queen of Hearts",
        "interaction" : "cut41",
        "SUID" : 752,
        "BEND_MAP_ID" : 752,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "751",
        "source" : "114",
        "target" : "263",
        "EdgeBetweenness" : 29.515384615384594,
        "shared_name" : "Donald (cut40) Queen of Hearts",
        "shared_interaction" : "cut40",
        "name" : "Donald (cut40) Queen of Hearts",
        "interaction" : "cut40",
        "SUID" : 751,
        "BEND_MAP_ID" : 751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "750",
        "source" : "114",
        "target" : "275",
        "EdgeBetweenness" : 31.015384615384598,
        "shared_name" : "Donald (cut39) Cheshire Cat",
        "shared_interaction" : "cut39",
        "name" : "Donald (cut39) Cheshire Cat",
        "interaction" : "cut39",
        "SUID" : 750,
        "BEND_MAP_ID" : 750,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "749",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut39) Sora",
        "shared_interaction" : "cut39",
        "name" : "Donald (cut39) Sora",
        "interaction" : "cut39",
        "SUID" : 749,
        "BEND_MAP_ID" : 749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "748",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut38) Sora",
        "shared_interaction" : "cut38",
        "name" : "Donald (cut38) Sora",
        "interaction" : "cut38",
        "SUID" : 748,
        "BEND_MAP_ID" : 748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "747",
        "source" : "114",
        "target" : "275",
        "EdgeBetweenness" : 31.015384615384598,
        "shared_name" : "Donald (cut38) Cheshire Cat",
        "shared_interaction" : "cut38",
        "name" : "Donald (cut38) Cheshire Cat",
        "interaction" : "cut38",
        "SUID" : 747,
        "BEND_MAP_ID" : 747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "746",
        "source" : "114",
        "target" : "272",
        "EdgeBetweenness" : 29.515384615384598,
        "shared_name" : "Donald (cut37) Card Soldier",
        "shared_interaction" : "cut37",
        "name" : "Donald (cut37) Card Soldier",
        "interaction" : "cut37",
        "SUID" : 746,
        "BEND_MAP_ID" : 746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "745",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut37) Goofy",
        "shared_interaction" : "cut37",
        "name" : "Donald (cut37) Goofy",
        "interaction" : "cut37",
        "SUID" : 745,
        "BEND_MAP_ID" : 745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "744",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut37) Sora",
        "shared_interaction" : "cut37",
        "name" : "Donald (cut37) Sora",
        "interaction" : "cut37",
        "SUID" : 744,
        "BEND_MAP_ID" : 744,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "743",
        "source" : "114",
        "target" : "265",
        "EdgeBetweenness" : 68.94285714285712,
        "shared_name" : "Donald (cut37) Alice",
        "shared_interaction" : "cut37",
        "name" : "Donald (cut37) Alice",
        "interaction" : "cut37",
        "SUID" : 743,
        "BEND_MAP_ID" : 743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "742",
        "source" : "114",
        "target" : "263",
        "EdgeBetweenness" : 29.515384615384594,
        "shared_name" : "Donald (cut36) Queen of Hearts",
        "shared_interaction" : "cut36",
        "name" : "Donald (cut36) Queen of Hearts",
        "interaction" : "cut36",
        "SUID" : 742,
        "BEND_MAP_ID" : 742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "741",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut36) Goofy",
        "shared_interaction" : "cut36",
        "name" : "Donald (cut36) Goofy",
        "interaction" : "cut36",
        "SUID" : 741,
        "BEND_MAP_ID" : 741,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "740",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut36) Sora",
        "shared_interaction" : "cut36",
        "name" : "Donald (cut36) Sora",
        "interaction" : "cut36",
        "SUID" : 740,
        "BEND_MAP_ID" : 740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "739",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut34) Goofy",
        "shared_interaction" : "cut34",
        "name" : "Donald (cut34) Goofy",
        "interaction" : "cut34",
        "SUID" : 739,
        "BEND_MAP_ID" : 739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "738",
        "source" : "114",
        "target" : "253",
        "EdgeBetweenness" : 26.432967032967017,
        "shared_name" : "Donald (cut33) Jiminy",
        "shared_interaction" : "cut33",
        "name" : "Donald (cut33) Jiminy",
        "interaction" : "cut33",
        "SUID" : 738,
        "BEND_MAP_ID" : 738,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "737",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut33) Sora",
        "shared_interaction" : "cut33",
        "name" : "Donald (cut33) Sora",
        "interaction" : "cut33",
        "SUID" : 737,
        "BEND_MAP_ID" : 737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "736",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut33) Goofy",
        "shared_interaction" : "cut33",
        "name" : "Donald (cut33) Goofy",
        "interaction" : "cut33",
        "SUID" : 736,
        "BEND_MAP_ID" : 736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "735",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut32) Goofy",
        "shared_interaction" : "cut32",
        "name" : "Donald (cut32) Goofy",
        "interaction" : "cut32",
        "SUID" : 735,
        "BEND_MAP_ID" : 735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "734",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut31) Goofy",
        "shared_interaction" : "cut31",
        "name" : "Donald (cut31) Goofy",
        "interaction" : "cut31",
        "SUID" : 734,
        "BEND_MAP_ID" : 734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "733",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut31) Sora",
        "shared_interaction" : "cut31",
        "name" : "Donald (cut31) Sora",
        "interaction" : "cut31",
        "SUID" : 733,
        "BEND_MAP_ID" : 733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "732",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut29) Sora",
        "shared_interaction" : "cut29",
        "name" : "Donald (cut29) Sora",
        "interaction" : "cut29",
        "SUID" : 732,
        "BEND_MAP_ID" : 732,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "731",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut29) Goofy",
        "shared_interaction" : "cut29",
        "name" : "Donald (cut29) Goofy",
        "interaction" : "cut29",
        "SUID" : 731,
        "BEND_MAP_ID" : 731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "730",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut28) Sora",
        "shared_interaction" : "cut28",
        "name" : "Donald (cut28) Sora",
        "interaction" : "cut28",
        "SUID" : 730,
        "BEND_MAP_ID" : 730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "729",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut27) Goofy",
        "shared_interaction" : "cut27",
        "name" : "Donald (cut27) Goofy",
        "interaction" : "cut27",
        "SUID" : 729,
        "BEND_MAP_ID" : 729,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "728",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut26) Sora",
        "shared_interaction" : "cut26",
        "name" : "Donald (cut26) Sora",
        "interaction" : "cut26",
        "SUID" : 728,
        "BEND_MAP_ID" : 728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "727",
        "source" : "114",
        "target" : "175",
        "EdgeBetweenness" : 26.09783549783549,
        "shared_name" : "Donald (cut26) Leon",
        "shared_interaction" : "cut26",
        "name" : "Donald (cut26) Leon",
        "interaction" : "cut26",
        "SUID" : 727,
        "BEND_MAP_ID" : 727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "726",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut25) Goofy",
        "shared_interaction" : "cut25",
        "name" : "Donald (cut25) Goofy",
        "interaction" : "cut25",
        "SUID" : 726,
        "BEND_MAP_ID" : 726,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "725",
        "source" : "114",
        "target" : "84",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Donald (cut22) Sora",
        "shared_interaction" : "cut22",
        "name" : "Donald (cut22) Sora",
        "interaction" : "cut22",
        "SUID" : 725,
        "BEND_MAP_ID" : 725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "724",
        "source" : "114",
        "target" : "179",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Donald (cut22) Aerith",
        "shared_interaction" : "cut22",
        "name" : "Donald (cut22) Aerith",
        "interaction" : "cut22",
        "SUID" : 724,
        "BEND_MAP_ID" : 724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "723",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut21) Goofy",
        "shared_interaction" : "cut21",
        "name" : "Donald (cut21) Goofy",
        "interaction" : "cut21",
        "SUID" : 723,
        "BEND_MAP_ID" : 723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "722",
        "source" : "114",
        "target" : "179",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Donald (cut21) Aerith",
        "shared_interaction" : "cut21",
        "name" : "Donald (cut21) Aerith",
        "interaction" : "cut21",
        "SUID" : 722,
        "BEND_MAP_ID" : 722,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "721",
        "source" : "114",
        "target" : "179",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Donald (cut20) Aerith",
        "shared_interaction" : "cut20",
        "name" : "Donald (cut20) Aerith",
        "interaction" : "cut20",
        "SUID" : 721,
        "BEND_MAP_ID" : 721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "720",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut20) Goofy",
        "shared_interaction" : "cut20",
        "name" : "Donald (cut20) Goofy",
        "interaction" : "cut20",
        "SUID" : 720,
        "BEND_MAP_ID" : 720,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "719",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut19) Goofy",
        "shared_interaction" : "cut19",
        "name" : "Donald (cut19) Goofy",
        "interaction" : "cut19",
        "SUID" : 719,
        "BEND_MAP_ID" : 719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "718",
        "source" : "114",
        "target" : "179",
        "EdgeBetweenness" : 26.59783549783549,
        "shared_name" : "Donald (cut19) Aerith",
        "shared_interaction" : "cut19",
        "name" : "Donald (cut19) Aerith",
        "interaction" : "cut19",
        "SUID" : 718,
        "BEND_MAP_ID" : 718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "717",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut18) Goofy",
        "shared_interaction" : "cut18",
        "name" : "Donald (cut18) Goofy",
        "interaction" : "cut18",
        "SUID" : 717,
        "BEND_MAP_ID" : 717,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "716",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut17) Goofy",
        "shared_interaction" : "cut17",
        "name" : "Donald (cut17) Goofy",
        "interaction" : "cut17",
        "SUID" : 716,
        "BEND_MAP_ID" : 716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "715",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut16) Goofy",
        "shared_interaction" : "cut16",
        "name" : "Donald (cut16) Goofy",
        "interaction" : "cut16",
        "SUID" : 715,
        "BEND_MAP_ID" : 715,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "714",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut15) Goofy",
        "shared_interaction" : "cut15",
        "name" : "Donald (cut15) Goofy",
        "interaction" : "cut15",
        "SUID" : 714,
        "BEND_MAP_ID" : 714,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut14) Goofy",
        "shared_interaction" : "cut14",
        "name" : "Donald (cut14) Goofy",
        "interaction" : "cut14",
        "SUID" : 713,
        "BEND_MAP_ID" : 713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "712",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut13) Goofy",
        "shared_interaction" : "cut13",
        "name" : "Donald (cut13) Goofy",
        "interaction" : "cut13",
        "SUID" : 712,
        "BEND_MAP_ID" : 712,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "711",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut12) Goofy",
        "shared_interaction" : "cut12",
        "name" : "Donald (cut12) Goofy",
        "interaction" : "cut12",
        "SUID" : 711,
        "BEND_MAP_ID" : 711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "710",
        "source" : "114",
        "target" : "253",
        "EdgeBetweenness" : 26.432967032967017,
        "shared_name" : "Donald (cut8) Jiminy",
        "shared_interaction" : "cut8",
        "name" : "Donald (cut8) Jiminy",
        "interaction" : "cut8",
        "SUID" : 710,
        "BEND_MAP_ID" : 710,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "709",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut8) Goofy",
        "shared_interaction" : "cut8",
        "name" : "Donald (cut8) Goofy",
        "interaction" : "cut8",
        "SUID" : 709,
        "BEND_MAP_ID" : 709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "708",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut6) Goofy",
        "shared_interaction" : "cut6",
        "name" : "Donald (cut6) Goofy",
        "interaction" : "cut6",
        "SUID" : 708,
        "BEND_MAP_ID" : 708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "707",
        "source" : "114",
        "target" : "706",
        "EdgeBetweenness" : 71.44242424242425,
        "shared_name" : "Donald (cut6) Minnie",
        "shared_interaction" : "cut6",
        "name" : "Donald (cut6) Minnie",
        "interaction" : "cut6",
        "SUID" : 707,
        "BEND_MAP_ID" : 707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "705",
        "source" : "114",
        "target" : "704",
        "EdgeBetweenness" : 71.44242424242425,
        "shared_name" : "Donald (cut6) Daisy",
        "shared_interaction" : "cut6",
        "name" : "Donald (cut6) Daisy",
        "interaction" : "cut6",
        "SUID" : 705,
        "BEND_MAP_ID" : 705,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "703",
        "source" : "114",
        "target" : "106",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Donald (cut5) Goofy",
        "shared_interaction" : "cut5",
        "name" : "Donald (cut5) Goofy",
        "interaction" : "cut5",
        "SUID" : 703,
        "BEND_MAP_ID" : 703,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1053",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut115) Donald",
        "shared_interaction" : "cut115",
        "name" : "Goofy (cut115) Donald",
        "interaction" : "cut115",
        "SUID" : 1053,
        "BEND_MAP_ID" : 1053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1052",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut115) Sora",
        "shared_interaction" : "cut115",
        "name" : "Goofy (cut115) Sora",
        "interaction" : "cut115",
        "SUID" : 1052,
        "BEND_MAP_ID" : 1052,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1051",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut113) Sora",
        "shared_interaction" : "cut113",
        "name" : "Goofy (cut113) Sora",
        "interaction" : "cut113",
        "SUID" : 1051,
        "BEND_MAP_ID" : 1051,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1050",
        "source" : "106",
        "target" : "96",
        "EdgeBetweenness" : 90.84440559440557,
        "shared_name" : "Goofy (cut112) Riku",
        "shared_interaction" : "cut112",
        "name" : "Goofy (cut112) Riku",
        "interaction" : "cut112",
        "SUID" : 1050,
        "BEND_MAP_ID" : 1050,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1049",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut112) Sora",
        "shared_interaction" : "cut112",
        "name" : "Goofy (cut112) Sora",
        "interaction" : "cut112",
        "SUID" : 1049,
        "BEND_MAP_ID" : 1049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1048",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut112) Donald",
        "shared_interaction" : "cut112",
        "name" : "Goofy (cut112) Donald",
        "interaction" : "cut112",
        "SUID" : 1048,
        "BEND_MAP_ID" : 1048,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1047",
        "source" : "106",
        "target" : "603",
        "EdgeBetweenness" : 37.232967032967046,
        "shared_name" : "Goofy (cut112) Mickey",
        "shared_interaction" : "cut112",
        "name" : "Goofy (cut112) Mickey",
        "interaction" : "cut112",
        "SUID" : 1047,
        "BEND_MAP_ID" : 1047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1046",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut111) Donald",
        "shared_interaction" : "cut111",
        "name" : "Goofy (cut111) Donald",
        "interaction" : "cut111",
        "SUID" : 1046,
        "BEND_MAP_ID" : 1046,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1045",
        "source" : "106",
        "target" : "598",
        "EdgeBetweenness" : 55.74603174603175,
        "shared_name" : "Goofy (cut109) Ansem",
        "shared_interaction" : "cut109",
        "name" : "Goofy (cut109) Ansem",
        "interaction" : "cut109",
        "SUID" : 1045,
        "BEND_MAP_ID" : 1045,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1044",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut108) Donald",
        "shared_interaction" : "cut108",
        "name" : "Goofy (cut108) Donald",
        "interaction" : "cut108",
        "SUID" : 1044,
        "BEND_MAP_ID" : 1044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1043",
        "source" : "106",
        "target" : "1042",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Goofy (cut107) Sora & Donald",
        "shared_interaction" : "cut107",
        "name" : "Goofy (cut107) Sora & Donald",
        "interaction" : "cut107",
        "SUID" : 1043,
        "BEND_MAP_ID" : 1043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1041",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut106) Donald",
        "shared_interaction" : "cut106",
        "name" : "Goofy (cut106) Donald",
        "interaction" : "cut106",
        "SUID" : 1041,
        "BEND_MAP_ID" : 1041,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1040",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut106) Sora",
        "shared_interaction" : "cut106",
        "name" : "Goofy (cut106) Sora",
        "interaction" : "cut106",
        "SUID" : 1040,
        "BEND_MAP_ID" : 1040,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1039",
        "source" : "106",
        "target" : "222",
        "EdgeBetweenness" : 54.951004551004544,
        "shared_name" : "Goofy (cut105) ??????",
        "shared_interaction" : "cut105",
        "name" : "Goofy (cut105) ??????",
        "interaction" : "cut105",
        "SUID" : 1039,
        "BEND_MAP_ID" : 1039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1038",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut105) Sora",
        "shared_interaction" : "cut105",
        "name" : "Goofy (cut105) Sora",
        "interaction" : "cut105",
        "SUID" : 1038,
        "BEND_MAP_ID" : 1038,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1037",
        "source" : "106",
        "target" : "175",
        "EdgeBetweenness" : 38.116883116883116,
        "shared_name" : "Goofy (cut104) Leon",
        "shared_interaction" : "cut104",
        "name" : "Goofy (cut104) Leon",
        "interaction" : "cut104",
        "SUID" : 1037,
        "BEND_MAP_ID" : 1037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1036",
        "source" : "106",
        "target" : "71",
        "EdgeBetweenness" : 114.98256743256738,
        "shared_name" : "Goofy (cut103) ????",
        "shared_interaction" : "cut103",
        "name" : "Goofy (cut103) ????",
        "interaction" : "cut103",
        "SUID" : 1036,
        "BEND_MAP_ID" : 1036,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1035",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut102) Donald",
        "shared_interaction" : "cut102",
        "name" : "Goofy (cut102) Donald",
        "interaction" : "cut102",
        "SUID" : 1035,
        "BEND_MAP_ID" : 1035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1034",
        "source" : "106",
        "target" : "534",
        "EdgeBetweenness" : 37.23296703296703,
        "shared_name" : "Goofy (cut102) Beast",
        "shared_interaction" : "cut102",
        "name" : "Goofy (cut102) Beast",
        "interaction" : "cut102",
        "SUID" : 1034,
        "BEND_MAP_ID" : 1034,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1033",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut102) Sora",
        "shared_interaction" : "cut102",
        "name" : "Goofy (cut102) Sora",
        "interaction" : "cut102",
        "SUID" : 1033,
        "BEND_MAP_ID" : 1033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1032",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut99) Donald",
        "shared_interaction" : "cut99",
        "name" : "Goofy (cut99) Donald",
        "interaction" : "cut99",
        "SUID" : 1032,
        "BEND_MAP_ID" : 1032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1031",
        "source" : "106",
        "target" : "82",
        "EdgeBetweenness" : 33.6,
        "shared_name" : "Goofy (cut99) Kairi",
        "shared_interaction" : "cut99",
        "name" : "Goofy (cut99) Kairi",
        "interaction" : "cut99",
        "SUID" : 1031,
        "BEND_MAP_ID" : 1031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1030",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut98) Donald",
        "shared_interaction" : "cut98",
        "name" : "Goofy (cut98) Donald",
        "interaction" : "cut98",
        "SUID" : 1030,
        "BEND_MAP_ID" : 1030,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1029",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut97) Donald",
        "shared_interaction" : "cut97",
        "name" : "Goofy (cut97) Donald",
        "interaction" : "cut97",
        "SUID" : 1029,
        "BEND_MAP_ID" : 1029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1028",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut96) Donald",
        "shared_interaction" : "cut96",
        "name" : "Goofy (cut96) Donald",
        "interaction" : "cut96",
        "SUID" : 1028,
        "BEND_MAP_ID" : 1028,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1027",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut95) Sora",
        "shared_interaction" : "cut95",
        "name" : "Goofy (cut95) Sora",
        "interaction" : "cut95",
        "SUID" : 1027,
        "BEND_MAP_ID" : 1027,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1026",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut94) Sora",
        "shared_interaction" : "cut94",
        "name" : "Goofy (cut94) Sora",
        "interaction" : "cut94",
        "SUID" : 1026,
        "BEND_MAP_ID" : 1026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1025",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut92) Donald",
        "shared_interaction" : "cut92",
        "name" : "Goofy (cut92) Donald",
        "interaction" : "cut92",
        "SUID" : 1025,
        "BEND_MAP_ID" : 1025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1024",
        "source" : "106",
        "target" : "96",
        "EdgeBetweenness" : 90.84440559440557,
        "shared_name" : "Goofy (cut91) Riku",
        "shared_interaction" : "cut91",
        "name" : "Goofy (cut91) Riku",
        "interaction" : "cut91",
        "SUID" : 1024,
        "BEND_MAP_ID" : 1024,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1023",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut91) Sora",
        "shared_interaction" : "cut91",
        "name" : "Goofy (cut91) Sora",
        "interaction" : "cut91",
        "SUID" : 1023,
        "BEND_MAP_ID" : 1023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1022",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut91) Donald",
        "shared_interaction" : "cut91",
        "name" : "Goofy (cut91) Donald",
        "interaction" : "cut91",
        "SUID" : 1022,
        "BEND_MAP_ID" : 1022,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1021",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut90) Donald",
        "shared_interaction" : "cut90",
        "name" : "Goofy (cut90) Donald",
        "interaction" : "cut90",
        "SUID" : 1021,
        "BEND_MAP_ID" : 1021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1020",
        "source" : "106",
        "target" : "96",
        "EdgeBetweenness" : 90.84440559440557,
        "shared_name" : "Goofy (cut89) Riku",
        "shared_interaction" : "cut89",
        "name" : "Goofy (cut89) Riku",
        "interaction" : "cut89",
        "SUID" : 1020,
        "BEND_MAP_ID" : 1020,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1019",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut87) Donald",
        "shared_interaction" : "cut87",
        "name" : "Goofy (cut87) Donald",
        "interaction" : "cut87",
        "SUID" : 1019,
        "BEND_MAP_ID" : 1019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1018",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut86) Sora",
        "shared_interaction" : "cut86",
        "name" : "Goofy (cut86) Sora",
        "interaction" : "cut86",
        "SUID" : 1018,
        "BEND_MAP_ID" : 1018,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1017",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut85) Sora",
        "shared_interaction" : "cut85",
        "name" : "Goofy (cut85) Sora",
        "interaction" : "cut85",
        "SUID" : 1017,
        "BEND_MAP_ID" : 1017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1016",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut84) Donald",
        "shared_interaction" : "cut84",
        "name" : "Goofy (cut84) Donald",
        "interaction" : "cut84",
        "SUID" : 1016,
        "BEND_MAP_ID" : 1016,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1015",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut84) Sora",
        "shared_interaction" : "cut84",
        "name" : "Goofy (cut84) Sora",
        "interaction" : "cut84",
        "SUID" : 1015,
        "BEND_MAP_ID" : 1015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1014",
        "source" : "106",
        "target" : "443",
        "EdgeBetweenness" : 41.14871794871796,
        "shared_name" : "Goofy (cut84) Hercules",
        "shared_interaction" : "cut84",
        "name" : "Goofy (cut84) Hercules",
        "interaction" : "cut84",
        "SUID" : 1014,
        "BEND_MAP_ID" : 1014,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1013",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut83) Sora",
        "shared_interaction" : "cut83",
        "name" : "Goofy (cut83) Sora",
        "interaction" : "cut83",
        "SUID" : 1013,
        "BEND_MAP_ID" : 1013,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1012",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut82) Sora",
        "shared_interaction" : "cut82",
        "name" : "Goofy (cut82) Sora",
        "interaction" : "cut82",
        "SUID" : 1012,
        "BEND_MAP_ID" : 1012,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1011",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut82) Donald",
        "shared_interaction" : "cut82",
        "name" : "Goofy (cut82) Donald",
        "interaction" : "cut82",
        "SUID" : 1011,
        "BEND_MAP_ID" : 1011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1010",
        "source" : "106",
        "target" : "488",
        "EdgeBetweenness" : 59.07936507936507,
        "shared_name" : "Goofy (cut80) Peter Pan",
        "shared_interaction" : "cut80",
        "name" : "Goofy (cut80) Peter Pan",
        "interaction" : "cut80",
        "SUID" : 1010,
        "BEND_MAP_ID" : 1010,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1009",
        "source" : "106",
        "target" : "78",
        "EdgeBetweenness" : 45.624342324342315,
        "shared_name" : "Goofy (cut79) ?????",
        "shared_interaction" : "cut79",
        "name" : "Goofy (cut79) ?????",
        "interaction" : "cut79",
        "SUID" : 1009,
        "BEND_MAP_ID" : 1009,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1008",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut78) Donald",
        "shared_interaction" : "cut78",
        "name" : "Goofy (cut78) Donald",
        "interaction" : "cut78",
        "SUID" : 1008,
        "BEND_MAP_ID" : 1008,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1007",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut78) Sora",
        "shared_interaction" : "cut78",
        "name" : "Goofy (cut78) Sora",
        "interaction" : "cut78",
        "SUID" : 1007,
        "BEND_MAP_ID" : 1007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1006",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut76) Donald",
        "shared_interaction" : "cut76",
        "name" : "Goofy (cut76) Donald",
        "interaction" : "cut76",
        "SUID" : 1006,
        "BEND_MAP_ID" : 1006,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1005",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut75) Donald",
        "shared_interaction" : "cut75",
        "name" : "Goofy (cut75) Donald",
        "interaction" : "cut75",
        "SUID" : 1005,
        "BEND_MAP_ID" : 1005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1004",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut75) Sora",
        "shared_interaction" : "cut75",
        "name" : "Goofy (cut75) Sora",
        "interaction" : "cut75",
        "SUID" : 1004,
        "BEND_MAP_ID" : 1004,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1003",
        "source" : "106",
        "target" : "450",
        "EdgeBetweenness" : 46.550000000000004,
        "shared_name" : "Goofy (cut74) Triton",
        "shared_interaction" : "cut74",
        "name" : "Goofy (cut74) Triton",
        "interaction" : "cut74",
        "SUID" : 1003,
        "BEND_MAP_ID" : 1003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1002",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut74) Sora",
        "shared_interaction" : "cut74",
        "name" : "Goofy (cut74) Sora",
        "interaction" : "cut74",
        "SUID" : 1002,
        "BEND_MAP_ID" : 1002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1001",
        "source" : "106",
        "target" : "447",
        "EdgeBetweenness" : 296.960606060606,
        "shared_name" : "Goofy (cut74) Ariel",
        "shared_interaction" : "cut74",
        "name" : "Goofy (cut74) Ariel",
        "interaction" : "cut74",
        "SUID" : 1001,
        "BEND_MAP_ID" : 1001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1000",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut73) Sora",
        "shared_interaction" : "cut73",
        "name" : "Goofy (cut73) Sora",
        "interaction" : "cut73",
        "SUID" : 1000,
        "BEND_MAP_ID" : 1000,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "999",
        "source" : "106",
        "target" : "450",
        "EdgeBetweenness" : 46.550000000000004,
        "shared_name" : "Goofy (cut73) Triton",
        "shared_interaction" : "cut73",
        "name" : "Goofy (cut73) Triton",
        "interaction" : "cut73",
        "SUID" : 999,
        "BEND_MAP_ID" : 999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "998",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut72) Sora",
        "shared_interaction" : "cut72",
        "name" : "Goofy (cut72) Sora",
        "interaction" : "cut72",
        "SUID" : 998,
        "BEND_MAP_ID" : 998,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "997",
        "source" : "106",
        "target" : "447",
        "EdgeBetweenness" : 296.960606060606,
        "shared_name" : "Goofy (cut72) Ariel",
        "shared_interaction" : "cut72",
        "name" : "Goofy (cut72) Ariel",
        "interaction" : "cut72",
        "SUID" : 997,
        "BEND_MAP_ID" : 997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "996",
        "source" : "106",
        "target" : "450",
        "EdgeBetweenness" : 46.550000000000004,
        "shared_name" : "Goofy (cut72) Triton",
        "shared_interaction" : "cut72",
        "name" : "Goofy (cut72) Triton",
        "interaction" : "cut72",
        "SUID" : 996,
        "BEND_MAP_ID" : 996,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "995",
        "source" : "106",
        "target" : "136",
        "EdgeBetweenness" : 48.30346320346322,
        "shared_name" : "Goofy (cut72) Sebastian",
        "shared_interaction" : "cut72",
        "name" : "Goofy (cut72) Sebastian",
        "interaction" : "cut72",
        "SUID" : 995,
        "BEND_MAP_ID" : 995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "994",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut71) Sora",
        "shared_interaction" : "cut71",
        "name" : "Goofy (cut71) Sora",
        "interaction" : "cut71",
        "SUID" : 994,
        "BEND_MAP_ID" : 994,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "993",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut71) Donald",
        "shared_interaction" : "cut71",
        "name" : "Goofy (cut71) Donald",
        "interaction" : "cut71",
        "SUID" : 993,
        "BEND_MAP_ID" : 993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "992",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut70) Sora",
        "shared_interaction" : "cut70",
        "name" : "Goofy (cut70) Sora",
        "interaction" : "cut70",
        "SUID" : 992,
        "BEND_MAP_ID" : 992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "991",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut68) Sora",
        "shared_interaction" : "cut68",
        "name" : "Goofy (cut68) Sora",
        "interaction" : "cut68",
        "SUID" : 991,
        "BEND_MAP_ID" : 991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "990",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut67) Sora",
        "shared_interaction" : "cut67",
        "name" : "Goofy (cut67) Sora",
        "interaction" : "cut67",
        "SUID" : 990,
        "BEND_MAP_ID" : 990,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "989",
        "source" : "106",
        "target" : "253",
        "EdgeBetweenness" : 38.23296703296703,
        "shared_name" : "Goofy (cut66) Jiminy",
        "shared_interaction" : "cut66",
        "name" : "Goofy (cut66) Jiminy",
        "interaction" : "cut66",
        "SUID" : 989,
        "BEND_MAP_ID" : 989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "988",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut65) Sora",
        "shared_interaction" : "cut65",
        "name" : "Goofy (cut65) Sora",
        "interaction" : "cut65",
        "SUID" : 988,
        "BEND_MAP_ID" : 988,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "987",
        "source" : "106",
        "target" : "395",
        "EdgeBetweenness" : 52.69458874458875,
        "shared_name" : "Goofy (cut64) Aladdin",
        "shared_interaction" : "cut64",
        "name" : "Goofy (cut64) Aladdin",
        "interaction" : "cut64",
        "SUID" : 987,
        "BEND_MAP_ID" : 987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "986",
        "source" : "106",
        "target" : "400",
        "EdgeBetweenness" : 38.36666666666666,
        "shared_name" : "Goofy (cut64) Genie",
        "shared_interaction" : "cut64",
        "name" : "Goofy (cut64) Genie",
        "interaction" : "cut64",
        "SUID" : 986,
        "BEND_MAP_ID" : 986,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "985",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut64) Sora",
        "shared_interaction" : "cut64",
        "name" : "Goofy (cut64) Sora",
        "interaction" : "cut64",
        "SUID" : 985,
        "BEND_MAP_ID" : 985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "984",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut64) Donald",
        "shared_interaction" : "cut64",
        "name" : "Goofy (cut64) Donald",
        "interaction" : "cut64",
        "SUID" : 984,
        "BEND_MAP_ID" : 984,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "983",
        "source" : "106",
        "target" : "395",
        "EdgeBetweenness" : 52.69458874458875,
        "shared_name" : "Goofy (cut63) Aladdin",
        "shared_interaction" : "cut63",
        "name" : "Goofy (cut63) Aladdin",
        "interaction" : "cut63",
        "SUID" : 983,
        "BEND_MAP_ID" : 983,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "982",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut62) Donald",
        "shared_interaction" : "cut62",
        "name" : "Goofy (cut62) Donald",
        "interaction" : "cut62",
        "SUID" : 982,
        "BEND_MAP_ID" : 982,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "981",
        "source" : "106",
        "target" : "123",
        "EdgeBetweenness" : 56.0063103563104,
        "shared_name" : "Goofy (cut62) Jafar",
        "shared_interaction" : "cut62",
        "name" : "Goofy (cut62) Jafar",
        "interaction" : "cut62",
        "SUID" : 981,
        "BEND_MAP_ID" : 981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "980",
        "source" : "106",
        "target" : "395",
        "EdgeBetweenness" : 52.69458874458875,
        "shared_name" : "Goofy (cut61) Aladdin",
        "shared_interaction" : "cut61",
        "name" : "Goofy (cut61) Aladdin",
        "interaction" : "cut61",
        "SUID" : 980,
        "BEND_MAP_ID" : 980,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "979",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut61) Sora",
        "shared_interaction" : "cut61",
        "name" : "Goofy (cut61) Sora",
        "interaction" : "cut61",
        "SUID" : 979,
        "BEND_MAP_ID" : 979,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "978",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut61) Donald",
        "shared_interaction" : "cut61",
        "name" : "Goofy (cut61) Donald",
        "interaction" : "cut61",
        "SUID" : 978,
        "BEND_MAP_ID" : 978,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "977",
        "source" : "106",
        "target" : "395",
        "EdgeBetweenness" : 52.69458874458875,
        "shared_name" : "Goofy (cut60) Aladdin",
        "shared_interaction" : "cut60",
        "name" : "Goofy (cut60) Aladdin",
        "interaction" : "cut60",
        "SUID" : 977,
        "BEND_MAP_ID" : 977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "976",
        "source" : "106",
        "target" : "400",
        "EdgeBetweenness" : 38.36666666666666,
        "shared_name" : "Goofy (cut60) Genie",
        "shared_interaction" : "cut60",
        "name" : "Goofy (cut60) Genie",
        "interaction" : "cut60",
        "SUID" : 976,
        "BEND_MAP_ID" : 976,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "975",
        "source" : "106",
        "target" : "123",
        "EdgeBetweenness" : 56.0063103563104,
        "shared_name" : "Goofy (cut58) Jafar",
        "shared_interaction" : "cut58",
        "name" : "Goofy (cut58) Jafar",
        "interaction" : "cut58",
        "SUID" : 975,
        "BEND_MAP_ID" : 975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "974",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut58) Sora",
        "shared_interaction" : "cut58",
        "name" : "Goofy (cut58) Sora",
        "interaction" : "cut58",
        "SUID" : 974,
        "BEND_MAP_ID" : 974,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "973",
        "source" : "106",
        "target" : "120",
        "EdgeBetweenness" : 53.716666666666676,
        "shared_name" : "Goofy (cut58) Jasmine",
        "shared_interaction" : "cut58",
        "name" : "Goofy (cut58) Jasmine",
        "interaction" : "cut58",
        "SUID" : 973,
        "BEND_MAP_ID" : 973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "972",
        "source" : "106",
        "target" : "76",
        "EdgeBetweenness" : 42.23333333333335,
        "shared_name" : "Goofy (cut58) ???????",
        "shared_interaction" : "cut58",
        "name" : "Goofy (cut58) ???????",
        "interaction" : "cut58",
        "SUID" : 972,
        "BEND_MAP_ID" : 972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "971",
        "source" : "106",
        "target" : "96",
        "EdgeBetweenness" : 90.84440559440557,
        "shared_name" : "Goofy (cut56) Riku",
        "shared_interaction" : "cut56",
        "name" : "Goofy (cut56) Riku",
        "interaction" : "cut56",
        "SUID" : 971,
        "BEND_MAP_ID" : 971,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "970",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut56) Sora",
        "shared_interaction" : "cut56",
        "name" : "Goofy (cut56) Sora",
        "interaction" : "cut56",
        "SUID" : 970,
        "BEND_MAP_ID" : 970,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "969",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut56) Donald",
        "shared_interaction" : "cut56",
        "name" : "Goofy (cut56) Donald",
        "interaction" : "cut56",
        "SUID" : 969,
        "BEND_MAP_ID" : 969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "968",
        "source" : "106",
        "target" : "133",
        "EdgeBetweenness" : 37.64285714285713,
        "shared_name" : "Goofy (cut55) Merlin",
        "shared_interaction" : "cut55",
        "name" : "Goofy (cut55) Merlin",
        "interaction" : "cut55",
        "SUID" : 968,
        "BEND_MAP_ID" : 968,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "967",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut55) Donald",
        "shared_interaction" : "cut55",
        "name" : "Goofy (cut55) Donald",
        "interaction" : "cut55",
        "SUID" : 967,
        "BEND_MAP_ID" : 967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "966",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut55) Sora",
        "shared_interaction" : "cut55",
        "name" : "Goofy (cut55) Sora",
        "interaction" : "cut55",
        "SUID" : 966,
        "BEND_MAP_ID" : 966,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "965",
        "source" : "106",
        "target" : "222",
        "EdgeBetweenness" : 54.951004551004544,
        "shared_name" : "Goofy (cut55) ??????",
        "shared_interaction" : "cut55",
        "name" : "Goofy (cut55) ??????",
        "interaction" : "cut55",
        "SUID" : 965,
        "BEND_MAP_ID" : 965,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "964",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut54) Sora",
        "shared_interaction" : "cut54",
        "name" : "Goofy (cut54) Sora",
        "interaction" : "cut54",
        "SUID" : 964,
        "BEND_MAP_ID" : 964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "963",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut53) Sora",
        "shared_interaction" : "cut53",
        "name" : "Goofy (cut53) Sora",
        "interaction" : "cut53",
        "SUID" : 963,
        "BEND_MAP_ID" : 963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "962",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut53) Donald",
        "shared_interaction" : "cut53",
        "name" : "Goofy (cut53) Donald",
        "interaction" : "cut53",
        "SUID" : 962,
        "BEND_MAP_ID" : 962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "961",
        "source" : "106",
        "target" : "220",
        "EdgeBetweenness" : 39.21538461538462,
        "shared_name" : "Goofy (cut53) Cid",
        "shared_interaction" : "cut53",
        "name" : "Goofy (cut53) Cid",
        "interaction" : "cut53",
        "SUID" : 961,
        "BEND_MAP_ID" : 961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "960",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut52) Donald",
        "shared_interaction" : "cut52",
        "name" : "Goofy (cut52) Donald",
        "interaction" : "cut52",
        "SUID" : 960,
        "BEND_MAP_ID" : 960,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "959",
        "source" : "106",
        "target" : "345",
        "EdgeBetweenness" : 39.68205128205129,
        "shared_name" : "Goofy (cut52) Sora, Donald & Goofy",
        "shared_interaction" : "cut52",
        "name" : "Goofy (cut52) Sora, Donald & Goofy",
        "interaction" : "cut52",
        "SUID" : 959,
        "BEND_MAP_ID" : 959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "958",
        "source" : "106",
        "target" : "179",
        "EdgeBetweenness" : 37.11688311688311,
        "shared_name" : "Goofy (cut52) Aerith",
        "shared_interaction" : "cut52",
        "name" : "Goofy (cut52) Aerith",
        "interaction" : "cut52",
        "SUID" : 958,
        "BEND_MAP_ID" : 958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "957",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut52) Sora",
        "shared_interaction" : "cut52",
        "name" : "Goofy (cut52) Sora",
        "interaction" : "cut52",
        "SUID" : 957,
        "BEND_MAP_ID" : 957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "956",
        "source" : "106",
        "target" : "175",
        "EdgeBetweenness" : 38.116883116883116,
        "shared_name" : "Goofy (cut52) Leon",
        "shared_interaction" : "cut52",
        "name" : "Goofy (cut52) Leon",
        "interaction" : "cut52",
        "SUID" : 956,
        "BEND_MAP_ID" : 956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "955",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut51) Donald",
        "shared_interaction" : "cut51",
        "name" : "Goofy (cut51) Donald",
        "interaction" : "cut51",
        "SUID" : 955,
        "BEND_MAP_ID" : 955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "954",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut51) Sora",
        "shared_interaction" : "cut51",
        "name" : "Goofy (cut51) Sora",
        "interaction" : "cut51",
        "SUID" : 954,
        "BEND_MAP_ID" : 954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "953",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut50) Donald",
        "shared_interaction" : "cut50",
        "name" : "Goofy (cut50) Donald",
        "interaction" : "cut50",
        "SUID" : 953,
        "BEND_MAP_ID" : 953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "952",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut49) Donald",
        "shared_interaction" : "cut49",
        "name" : "Goofy (cut49) Donald",
        "interaction" : "cut49",
        "SUID" : 952,
        "BEND_MAP_ID" : 952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "951",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut49) Sora",
        "shared_interaction" : "cut49",
        "name" : "Goofy (cut49) Sora",
        "interaction" : "cut49",
        "SUID" : 951,
        "BEND_MAP_ID" : 951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "950",
        "source" : "106",
        "target" : "117",
        "EdgeBetweenness" : 39.616883116883116,
        "shared_name" : "Goofy (cut49) Jane",
        "shared_interaction" : "cut49",
        "name" : "Goofy (cut49) Jane",
        "interaction" : "cut49",
        "SUID" : 950,
        "BEND_MAP_ID" : 950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "949",
        "source" : "106",
        "target" : "328",
        "EdgeBetweenness" : 42.482051282051295,
        "shared_name" : "Goofy (cut49) Tarzan",
        "shared_interaction" : "cut49",
        "name" : "Goofy (cut49) Tarzan",
        "interaction" : "cut49",
        "SUID" : 949,
        "BEND_MAP_ID" : 949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "948",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut47) Donald",
        "shared_interaction" : "cut47",
        "name" : "Goofy (cut47) Donald",
        "interaction" : "cut47",
        "SUID" : 948,
        "BEND_MAP_ID" : 948,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "947",
        "source" : "106",
        "target" : "328",
        "EdgeBetweenness" : 42.482051282051295,
        "shared_name" : "Goofy (cut47) Tarzan",
        "shared_interaction" : "cut47",
        "name" : "Goofy (cut47) Tarzan",
        "interaction" : "cut47",
        "SUID" : 947,
        "BEND_MAP_ID" : 947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "946",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut47) Sora",
        "shared_interaction" : "cut47",
        "name" : "Goofy (cut47) Sora",
        "interaction" : "cut47",
        "SUID" : 946,
        "BEND_MAP_ID" : 946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "945",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut46) Donald",
        "shared_interaction" : "cut46",
        "name" : "Goofy (cut46) Donald",
        "interaction" : "cut46",
        "SUID" : 945,
        "BEND_MAP_ID" : 945,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "944",
        "source" : "106",
        "target" : "328",
        "EdgeBetweenness" : 42.482051282051295,
        "shared_name" : "Goofy (cut45) Tarzan",
        "shared_interaction" : "cut45",
        "name" : "Goofy (cut45) Tarzan",
        "interaction" : "cut45",
        "SUID" : 944,
        "BEND_MAP_ID" : 944,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "943",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut45) Donald",
        "shared_interaction" : "cut45",
        "name" : "Goofy (cut45) Donald",
        "interaction" : "cut45",
        "SUID" : 943,
        "BEND_MAP_ID" : 943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "942",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut44) Sora",
        "shared_interaction" : "cut44",
        "name" : "Goofy (cut44) Sora",
        "interaction" : "cut44",
        "SUID" : 942,
        "BEND_MAP_ID" : 942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "941",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut43) Donald",
        "shared_interaction" : "cut43",
        "name" : "Goofy (cut43) Donald",
        "interaction" : "cut43",
        "SUID" : 941,
        "BEND_MAP_ID" : 941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "940",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut43) Sora",
        "shared_interaction" : "cut43",
        "name" : "Goofy (cut43) Sora",
        "interaction" : "cut43",
        "SUID" : 940,
        "BEND_MAP_ID" : 940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "939",
        "source" : "106",
        "target" : "317",
        "EdgeBetweenness" : 53.41269841269842,
        "shared_name" : "Goofy (cut42) Donald & Sora",
        "shared_interaction" : "cut42",
        "name" : "Goofy (cut42) Donald & Sora",
        "interaction" : "cut42",
        "SUID" : 939,
        "BEND_MAP_ID" : 939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "938",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut42) Sora",
        "shared_interaction" : "cut42",
        "name" : "Goofy (cut42) Sora",
        "interaction" : "cut42",
        "SUID" : 938,
        "BEND_MAP_ID" : 938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "937",
        "source" : "106",
        "target" : "117",
        "EdgeBetweenness" : 39.616883116883116,
        "shared_name" : "Goofy (cut42) Jane",
        "shared_interaction" : "cut42",
        "name" : "Goofy (cut42) Jane",
        "interaction" : "cut42",
        "SUID" : 937,
        "BEND_MAP_ID" : 937,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "936",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut40) Donald",
        "shared_interaction" : "cut40",
        "name" : "Goofy (cut40) Donald",
        "interaction" : "cut40",
        "SUID" : 936,
        "BEND_MAP_ID" : 936,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "935",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut38) Sora",
        "shared_interaction" : "cut38",
        "name" : "Goofy (cut38) Sora",
        "interaction" : "cut38",
        "SUID" : 935,
        "BEND_MAP_ID" : 935,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "934",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut38) Donald",
        "shared_interaction" : "cut38",
        "name" : "Goofy (cut38) Donald",
        "interaction" : "cut38",
        "SUID" : 934,
        "BEND_MAP_ID" : 934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "933",
        "source" : "106",
        "target" : "443",
        "EdgeBetweenness" : 41.14871794871796,
        "shared_name" : "Goofy (cut37) Hercules",
        "shared_interaction" : "cut37",
        "name" : "Goofy (cut37) Hercules",
        "interaction" : "cut37",
        "SUID" : 933,
        "BEND_MAP_ID" : 933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "932",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut37) Donald",
        "shared_interaction" : "cut37",
        "name" : "Goofy (cut37) Donald",
        "interaction" : "cut37",
        "SUID" : 932,
        "BEND_MAP_ID" : 932,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "931",
        "source" : "106",
        "target" : "292",
        "EdgeBetweenness" : 41.14871794871795,
        "shared_name" : "Goofy (cut37) Philoctetes",
        "shared_interaction" : "cut37",
        "name" : "Goofy (cut37) Philoctetes",
        "interaction" : "cut37",
        "SUID" : 931,
        "BEND_MAP_ID" : 931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "930",
        "source" : "106",
        "target" : "292",
        "EdgeBetweenness" : 41.14871794871795,
        "shared_name" : "Goofy (cut36) Philoctetes",
        "shared_interaction" : "cut36",
        "name" : "Goofy (cut36) Philoctetes",
        "interaction" : "cut36",
        "SUID" : 930,
        "BEND_MAP_ID" : 930,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "929",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut36) Donald",
        "shared_interaction" : "cut36",
        "name" : "Goofy (cut36) Donald",
        "interaction" : "cut36",
        "SUID" : 929,
        "BEND_MAP_ID" : 929,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "928",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut35) Donald",
        "shared_interaction" : "cut35",
        "name" : "Goofy (cut35) Donald",
        "interaction" : "cut35",
        "SUID" : 928,
        "BEND_MAP_ID" : 928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "927",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut35) Sora",
        "shared_interaction" : "cut35",
        "name" : "Goofy (cut35) Sora",
        "interaction" : "cut35",
        "SUID" : 927,
        "BEND_MAP_ID" : 927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "926",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut34) Donald",
        "shared_interaction" : "cut34",
        "name" : "Goofy (cut34) Donald",
        "interaction" : "cut34",
        "SUID" : 926,
        "BEND_MAP_ID" : 926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "925",
        "source" : "106",
        "target" : "275",
        "EdgeBetweenness" : 41.815384615384616,
        "shared_name" : "Goofy (cut33) Cheshire Cat",
        "shared_interaction" : "cut33",
        "name" : "Goofy (cut33) Cheshire Cat",
        "interaction" : "cut33",
        "SUID" : 925,
        "BEND_MAP_ID" : 925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "924",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut33) Sora",
        "shared_interaction" : "cut33",
        "name" : "Goofy (cut33) Sora",
        "interaction" : "cut33",
        "SUID" : 924,
        "BEND_MAP_ID" : 924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "923",
        "source" : "106",
        "target" : "272",
        "EdgeBetweenness" : 39.98205128205128,
        "shared_name" : "Goofy (cut32) Card Soldier",
        "shared_interaction" : "cut32",
        "name" : "Goofy (cut32) Card Soldier",
        "interaction" : "cut32",
        "SUID" : 923,
        "BEND_MAP_ID" : 923,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "922",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut32) Donald",
        "shared_interaction" : "cut32",
        "name" : "Goofy (cut32) Donald",
        "interaction" : "cut32",
        "SUID" : 922,
        "BEND_MAP_ID" : 922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "921",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut32) Sora",
        "shared_interaction" : "cut32",
        "name" : "Goofy (cut32) Sora",
        "interaction" : "cut32",
        "SUID" : 921,
        "BEND_MAP_ID" : 921,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "920",
        "source" : "106",
        "target" : "265",
        "EdgeBetweenness" : 84.40952380952379,
        "shared_name" : "Goofy (cut32) Alice",
        "shared_interaction" : "cut32",
        "name" : "Goofy (cut32) Alice",
        "interaction" : "cut32",
        "SUID" : 920,
        "BEND_MAP_ID" : 920,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "919",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut31) Sora",
        "shared_interaction" : "cut31",
        "name" : "Goofy (cut31) Sora",
        "interaction" : "cut31",
        "SUID" : 919,
        "BEND_MAP_ID" : 919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "918",
        "source" : "106",
        "target" : "263",
        "EdgeBetweenness" : 39.98205128205127,
        "shared_name" : "Goofy (cut31) Queen of Hearts",
        "shared_interaction" : "cut31",
        "name" : "Goofy (cut31) Queen of Hearts",
        "interaction" : "cut31",
        "SUID" : 918,
        "BEND_MAP_ID" : 918,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "917",
        "source" : "106",
        "target" : "263",
        "EdgeBetweenness" : 39.98205128205127,
        "shared_name" : "Goofy (cut30) Queen of Hearts",
        "shared_interaction" : "cut30",
        "name" : "Goofy (cut30) Queen of Hearts",
        "interaction" : "cut30",
        "SUID" : 917,
        "BEND_MAP_ID" : 917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "916",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut30) Donald",
        "shared_interaction" : "cut30",
        "name" : "Goofy (cut30) Donald",
        "interaction" : "cut30",
        "SUID" : 916,
        "BEND_MAP_ID" : 916,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "915",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut30) Sora",
        "shared_interaction" : "cut30",
        "name" : "Goofy (cut30) Sora",
        "interaction" : "cut30",
        "SUID" : 915,
        "BEND_MAP_ID" : 915,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "914",
        "source" : "106",
        "target" : "258",
        "EdgeBetweenness" : 55.74603174603175,
        "shared_name" : "Goofy (cut29) Doorknob",
        "shared_interaction" : "cut29",
        "name" : "Goofy (cut29) Doorknob",
        "interaction" : "cut29",
        "SUID" : 914,
        "BEND_MAP_ID" : 914,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "913",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut28) Donald",
        "shared_interaction" : "cut28",
        "name" : "Goofy (cut28) Donald",
        "interaction" : "cut28",
        "SUID" : 913,
        "BEND_MAP_ID" : 913,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "912",
        "source" : "106",
        "target" : "253",
        "EdgeBetweenness" : 38.23296703296703,
        "shared_name" : "Goofy (cut27) Jiminy",
        "shared_interaction" : "cut27",
        "name" : "Goofy (cut27) Jiminy",
        "interaction" : "cut27",
        "SUID" : 912,
        "BEND_MAP_ID" : 912,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "911",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut27) Donald",
        "shared_interaction" : "cut27",
        "name" : "Goofy (cut27) Donald",
        "interaction" : "cut27",
        "SUID" : 911,
        "BEND_MAP_ID" : 911,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "910",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut27) Sora",
        "shared_interaction" : "cut27",
        "name" : "Goofy (cut27) Sora",
        "interaction" : "cut27",
        "SUID" : 910,
        "BEND_MAP_ID" : 910,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "909",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut26) Donald",
        "shared_interaction" : "cut26",
        "name" : "Goofy (cut26) Donald",
        "interaction" : "cut26",
        "SUID" : 909,
        "BEND_MAP_ID" : 909,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "908",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut25) Donald",
        "shared_interaction" : "cut25",
        "name" : "Goofy (cut25) Donald",
        "interaction" : "cut25",
        "SUID" : 908,
        "BEND_MAP_ID" : 908,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "907",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut25) Sora",
        "shared_interaction" : "cut25",
        "name" : "Goofy (cut25) Sora",
        "interaction" : "cut25",
        "SUID" : 907,
        "BEND_MAP_ID" : 907,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "906",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut24) Donald",
        "shared_interaction" : "cut24",
        "name" : "Goofy (cut24) Donald",
        "interaction" : "cut24",
        "SUID" : 906,
        "BEND_MAP_ID" : 906,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "905",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut24) Sora",
        "shared_interaction" : "cut24",
        "name" : "Goofy (cut24) Sora",
        "interaction" : "cut24",
        "SUID" : 905,
        "BEND_MAP_ID" : 905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "904",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut23) Donald",
        "shared_interaction" : "cut23",
        "name" : "Goofy (cut23) Donald",
        "interaction" : "cut23",
        "SUID" : 904,
        "BEND_MAP_ID" : 904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "903",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut22) Donald",
        "shared_interaction" : "cut22",
        "name" : "Goofy (cut22) Donald",
        "interaction" : "cut22",
        "SUID" : 903,
        "BEND_MAP_ID" : 903,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "902",
        "source" : "106",
        "target" : "84",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Goofy (cut21) Sora",
        "shared_interaction" : "cut21",
        "name" : "Goofy (cut21) Sora",
        "interaction" : "cut21",
        "SUID" : 902,
        "BEND_MAP_ID" : 902,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "901",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut19) Donald",
        "shared_interaction" : "cut19",
        "name" : "Goofy (cut19) Donald",
        "interaction" : "cut19",
        "SUID" : 901,
        "BEND_MAP_ID" : 901,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "900",
        "source" : "106",
        "target" : "179",
        "EdgeBetweenness" : 37.11688311688311,
        "shared_name" : "Goofy (cut19) Aerith",
        "shared_interaction" : "cut19",
        "name" : "Goofy (cut19) Aerith",
        "interaction" : "cut19",
        "SUID" : 900,
        "BEND_MAP_ID" : 900,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "899",
        "source" : "106",
        "target" : "179",
        "EdgeBetweenness" : 37.11688311688311,
        "shared_name" : "Goofy (cut18) Aerith",
        "shared_interaction" : "cut18",
        "name" : "Goofy (cut18) Aerith",
        "interaction" : "cut18",
        "SUID" : 899,
        "BEND_MAP_ID" : 899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "898",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut17) Donald",
        "shared_interaction" : "cut17",
        "name" : "Goofy (cut17) Donald",
        "interaction" : "cut17",
        "SUID" : 898,
        "BEND_MAP_ID" : 898,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "897",
        "source" : "106",
        "target" : "179",
        "EdgeBetweenness" : 37.11688311688311,
        "shared_name" : "Goofy (cut17) Aerith",
        "shared_interaction" : "cut17",
        "name" : "Goofy (cut17) Aerith",
        "interaction" : "cut17",
        "SUID" : 897,
        "BEND_MAP_ID" : 897,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "896",
        "source" : "106",
        "target" : "177",
        "EdgeBetweenness" : 37.516883116883115,
        "shared_name" : "Goofy (cut16) Yuffie",
        "shared_interaction" : "cut16",
        "name" : "Goofy (cut16) Yuffie",
        "interaction" : "cut16",
        "SUID" : 896,
        "BEND_MAP_ID" : 896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "895",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut15) Donald",
        "shared_interaction" : "cut15",
        "name" : "Goofy (cut15) Donald",
        "interaction" : "cut15",
        "SUID" : 895,
        "BEND_MAP_ID" : 895,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "894",
        "source" : "106",
        "target" : "179",
        "EdgeBetweenness" : 37.11688311688311,
        "shared_name" : "Goofy (cut15) Aerith",
        "shared_interaction" : "cut15",
        "name" : "Goofy (cut15) Aerith",
        "interaction" : "cut15",
        "SUID" : 894,
        "BEND_MAP_ID" : 894,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "893",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut14) Donald",
        "shared_interaction" : "cut14",
        "name" : "Goofy (cut14) Donald",
        "interaction" : "cut14",
        "SUID" : 893,
        "BEND_MAP_ID" : 893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "892",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut13) Donald",
        "shared_interaction" : "cut13",
        "name" : "Goofy (cut13) Donald",
        "interaction" : "cut13",
        "SUID" : 892,
        "BEND_MAP_ID" : 892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "891",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut12) Donald",
        "shared_interaction" : "cut12",
        "name" : "Goofy (cut12) Donald",
        "interaction" : "cut12",
        "SUID" : 891,
        "BEND_MAP_ID" : 891,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "890",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut11) Donald",
        "shared_interaction" : "cut11",
        "name" : "Goofy (cut11) Donald",
        "interaction" : "cut11",
        "SUID" : 890,
        "BEND_MAP_ID" : 890,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "889",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut10) Donald",
        "shared_interaction" : "cut10",
        "name" : "Goofy (cut10) Donald",
        "interaction" : "cut10",
        "SUID" : 889,
        "BEND_MAP_ID" : 889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "888",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut7) Donald",
        "shared_interaction" : "cut7",
        "name" : "Goofy (cut7) Donald",
        "interaction" : "cut7",
        "SUID" : 888,
        "BEND_MAP_ID" : 888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "887",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut6) Donald",
        "shared_interaction" : "cut6",
        "name" : "Goofy (cut6) Donald",
        "interaction" : "cut6",
        "SUID" : 887,
        "BEND_MAP_ID" : 887,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "886",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut3) Donald",
        "shared_interaction" : "cut3",
        "name" : "Goofy (cut3) Donald",
        "interaction" : "cut3",
        "SUID" : 886,
        "BEND_MAP_ID" : 886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "885",
        "source" : "106",
        "target" : "253",
        "EdgeBetweenness" : 38.23296703296703,
        "shared_name" : "Goofy (cut3) Jiminy",
        "shared_interaction" : "cut3",
        "name" : "Goofy (cut3) Jiminy",
        "interaction" : "cut3",
        "SUID" : 885,
        "BEND_MAP_ID" : 885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "884",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut2) Donald",
        "shared_interaction" : "cut2",
        "name" : "Goofy (cut2) Donald",
        "interaction" : "cut2",
        "SUID" : 884,
        "BEND_MAP_ID" : 884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "883",
        "source" : "106",
        "target" : "706",
        "EdgeBetweenness" : 90.55757575757576,
        "shared_name" : "Goofy (cut2) Minnie",
        "shared_interaction" : "cut2",
        "name" : "Goofy (cut2) Minnie",
        "interaction" : "cut2",
        "SUID" : 883,
        "BEND_MAP_ID" : 883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "882",
        "source" : "106",
        "target" : "704",
        "EdgeBetweenness" : 90.55757575757576,
        "shared_name" : "Goofy (cut2) Daisy",
        "shared_interaction" : "cut2",
        "name" : "Goofy (cut2) Daisy",
        "interaction" : "cut2",
        "SUID" : 882,
        "BEND_MAP_ID" : 882,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "881",
        "source" : "106",
        "target" : "114",
        "EdgeBetweenness" : 33.966666666666654,
        "shared_name" : "Goofy (cut1) Donald",
        "shared_interaction" : "cut1",
        "name" : "Goofy (cut1) Donald",
        "interaction" : "cut1",
        "SUID" : 881,
        "BEND_MAP_ID" : 881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1761",
        "source" : "104",
        "target" : "102",
        "EdgeBetweenness" : 5.699999999999999,
        "shared_name" : "Captain Hook (cut4) Hook",
        "shared_interaction" : "cut4",
        "name" : "Captain Hook (cut4) Hook",
        "interaction" : "cut4",
        "SUID" : 1761,
        "BEND_MAP_ID" : 1761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1760",
        "source" : "104",
        "target" : "666",
        "EdgeBetweenness" : 4.633333333333333,
        "shared_name" : "Captain Hook (cut4) Smee",
        "shared_interaction" : "cut4",
        "name" : "Captain Hook (cut4) Smee",
        "interaction" : "cut4",
        "SUID" : 1760,
        "BEND_MAP_ID" : 1760,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1759",
        "source" : "104",
        "target" : "666",
        "EdgeBetweenness" : 4.633333333333333,
        "shared_name" : "Captain Hook (cut3) Smee",
        "shared_interaction" : "cut3",
        "name" : "Captain Hook (cut3) Smee",
        "interaction" : "cut3",
        "SUID" : 1759,
        "BEND_MAP_ID" : 1759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1758",
        "source" : "104",
        "target" : "96",
        "EdgeBetweenness" : 90.42900432900436,
        "shared_name" : "Captain Hook (cut3) Riku",
        "shared_interaction" : "cut3",
        "name" : "Captain Hook (cut3) Riku",
        "interaction" : "cut3",
        "SUID" : 1758,
        "BEND_MAP_ID" : 1758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1757",
        "source" : "104",
        "target" : "96",
        "EdgeBetweenness" : 90.42900432900436,
        "shared_name" : "Captain Hook (cut2) Riku",
        "shared_interaction" : "cut2",
        "name" : "Captain Hook (cut2) Riku",
        "interaction" : "cut2",
        "SUID" : 1757,
        "BEND_MAP_ID" : 1757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1756",
        "source" : "104",
        "target" : "71",
        "EdgeBetweenness" : 75.904329004329,
        "shared_name" : "Captain Hook (cut1) ????",
        "shared_interaction" : "cut1",
        "name" : "Captain Hook (cut1) ????",
        "interaction" : "cut1",
        "SUID" : 1756,
        "BEND_MAP_ID" : 1756,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1899",
        "source" : "102",
        "target" : "666",
        "EdgeBetweenness" : 8.333333333333334,
        "shared_name" : "Hook (cut3) Smee",
        "shared_interaction" : "cut3",
        "name" : "Hook (cut3) Smee",
        "interaction" : "cut3",
        "SUID" : 1899,
        "BEND_MAP_ID" : 1899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1898",
        "source" : "102",
        "target" : "104",
        "EdgeBetweenness" : 5.699999999999999,
        "shared_name" : "Hook (cut3) Captain Hook",
        "shared_interaction" : "cut3",
        "name" : "Hook (cut3) Captain Hook",
        "interaction" : "cut3",
        "SUID" : 1898,
        "BEND_MAP_ID" : 1898,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1897",
        "source" : "102",
        "target" : "666",
        "EdgeBetweenness" : 8.333333333333334,
        "shared_name" : "Hook (cut2) Smee",
        "shared_interaction" : "cut2",
        "name" : "Hook (cut2) Smee",
        "interaction" : "cut2",
        "SUID" : 1897,
        "BEND_MAP_ID" : 1897,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1896",
        "source" : "102",
        "target" : "71",
        "EdgeBetweenness" : 155.23333333333332,
        "shared_name" : "Hook (cut1) ????",
        "shared_interaction" : "cut1",
        "name" : "Hook (cut1) ????",
        "interaction" : "cut1",
        "SUID" : 1896,
        "BEND_MAP_ID" : 1896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1466",
        "source" : "98",
        "target" : "96",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Maleficent (cut25) Riku",
        "shared_interaction" : "cut25",
        "name" : "Maleficent (cut25) Riku",
        "interaction" : "cut25",
        "SUID" : 1466,
        "BEND_MAP_ID" : 1466,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1465",
        "source" : "98",
        "target" : "96",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Maleficent (cut24) Riku",
        "shared_interaction" : "cut24",
        "name" : "Maleficent (cut24) Riku",
        "interaction" : "cut24",
        "SUID" : 1465,
        "BEND_MAP_ID" : 1465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1464",
        "source" : "98",
        "target" : "96",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Maleficent (cut22) Riku",
        "shared_interaction" : "cut22",
        "name" : "Maleficent (cut22) Riku",
        "interaction" : "cut22",
        "SUID" : 1464,
        "BEND_MAP_ID" : 1464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1463",
        "source" : "98",
        "target" : "96",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Maleficent (cut18) Riku",
        "shared_interaction" : "cut18",
        "name" : "Maleficent (cut18) Riku",
        "interaction" : "cut18",
        "SUID" : 1463,
        "BEND_MAP_ID" : 1463,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1462",
        "source" : "98",
        "target" : "96",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Maleficent (cut17) Riku",
        "shared_interaction" : "cut17",
        "name" : "Maleficent (cut17) Riku",
        "interaction" : "cut17",
        "SUID" : 1462,
        "BEND_MAP_ID" : 1462,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1461",
        "source" : "98",
        "target" : "96",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Maleficent (cut16) Riku",
        "shared_interaction" : "cut16",
        "name" : "Maleficent (cut16) Riku",
        "interaction" : "cut16",
        "SUID" : 1461,
        "BEND_MAP_ID" : 1461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1460",
        "source" : "98",
        "target" : "96",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Maleficent (cut14) Riku",
        "shared_interaction" : "cut14",
        "name" : "Maleficent (cut14) Riku",
        "interaction" : "cut14",
        "SUID" : 1460,
        "BEND_MAP_ID" : 1460,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1459",
        "source" : "98",
        "target" : "96",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Maleficent (cut13) Riku",
        "shared_interaction" : "cut13",
        "name" : "Maleficent (cut13) Riku",
        "interaction" : "cut13",
        "SUID" : 1459,
        "BEND_MAP_ID" : 1459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1458",
        "source" : "98",
        "target" : "96",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Maleficent (cut11) Riku",
        "shared_interaction" : "cut11",
        "name" : "Maleficent (cut11) Riku",
        "interaction" : "cut11",
        "SUID" : 1458,
        "BEND_MAP_ID" : 1458,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1457",
        "source" : "98",
        "target" : "71",
        "EdgeBetweenness" : 42.56961926961927,
        "shared_name" : "Maleficent (cut11) ????",
        "shared_interaction" : "cut11",
        "name" : "Maleficent (cut11) ????",
        "interaction" : "cut11",
        "SUID" : 1457,
        "BEND_MAP_ID" : 1457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1456",
        "source" : "98",
        "target" : "96",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Maleficent (cut10) Riku",
        "shared_interaction" : "cut10",
        "name" : "Maleficent (cut10) Riku",
        "interaction" : "cut10",
        "SUID" : 1456,
        "BEND_MAP_ID" : 1456,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1455",
        "source" : "98",
        "target" : "296",
        "EdgeBetweenness" : 29.139460539460533,
        "shared_name" : "Maleficent (cut8) Hades",
        "shared_interaction" : "cut8",
        "name" : "Maleficent (cut8) Hades",
        "interaction" : "cut8",
        "SUID" : 1455,
        "BEND_MAP_ID" : 1455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1454",
        "source" : "98",
        "target" : "96",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Maleficent (cut8) Riku",
        "shared_interaction" : "cut8",
        "name" : "Maleficent (cut8) Riku",
        "interaction" : "cut8",
        "SUID" : 1454,
        "BEND_MAP_ID" : 1454,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1453",
        "source" : "98",
        "target" : "123",
        "EdgeBetweenness" : 36.11626151626152,
        "shared_name" : "Maleficent (cut7) Jafar",
        "shared_interaction" : "cut7",
        "name" : "Maleficent (cut7) Jafar",
        "interaction" : "cut7",
        "SUID" : 1453,
        "BEND_MAP_ID" : 1453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1452",
        "source" : "98",
        "target" : "123",
        "EdgeBetweenness" : 36.11626151626152,
        "shared_name" : "Maleficent (cut5) Jafar",
        "shared_interaction" : "cut5",
        "name" : "Maleficent (cut5) Jafar",
        "interaction" : "cut5",
        "SUID" : 1452,
        "BEND_MAP_ID" : 1452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1451",
        "source" : "98",
        "target" : "1450",
        "EdgeBetweenness" : 25.129437229437226,
        "shared_name" : "Maleficent (cut5) Iago",
        "shared_interaction" : "cut5",
        "name" : "Maleficent (cut5) Iago",
        "interaction" : "cut5",
        "SUID" : 1451,
        "BEND_MAP_ID" : 1451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1449",
        "source" : "98",
        "target" : "78",
        "EdgeBetweenness" : 38.35363525363525,
        "shared_name" : "Maleficent (cut4) ?????",
        "shared_interaction" : "cut4",
        "name" : "Maleficent (cut4) ?????",
        "interaction" : "cut4",
        "SUID" : 1449,
        "BEND_MAP_ID" : 1449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "702",
        "source" : "96",
        "target" : "106",
        "EdgeBetweenness" : 90.84440559440557,
        "shared_name" : "Riku (cut108) Goofy",
        "shared_interaction" : "cut108",
        "name" : "Riku (cut108) Goofy",
        "interaction" : "cut108",
        "SUID" : 702,
        "BEND_MAP_ID" : 702,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "701",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut108) Sora",
        "shared_interaction" : "cut108",
        "name" : "Riku (cut108) Sora",
        "interaction" : "cut108",
        "SUID" : 701,
        "BEND_MAP_ID" : 701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "700",
        "source" : "96",
        "target" : "114",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Riku (cut108) Donald",
        "shared_interaction" : "cut108",
        "name" : "Riku (cut108) Donald",
        "interaction" : "cut108",
        "SUID" : 700,
        "BEND_MAP_ID" : 700,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "699",
        "source" : "96",
        "target" : "603",
        "EdgeBetweenness" : 14.947252747252747,
        "shared_name" : "Riku (cut108) Mickey",
        "shared_interaction" : "cut108",
        "name" : "Riku (cut108) Mickey",
        "interaction" : "cut108",
        "SUID" : 699,
        "BEND_MAP_ID" : 699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "698",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut107) Sora",
        "shared_interaction" : "cut107",
        "name" : "Riku (cut107) Sora",
        "interaction" : "cut107",
        "SUID" : 698,
        "BEND_MAP_ID" : 698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "697",
        "source" : "96",
        "target" : "78",
        "EdgeBetweenness" : 15.233832833832833,
        "shared_name" : "Riku (cut103) ?????",
        "shared_interaction" : "cut103",
        "name" : "Riku (cut103) ?????",
        "interaction" : "cut103",
        "SUID" : 697,
        "BEND_MAP_ID" : 697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "696",
        "source" : "96",
        "target" : "78",
        "EdgeBetweenness" : 15.233832833832833,
        "shared_name" : "Riku (cut102) ?????",
        "shared_interaction" : "cut102",
        "name" : "Riku (cut102) ?????",
        "interaction" : "cut102",
        "SUID" : 696,
        "BEND_MAP_ID" : 696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "source" : "96",
        "target" : "78",
        "EdgeBetweenness" : 15.233832833832833,
        "shared_name" : "Riku (cut101) ?????",
        "shared_interaction" : "cut101",
        "name" : "Riku (cut101) ?????",
        "interaction" : "cut101",
        "SUID" : 695,
        "BEND_MAP_ID" : 695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "694",
        "source" : "96",
        "target" : "82",
        "EdgeBetweenness" : 16.655627705627705,
        "shared_name" : "Riku (cut97) Kairi",
        "shared_interaction" : "cut97",
        "name" : "Riku (cut97) Kairi",
        "interaction" : "cut97",
        "SUID" : 694,
        "BEND_MAP_ID" : 694,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "693",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut95) Sora",
        "shared_interaction" : "cut95",
        "name" : "Riku (cut95) Sora",
        "interaction" : "cut95",
        "SUID" : 693,
        "BEND_MAP_ID" : 693,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "692",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut94) Sora",
        "shared_interaction" : "cut94",
        "name" : "Riku (cut94) Sora",
        "interaction" : "cut94",
        "SUID" : 692,
        "BEND_MAP_ID" : 692,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "691",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut93) Sora",
        "shared_interaction" : "cut93",
        "name" : "Riku (cut93) Sora",
        "interaction" : "cut93",
        "SUID" : 691,
        "BEND_MAP_ID" : 691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "690",
        "source" : "96",
        "target" : "114",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Riku (cut93) Donald",
        "shared_interaction" : "cut93",
        "name" : "Riku (cut93) Donald",
        "interaction" : "cut93",
        "SUID" : 690,
        "BEND_MAP_ID" : 690,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut92) Sora",
        "shared_interaction" : "cut92",
        "name" : "Riku (cut92) Sora",
        "interaction" : "cut92",
        "SUID" : 689,
        "BEND_MAP_ID" : 689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "688",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut91) Sora",
        "shared_interaction" : "cut91",
        "name" : "Riku (cut91) Sora",
        "interaction" : "cut91",
        "SUID" : 688,
        "BEND_MAP_ID" : 688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "687",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut89) Sora",
        "shared_interaction" : "cut89",
        "name" : "Riku (cut89) Sora",
        "interaction" : "cut89",
        "SUID" : 687,
        "BEND_MAP_ID" : 687,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "686",
        "source" : "96",
        "target" : "114",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Riku (cut88) Donald",
        "shared_interaction" : "cut88",
        "name" : "Riku (cut88) Donald",
        "interaction" : "cut88",
        "SUID" : 686,
        "BEND_MAP_ID" : 686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "685",
        "source" : "96",
        "target" : "114",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Riku (cut85) Donald",
        "shared_interaction" : "cut85",
        "name" : "Riku (cut85) Donald",
        "interaction" : "cut85",
        "SUID" : 685,
        "BEND_MAP_ID" : 685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "684",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut84) Sora",
        "shared_interaction" : "cut84",
        "name" : "Riku (cut84) Sora",
        "interaction" : "cut84",
        "SUID" : 684,
        "BEND_MAP_ID" : 684,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "683",
        "source" : "96",
        "target" : "98",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Riku (cut82) Maleficent",
        "shared_interaction" : "cut82",
        "name" : "Riku (cut82) Maleficent",
        "interaction" : "cut82",
        "SUID" : 683,
        "BEND_MAP_ID" : 683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "682",
        "source" : "96",
        "target" : "98",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Riku (cut81) Maleficent",
        "shared_interaction" : "cut81",
        "name" : "Riku (cut81) Maleficent",
        "interaction" : "cut81",
        "SUID" : 682,
        "BEND_MAP_ID" : 682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "681",
        "source" : "96",
        "target" : "78",
        "EdgeBetweenness" : 15.233832833832833,
        "shared_name" : "Riku (cut80) ?????",
        "shared_interaction" : "cut80",
        "name" : "Riku (cut80) ?????",
        "interaction" : "cut80",
        "SUID" : 681,
        "BEND_MAP_ID" : 681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "680",
        "source" : "96",
        "target" : "78",
        "EdgeBetweenness" : 15.233832833832833,
        "shared_name" : "Riku (cut78) ?????",
        "shared_interaction" : "cut78",
        "name" : "Riku (cut78) ?????",
        "interaction" : "cut78",
        "SUID" : 680,
        "BEND_MAP_ID" : 680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "679",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut76) Sora",
        "shared_interaction" : "cut76",
        "name" : "Riku (cut76) Sora",
        "interaction" : "cut76",
        "SUID" : 679,
        "BEND_MAP_ID" : 679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "678",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut75) Sora",
        "shared_interaction" : "cut75",
        "name" : "Riku (cut75) Sora",
        "interaction" : "cut75",
        "SUID" : 678,
        "BEND_MAP_ID" : 678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "source" : "96",
        "target" : "106",
        "EdgeBetweenness" : 90.84440559440557,
        "shared_name" : "Riku (cut75) Goofy",
        "shared_interaction" : "cut75",
        "name" : "Riku (cut75) Goofy",
        "interaction" : "cut75",
        "SUID" : 677,
        "BEND_MAP_ID" : 677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "676",
        "source" : "96",
        "target" : "114",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Riku (cut75) Donald",
        "shared_interaction" : "cut75",
        "name" : "Riku (cut75) Donald",
        "interaction" : "cut75",
        "SUID" : 676,
        "BEND_MAP_ID" : 676,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "675",
        "source" : "96",
        "target" : "106",
        "EdgeBetweenness" : 90.84440559440557,
        "shared_name" : "Riku (cut74) Goofy",
        "shared_interaction" : "cut74",
        "name" : "Riku (cut74) Goofy",
        "interaction" : "cut74",
        "SUID" : 675,
        "BEND_MAP_ID" : 675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "674",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut73) Sora",
        "shared_interaction" : "cut73",
        "name" : "Riku (cut73) Sora",
        "interaction" : "cut73",
        "SUID" : 674,
        "BEND_MAP_ID" : 674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "673",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut72) Sora",
        "shared_interaction" : "cut72",
        "name" : "Riku (cut72) Sora",
        "interaction" : "cut72",
        "SUID" : 673,
        "BEND_MAP_ID" : 673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "672",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut68) Sora",
        "shared_interaction" : "cut68",
        "name" : "Riku (cut68) Sora",
        "interaction" : "cut68",
        "SUID" : 672,
        "BEND_MAP_ID" : 672,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut64) Sora",
        "shared_interaction" : "cut64",
        "name" : "Riku (cut64) Sora",
        "interaction" : "cut64",
        "SUID" : 671,
        "BEND_MAP_ID" : 671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "670",
        "source" : "96",
        "target" : "534",
        "EdgeBetweenness" : 14.947252747252747,
        "shared_name" : "Riku (cut63) Beast",
        "shared_interaction" : "cut63",
        "name" : "Riku (cut63) Beast",
        "interaction" : "cut63",
        "SUID" : 670,
        "BEND_MAP_ID" : 670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "669",
        "source" : "96",
        "target" : "98",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Riku (cut61) Maleficent",
        "shared_interaction" : "cut61",
        "name" : "Riku (cut61) Maleficent",
        "interaction" : "cut61",
        "SUID" : 669,
        "BEND_MAP_ID" : 669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "668",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut60) Sora",
        "shared_interaction" : "cut60",
        "name" : "Riku (cut60) Sora",
        "interaction" : "cut60",
        "SUID" : 668,
        "BEND_MAP_ID" : 668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "667",
        "source" : "96",
        "target" : "666",
        "EdgeBetweenness" : 158.43333333333334,
        "shared_name" : "Riku (cut59) Smee",
        "shared_interaction" : "cut59",
        "name" : "Riku (cut59) Smee",
        "interaction" : "cut59",
        "SUID" : 667,
        "BEND_MAP_ID" : 667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "source" : "96",
        "target" : "104",
        "EdgeBetweenness" : 90.42900432900436,
        "shared_name" : "Riku (cut59) Captain Hook",
        "shared_interaction" : "cut59",
        "name" : "Riku (cut59) Captain Hook",
        "interaction" : "cut59",
        "SUID" : 665,
        "BEND_MAP_ID" : 665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "664",
        "source" : "96",
        "target" : "104",
        "EdgeBetweenness" : 90.42900432900436,
        "shared_name" : "Riku (cut58) Captain Hook",
        "shared_interaction" : "cut58",
        "name" : "Riku (cut58) Captain Hook",
        "interaction" : "cut58",
        "SUID" : 664,
        "BEND_MAP_ID" : 664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "663",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut55) Sora",
        "shared_interaction" : "cut55",
        "name" : "Riku (cut55) Sora",
        "interaction" : "cut55",
        "SUID" : 663,
        "BEND_MAP_ID" : 663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "662",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut54) Sora",
        "shared_interaction" : "cut54",
        "name" : "Riku (cut54) Sora",
        "interaction" : "cut54",
        "SUID" : 662,
        "BEND_MAP_ID" : 662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "661",
        "source" : "96",
        "target" : "71",
        "EdgeBetweenness" : 17.78058608058608,
        "shared_name" : "Riku (cut53) ????",
        "shared_interaction" : "cut53",
        "name" : "Riku (cut53) ????",
        "interaction" : "cut53",
        "SUID" : 661,
        "BEND_MAP_ID" : 661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "660",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut53) Sora",
        "shared_interaction" : "cut53",
        "name" : "Riku (cut53) Sora",
        "interaction" : "cut53",
        "SUID" : 660,
        "BEND_MAP_ID" : 660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "659",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut51) Sora",
        "shared_interaction" : "cut51",
        "name" : "Riku (cut51) Sora",
        "interaction" : "cut51",
        "SUID" : 659,
        "BEND_MAP_ID" : 659,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "658",
        "source" : "96",
        "target" : "98",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Riku (cut48) Maleficent",
        "shared_interaction" : "cut48",
        "name" : "Riku (cut48) Maleficent",
        "interaction" : "cut48",
        "SUID" : 658,
        "BEND_MAP_ID" : 658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "657",
        "source" : "96",
        "target" : "98",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Riku (cut47) Maleficent",
        "shared_interaction" : "cut47",
        "name" : "Riku (cut47) Maleficent",
        "interaction" : "cut47",
        "SUID" : 657,
        "BEND_MAP_ID" : 657,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "656",
        "source" : "96",
        "target" : "98",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Riku (cut46) Maleficent",
        "shared_interaction" : "cut46",
        "name" : "Riku (cut46) Maleficent",
        "interaction" : "cut46",
        "SUID" : 656,
        "BEND_MAP_ID" : 656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "655",
        "source" : "96",
        "target" : "387",
        "EdgeBetweenness" : 18.833333333333336,
        "shared_name" : "Riku (cut45) Pinocchio",
        "shared_interaction" : "cut45",
        "name" : "Riku (cut45) Pinocchio",
        "interaction" : "cut45",
        "SUID" : 655,
        "BEND_MAP_ID" : 655,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "654",
        "source" : "96",
        "target" : "253",
        "EdgeBetweenness" : 13.947252747252747,
        "shared_name" : "Riku (cut45) Jiminy",
        "shared_interaction" : "cut45",
        "name" : "Riku (cut45) Jiminy",
        "interaction" : "cut45",
        "SUID" : 654,
        "BEND_MAP_ID" : 654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "653",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut45) Sora",
        "shared_interaction" : "cut45",
        "name" : "Riku (cut45) Sora",
        "interaction" : "cut45",
        "SUID" : 653,
        "BEND_MAP_ID" : 653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "652",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut44) Sora",
        "shared_interaction" : "cut44",
        "name" : "Riku (cut44) Sora",
        "interaction" : "cut44",
        "SUID" : 652,
        "BEND_MAP_ID" : 652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "651",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut42) Sora",
        "shared_interaction" : "cut42",
        "name" : "Riku (cut42) Sora",
        "interaction" : "cut42",
        "SUID" : 651,
        "BEND_MAP_ID" : 651,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "650",
        "source" : "96",
        "target" : "432",
        "EdgeBetweenness" : 22.62380952380952,
        "shared_name" : "Riku (cut42) Geppetto",
        "shared_interaction" : "cut42",
        "name" : "Riku (cut42) Geppetto",
        "interaction" : "cut42",
        "SUID" : 650,
        "BEND_MAP_ID" : 650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "649",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut40) Sora",
        "shared_interaction" : "cut40",
        "name" : "Riku (cut40) Sora",
        "interaction" : "cut40",
        "SUID" : 649,
        "BEND_MAP_ID" : 649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "648",
        "source" : "96",
        "target" : "98",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Riku (cut38) Maleficent",
        "shared_interaction" : "cut38",
        "name" : "Riku (cut38) Maleficent",
        "interaction" : "cut38",
        "SUID" : 648,
        "BEND_MAP_ID" : 648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "647",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut37) Sora",
        "shared_interaction" : "cut37",
        "name" : "Riku (cut37) Sora",
        "interaction" : "cut37",
        "SUID" : 647,
        "BEND_MAP_ID" : 647,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "646",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut35) Sora",
        "shared_interaction" : "cut35",
        "name" : "Riku (cut35) Sora",
        "interaction" : "cut35",
        "SUID" : 646,
        "BEND_MAP_ID" : 646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "645",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut34) Sora",
        "shared_interaction" : "cut34",
        "name" : "Riku (cut34) Sora",
        "interaction" : "cut34",
        "SUID" : 645,
        "BEND_MAP_ID" : 645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "644",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut33) Sora",
        "shared_interaction" : "cut33",
        "name" : "Riku (cut33) Sora",
        "interaction" : "cut33",
        "SUID" : 644,
        "BEND_MAP_ID" : 644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "643",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut31) Sora",
        "shared_interaction" : "cut31",
        "name" : "Riku (cut31) Sora",
        "interaction" : "cut31",
        "SUID" : 643,
        "BEND_MAP_ID" : 643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "642",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut30) Sora",
        "shared_interaction" : "cut30",
        "name" : "Riku (cut30) Sora",
        "interaction" : "cut30",
        "SUID" : 642,
        "BEND_MAP_ID" : 642,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "641",
        "source" : "96",
        "target" : "98",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Riku (cut29) Maleficent",
        "shared_interaction" : "cut29",
        "name" : "Riku (cut29) Maleficent",
        "interaction" : "cut29",
        "SUID" : 641,
        "BEND_MAP_ID" : 641,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "640",
        "source" : "96",
        "target" : "98",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Riku (cut28) Maleficent",
        "shared_interaction" : "cut28",
        "name" : "Riku (cut28) Maleficent",
        "interaction" : "cut28",
        "SUID" : 640,
        "BEND_MAP_ID" : 640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "639",
        "source" : "96",
        "target" : "71",
        "EdgeBetweenness" : 17.78058608058608,
        "shared_name" : "Riku (cut28) ????",
        "shared_interaction" : "cut28",
        "name" : "Riku (cut28) ????",
        "interaction" : "cut28",
        "SUID" : 639,
        "BEND_MAP_ID" : 639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "638",
        "source" : "96",
        "target" : "98",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Riku (cut27) Maleficent",
        "shared_interaction" : "cut27",
        "name" : "Riku (cut27) Maleficent",
        "interaction" : "cut27",
        "SUID" : 638,
        "BEND_MAP_ID" : 638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "637",
        "source" : "96",
        "target" : "296",
        "EdgeBetweenness" : 20.913919413919412,
        "shared_name" : "Riku (cut26) Hades",
        "shared_interaction" : "cut26",
        "name" : "Riku (cut26) Hades",
        "interaction" : "cut26",
        "SUID" : 637,
        "BEND_MAP_ID" : 637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "636",
        "source" : "96",
        "target" : "98",
        "EdgeBetweenness" : 47.607603507603514,
        "shared_name" : "Riku (cut26) Maleficent",
        "shared_interaction" : "cut26",
        "name" : "Riku (cut26) Maleficent",
        "interaction" : "cut26",
        "SUID" : 636,
        "BEND_MAP_ID" : 636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "635",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut25) Sora",
        "shared_interaction" : "cut25",
        "name" : "Riku (cut25) Sora",
        "interaction" : "cut25",
        "SUID" : 635,
        "BEND_MAP_ID" : 635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "634",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut24) Sora",
        "shared_interaction" : "cut24",
        "name" : "Riku (cut24) Sora",
        "interaction" : "cut24",
        "SUID" : 634,
        "BEND_MAP_ID" : 634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "633",
        "source" : "96",
        "target" : "114",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Riku (cut24) Donald",
        "shared_interaction" : "cut24",
        "name" : "Riku (cut24) Donald",
        "interaction" : "cut24",
        "SUID" : 633,
        "BEND_MAP_ID" : 633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "632",
        "source" : "96",
        "target" : "106",
        "EdgeBetweenness" : 90.84440559440557,
        "shared_name" : "Riku (cut24) Goofy",
        "shared_interaction" : "cut24",
        "name" : "Riku (cut24) Goofy",
        "interaction" : "cut24",
        "SUID" : 632,
        "BEND_MAP_ID" : 632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "631",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut23) Sora",
        "shared_interaction" : "cut23",
        "name" : "Riku (cut23) Sora",
        "interaction" : "cut23",
        "SUID" : 631,
        "BEND_MAP_ID" : 631,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "630",
        "source" : "96",
        "target" : "114",
        "EdgeBetweenness" : 63.544405594405575,
        "shared_name" : "Riku (cut23) Donald",
        "shared_interaction" : "cut23",
        "name" : "Riku (cut23) Donald",
        "interaction" : "cut23",
        "SUID" : 630,
        "BEND_MAP_ID" : 630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "629",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut22) Sora",
        "shared_interaction" : "cut22",
        "name" : "Riku (cut22) Sora",
        "interaction" : "cut22",
        "SUID" : 629,
        "BEND_MAP_ID" : 629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "628",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut18) Sora",
        "shared_interaction" : "cut18",
        "name" : "Riku (cut18) Sora",
        "interaction" : "cut18",
        "SUID" : 628,
        "BEND_MAP_ID" : 628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "627",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut17) Sora",
        "shared_interaction" : "cut17",
        "name" : "Riku (cut17) Sora",
        "interaction" : "cut17",
        "SUID" : 627,
        "BEND_MAP_ID" : 627,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "626",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut16) Sora",
        "shared_interaction" : "cut16",
        "name" : "Riku (cut16) Sora",
        "interaction" : "cut16",
        "SUID" : 626,
        "BEND_MAP_ID" : 626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "625",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut12) Sora",
        "shared_interaction" : "cut12",
        "name" : "Riku (cut12) Sora",
        "interaction" : "cut12",
        "SUID" : 625,
        "BEND_MAP_ID" : 625,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "624",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut11) Sora",
        "shared_interaction" : "cut11",
        "name" : "Riku (cut11) Sora",
        "interaction" : "cut11",
        "SUID" : 624,
        "BEND_MAP_ID" : 624,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "623",
        "source" : "96",
        "target" : "82",
        "EdgeBetweenness" : 16.655627705627705,
        "shared_name" : "Riku (cut10) Kairi",
        "shared_interaction" : "cut10",
        "name" : "Riku (cut10) Kairi",
        "interaction" : "cut10",
        "SUID" : 623,
        "BEND_MAP_ID" : 623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "622",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut10) Sora",
        "shared_interaction" : "cut10",
        "name" : "Riku (cut10) Sora",
        "interaction" : "cut10",
        "SUID" : 622,
        "BEND_MAP_ID" : 622,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "621",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut9) Sora",
        "shared_interaction" : "cut9",
        "name" : "Riku (cut9) Sora",
        "interaction" : "cut9",
        "SUID" : 621,
        "BEND_MAP_ID" : 621,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "620",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut8) Sora",
        "shared_interaction" : "cut8",
        "name" : "Riku (cut8) Sora",
        "interaction" : "cut8",
        "SUID" : 620,
        "BEND_MAP_ID" : 620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "619",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut7) Sora",
        "shared_interaction" : "cut7",
        "name" : "Riku (cut7) Sora",
        "interaction" : "cut7",
        "SUID" : 619,
        "BEND_MAP_ID" : 619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "618",
        "source" : "96",
        "target" : "82",
        "EdgeBetweenness" : 16.655627705627705,
        "shared_name" : "Riku (cut5) Kairi",
        "shared_interaction" : "cut5",
        "name" : "Riku (cut5) Kairi",
        "interaction" : "cut5",
        "SUID" : 618,
        "BEND_MAP_ID" : 618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "617",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut5) Sora",
        "shared_interaction" : "cut5",
        "name" : "Riku (cut5) Sora",
        "interaction" : "cut5",
        "SUID" : 617,
        "BEND_MAP_ID" : 617,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "616",
        "source" : "96",
        "target" : "82",
        "EdgeBetweenness" : 16.655627705627705,
        "shared_name" : "Riku (cut4) Kairi",
        "shared_interaction" : "cut4",
        "name" : "Riku (cut4) Kairi",
        "interaction" : "cut4",
        "SUID" : 616,
        "BEND_MAP_ID" : 616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "615",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut4) Sora",
        "shared_interaction" : "cut4",
        "name" : "Riku (cut4) Sora",
        "interaction" : "cut4",
        "SUID" : 615,
        "BEND_MAP_ID" : 615,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "614",
        "source" : "96",
        "target" : "84",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Riku (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Riku (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 614,
        "BEND_MAP_ID" : 614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "613",
        "source" : "96",
        "target" : "82",
        "EdgeBetweenness" : 16.655627705627705,
        "shared_name" : "Riku (cut3) Kairi",
        "shared_interaction" : "cut3",
        "name" : "Riku (cut3) Kairi",
        "interaction" : "cut3",
        "SUID" : 613,
        "BEND_MAP_ID" : 613,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "612",
        "source" : "96",
        "target" : "82",
        "EdgeBetweenness" : 16.655627705627705,
        "shared_name" : "Riku (cut2) Kairi",
        "shared_interaction" : "cut2",
        "name" : "Riku (cut2) Kairi",
        "interaction" : "cut2",
        "SUID" : 612,
        "BEND_MAP_ID" : 612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1437",
        "source" : "94",
        "target" : "84",
        "EdgeBetweenness" : 168.765367965368,
        "shared_name" : "Pooh (cut37) Sora",
        "shared_interaction" : "cut37",
        "name" : "Pooh (cut37) Sora",
        "interaction" : "cut37",
        "SUID" : 1437,
        "BEND_MAP_ID" : 1437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1436",
        "source" : "94",
        "target" : "441",
        "EdgeBetweenness" : 8.071428571428571,
        "shared_name" : "Pooh (cut36) Tigger",
        "shared_interaction" : "cut36",
        "name" : "Pooh (cut36) Tigger",
        "interaction" : "cut36",
        "SUID" : 1436,
        "BEND_MAP_ID" : 1436,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1435",
        "source" : "94",
        "target" : "412",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Pooh (cut36) Piglet",
        "shared_interaction" : "cut36",
        "name" : "Pooh (cut36) Piglet",
        "interaction" : "cut36",
        "SUID" : 1435,
        "BEND_MAP_ID" : 1435,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1434",
        "source" : "94",
        "target" : "412",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Pooh (cut34) Piglet",
        "shared_interaction" : "cut34",
        "name" : "Pooh (cut34) Piglet",
        "interaction" : "cut34",
        "SUID" : 1434,
        "BEND_MAP_ID" : 1434,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1433",
        "source" : "94",
        "target" : "84",
        "EdgeBetweenness" : 168.765367965368,
        "shared_name" : "Pooh (cut33) Sora",
        "shared_interaction" : "cut33",
        "name" : "Pooh (cut33) Sora",
        "interaction" : "cut33",
        "SUID" : 1433,
        "BEND_MAP_ID" : 1433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1432",
        "source" : "94",
        "target" : "591",
        "EdgeBetweenness" : 7.404761904761904,
        "shared_name" : "Pooh (cut29) Eeyore",
        "shared_interaction" : "cut29",
        "name" : "Pooh (cut29) Eeyore",
        "interaction" : "cut29",
        "SUID" : 1432,
        "BEND_MAP_ID" : 1432,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1431",
        "source" : "94",
        "target" : "84",
        "EdgeBetweenness" : 168.765367965368,
        "shared_name" : "Pooh (cut28) Sora",
        "shared_interaction" : "cut28",
        "name" : "Pooh (cut28) Sora",
        "interaction" : "cut28",
        "SUID" : 1431,
        "BEND_MAP_ID" : 1431,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1430",
        "source" : "94",
        "target" : "466",
        "EdgeBetweenness" : 7.7333333333333325,
        "shared_name" : "Pooh (cut27) Owl",
        "shared_interaction" : "cut27",
        "name" : "Pooh (cut27) Owl",
        "interaction" : "cut27",
        "SUID" : 1430,
        "BEND_MAP_ID" : 1430,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1429",
        "source" : "94",
        "target" : "591",
        "EdgeBetweenness" : 7.404761904761904,
        "shared_name" : "Pooh (cut27) Eeyore",
        "shared_interaction" : "cut27",
        "name" : "Pooh (cut27) Eeyore",
        "interaction" : "cut27",
        "SUID" : 1429,
        "BEND_MAP_ID" : 1429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1428",
        "source" : "94",
        "target" : "412",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Pooh (cut25) Piglet",
        "shared_interaction" : "cut25",
        "name" : "Pooh (cut25) Piglet",
        "interaction" : "cut25",
        "SUID" : 1428,
        "BEND_MAP_ID" : 1428,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1427",
        "source" : "94",
        "target" : "441",
        "EdgeBetweenness" : 8.071428571428571,
        "shared_name" : "Pooh (cut23) Tigger",
        "shared_interaction" : "cut23",
        "name" : "Pooh (cut23) Tigger",
        "interaction" : "cut23",
        "SUID" : 1427,
        "BEND_MAP_ID" : 1427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1426",
        "source" : "94",
        "target" : "1421",
        "EdgeBetweenness" : 64.40865800865811,
        "shared_name" : "Pooh (cut22) Rabbit",
        "shared_interaction" : "cut22",
        "name" : "Pooh (cut22) Rabbit",
        "interaction" : "cut22",
        "SUID" : 1426,
        "BEND_MAP_ID" : 1426,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1425",
        "source" : "94",
        "target" : "1421",
        "EdgeBetweenness" : 64.40865800865811,
        "shared_name" : "Pooh (cut21) Rabbit",
        "shared_interaction" : "cut21",
        "name" : "Pooh (cut21) Rabbit",
        "interaction" : "cut21",
        "SUID" : 1425,
        "BEND_MAP_ID" : 1425,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1424",
        "source" : "94",
        "target" : "412",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Pooh (cut21) Piglet",
        "shared_interaction" : "cut21",
        "name" : "Pooh (cut21) Piglet",
        "interaction" : "cut21",
        "SUID" : 1424,
        "BEND_MAP_ID" : 1424,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1423",
        "source" : "94",
        "target" : "1421",
        "EdgeBetweenness" : 64.40865800865811,
        "shared_name" : "Pooh (cut20) Rabbit",
        "shared_interaction" : "cut20",
        "name" : "Pooh (cut20) Rabbit",
        "interaction" : "cut20",
        "SUID" : 1423,
        "BEND_MAP_ID" : 1423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1422",
        "source" : "94",
        "target" : "1421",
        "EdgeBetweenness" : 64.40865800865811,
        "shared_name" : "Pooh (cut18) Rabbit",
        "shared_interaction" : "cut18",
        "name" : "Pooh (cut18) Rabbit",
        "interaction" : "cut18",
        "SUID" : 1422,
        "BEND_MAP_ID" : 1422,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1420",
        "source" : "94",
        "target" : "222",
        "EdgeBetweenness" : 17.82886002886003,
        "shared_name" : "Pooh (cut17) ??????",
        "shared_interaction" : "cut17",
        "name" : "Pooh (cut17) ??????",
        "interaction" : "cut17",
        "SUID" : 1420,
        "BEND_MAP_ID" : 1420,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1419",
        "source" : "94",
        "target" : "222",
        "EdgeBetweenness" : 17.82886002886003,
        "shared_name" : "Pooh (cut15) ??????",
        "shared_interaction" : "cut15",
        "name" : "Pooh (cut15) ??????",
        "interaction" : "cut15",
        "SUID" : 1419,
        "BEND_MAP_ID" : 1419,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1418",
        "source" : "94",
        "target" : "412",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Pooh (cut15) Piglet",
        "shared_interaction" : "cut15",
        "name" : "Pooh (cut15) Piglet",
        "interaction" : "cut15",
        "SUID" : 1418,
        "BEND_MAP_ID" : 1418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1417",
        "source" : "94",
        "target" : "466",
        "EdgeBetweenness" : 7.7333333333333325,
        "shared_name" : "Pooh (cut13) Owl",
        "shared_interaction" : "cut13",
        "name" : "Pooh (cut13) Owl",
        "interaction" : "cut13",
        "SUID" : 1417,
        "BEND_MAP_ID" : 1417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1416",
        "source" : "94",
        "target" : "84",
        "EdgeBetweenness" : 168.765367965368,
        "shared_name" : "Pooh (cut12) Sora",
        "shared_interaction" : "cut12",
        "name" : "Pooh (cut12) Sora",
        "interaction" : "cut12",
        "SUID" : 1416,
        "BEND_MAP_ID" : 1416,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1415",
        "source" : "94",
        "target" : "412",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Pooh (cut10) Piglet",
        "shared_interaction" : "cut10",
        "name" : "Pooh (cut10) Piglet",
        "interaction" : "cut10",
        "SUID" : 1415,
        "BEND_MAP_ID" : 1415,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1414",
        "source" : "94",
        "target" : "412",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Pooh (cut9) Piglet",
        "shared_interaction" : "cut9",
        "name" : "Pooh (cut9) Piglet",
        "interaction" : "cut9",
        "SUID" : 1414,
        "BEND_MAP_ID" : 1414,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1413",
        "source" : "94",
        "target" : "412",
        "EdgeBetweenness" : 5.4,
        "shared_name" : "Pooh (cut8) Piglet",
        "shared_interaction" : "cut8",
        "name" : "Pooh (cut8) Piglet",
        "interaction" : "cut8",
        "SUID" : 1413,
        "BEND_MAP_ID" : 1413,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1412",
        "source" : "94",
        "target" : "84",
        "EdgeBetweenness" : 168.765367965368,
        "shared_name" : "Pooh (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Pooh (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 1412,
        "BEND_MAP_ID" : 1412,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1411",
        "source" : "94",
        "target" : "84",
        "EdgeBetweenness" : 168.765367965368,
        "shared_name" : "Pooh (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Pooh (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 1411,
        "BEND_MAP_ID" : 1411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1410",
        "source" : "94",
        "target" : "71",
        "EdgeBetweenness" : 46.08427128427128,
        "shared_name" : "Pooh (cut1) ????",
        "shared_interaction" : "cut1",
        "name" : "Pooh (cut1) ????",
        "interaction" : "cut1",
        "SUID" : 1410,
        "BEND_MAP_ID" : 1410,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1251",
        "source" : "89",
        "target" : "222",
        "EdgeBetweenness" : 43.63786213786214,
        "shared_name" : "?????????? (cut6) ??????",
        "shared_interaction" : "cut6",
        "name" : "?????????? (cut6) ??????",
        "interaction" : "cut6",
        "SUID" : 1251,
        "BEND_MAP_ID" : 1251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1250",
        "source" : "89",
        "target" : "78",
        "EdgeBetweenness" : 46.29384504384504,
        "shared_name" : "?????????? (cut5) ?????",
        "shared_interaction" : "cut5",
        "name" : "?????????? (cut5) ?????",
        "interaction" : "cut5",
        "SUID" : 1250,
        "BEND_MAP_ID" : 1250,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1249",
        "source" : "89",
        "target" : "78",
        "EdgeBetweenness" : 46.29384504384504,
        "shared_name" : "?????????? (cut4) ?????",
        "shared_interaction" : "cut4",
        "name" : "?????????? (cut4) ?????",
        "interaction" : "cut4",
        "SUID" : 1249,
        "BEND_MAP_ID" : 1249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1248",
        "source" : "89",
        "target" : "296",
        "EdgeBetweenness" : 34.76931956931956,
        "shared_name" : "?????????? (cut3) Hades",
        "shared_interaction" : "cut3",
        "name" : "?????????? (cut3) Hades",
        "interaction" : "cut3",
        "SUID" : 1248,
        "BEND_MAP_ID" : 1248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1247",
        "source" : "89",
        "target" : "71",
        "EdgeBetweenness" : 47.13706848706849,
        "shared_name" : "?????????? (cut1) ????",
        "shared_interaction" : "cut1",
        "name" : "?????????? (cut1) ????",
        "interaction" : "cut1",
        "SUID" : 1247,
        "BEND_MAP_ID" : 1247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "611",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut339) Goofy",
        "shared_interaction" : "cut339",
        "name" : "Sora (cut339) Goofy",
        "interaction" : "cut339",
        "SUID" : 611,
        "BEND_MAP_ID" : 611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "610",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut339) Donald",
        "shared_interaction" : "cut339",
        "name" : "Sora (cut339) Donald",
        "interaction" : "cut339",
        "SUID" : 610,
        "BEND_MAP_ID" : 610,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "609",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut338) Goofy",
        "shared_interaction" : "cut338",
        "name" : "Sora (cut338) Goofy",
        "interaction" : "cut338",
        "SUID" : 609,
        "BEND_MAP_ID" : 609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "608",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut337) Kairi",
        "shared_interaction" : "cut337",
        "name" : "Sora (cut337) Kairi",
        "interaction" : "cut337",
        "SUID" : 608,
        "BEND_MAP_ID" : 608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "607",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut334) Riku",
        "shared_interaction" : "cut334",
        "name" : "Sora (cut334) Riku",
        "interaction" : "cut334",
        "SUID" : 607,
        "BEND_MAP_ID" : 607,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "606",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut334) Goofy",
        "shared_interaction" : "cut334",
        "name" : "Sora (cut334) Goofy",
        "interaction" : "cut334",
        "SUID" : 606,
        "BEND_MAP_ID" : 606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut334) Donald",
        "shared_interaction" : "cut334",
        "name" : "Sora (cut334) Donald",
        "interaction" : "cut334",
        "SUID" : 605,
        "BEND_MAP_ID" : 605,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "604",
        "source" : "84",
        "target" : "603",
        "EdgeBetweenness" : 84.7201465201465,
        "shared_name" : "Sora (cut334) Mickey",
        "shared_interaction" : "cut334",
        "name" : "Sora (cut334) Mickey",
        "interaction" : "cut334",
        "SUID" : 604,
        "BEND_MAP_ID" : 604,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "602",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut333) Riku",
        "shared_interaction" : "cut333",
        "name" : "Sora (cut333) Riku",
        "interaction" : "cut333",
        "SUID" : 602,
        "BEND_MAP_ID" : 602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "601",
        "source" : "84",
        "target" : "598",
        "EdgeBetweenness" : 108.25396825396825,
        "shared_name" : "Sora (cut330) Ansem",
        "shared_interaction" : "cut330",
        "name" : "Sora (cut330) Ansem",
        "interaction" : "cut330",
        "SUID" : 601,
        "BEND_MAP_ID" : 601,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "600",
        "source" : "84",
        "target" : "598",
        "EdgeBetweenness" : 108.25396825396825,
        "shared_name" : "Sora (cut327) Ansem",
        "shared_interaction" : "cut327",
        "name" : "Sora (cut327) Ansem",
        "interaction" : "cut327",
        "SUID" : 600,
        "BEND_MAP_ID" : 600,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "599",
        "source" : "84",
        "target" : "598",
        "EdgeBetweenness" : 108.25396825396825,
        "shared_name" : "Sora (cut326) Ansem",
        "shared_interaction" : "cut326",
        "name" : "Sora (cut326) Ansem",
        "interaction" : "cut326",
        "SUID" : 599,
        "BEND_MAP_ID" : 599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "597",
        "source" : "84",
        "target" : "72",
        "EdgeBetweenness" : 103.99999999999999,
        "shared_name" : "Sora (cut324) Voice",
        "shared_interaction" : "cut324",
        "name" : "Sora (cut324) Voice",
        "interaction" : "cut324",
        "SUID" : 597,
        "BEND_MAP_ID" : 597,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "596",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut324) Donald",
        "shared_interaction" : "cut324",
        "name" : "Sora (cut324) Donald",
        "interaction" : "cut324",
        "SUID" : 596,
        "BEND_MAP_ID" : 596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "595",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut322) Donald",
        "shared_interaction" : "cut322",
        "name" : "Sora (cut322) Donald",
        "interaction" : "cut322",
        "SUID" : 595,
        "BEND_MAP_ID" : 595,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "594",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut322) Goofy",
        "shared_interaction" : "cut322",
        "name" : "Sora (cut322) Goofy",
        "interaction" : "cut322",
        "SUID" : 594,
        "BEND_MAP_ID" : 594,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "593",
        "source" : "84",
        "target" : "94",
        "EdgeBetweenness" : 168.765367965368,
        "shared_name" : "Sora (cut320) Pooh",
        "shared_interaction" : "cut320",
        "name" : "Sora (cut320) Pooh",
        "interaction" : "cut320",
        "SUID" : 593,
        "BEND_MAP_ID" : 593,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "592",
        "source" : "84",
        "target" : "591",
        "EdgeBetweenness" : 148.30952380952385,
        "shared_name" : "Sora (cut317) Eeyore",
        "shared_interaction" : "cut317",
        "name" : "Sora (cut317) Eeyore",
        "interaction" : "cut317",
        "SUID" : 592,
        "BEND_MAP_ID" : 592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "590",
        "source" : "84",
        "target" : "94",
        "EdgeBetweenness" : 168.765367965368,
        "shared_name" : "Sora (cut316) Pooh",
        "shared_interaction" : "cut316",
        "name" : "Sora (cut316) Pooh",
        "interaction" : "cut316",
        "SUID" : 590,
        "BEND_MAP_ID" : 590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "589",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut315) ??????",
        "shared_interaction" : "cut315",
        "name" : "Sora (cut315) ??????",
        "interaction" : "cut315",
        "SUID" : 589,
        "BEND_MAP_ID" : 589,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "588",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut314) ??????",
        "shared_interaction" : "cut314",
        "name" : "Sora (cut314) ??????",
        "interaction" : "cut314",
        "SUID" : 588,
        "BEND_MAP_ID" : 588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "587",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut313) ??????",
        "shared_interaction" : "cut313",
        "name" : "Sora (cut313) ??????",
        "interaction" : "cut313",
        "SUID" : 587,
        "BEND_MAP_ID" : 587,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "586",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut312) Goofy",
        "shared_interaction" : "cut312",
        "name" : "Sora (cut312) Goofy",
        "interaction" : "cut312",
        "SUID" : 586,
        "BEND_MAP_ID" : 586,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "585",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut312) ??????",
        "shared_interaction" : "cut312",
        "name" : "Sora (cut312) ??????",
        "interaction" : "cut312",
        "SUID" : 585,
        "BEND_MAP_ID" : 585,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "584",
        "source" : "84",
        "target" : "179",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Sora (cut311) Aerith",
        "shared_interaction" : "cut311",
        "name" : "Sora (cut311) Aerith",
        "interaction" : "cut311",
        "SUID" : 584,
        "BEND_MAP_ID" : 584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "583",
        "source" : "84",
        "target" : "120",
        "EdgeBetweenness" : 89.43333333333335,
        "shared_name" : "Sora (cut310) Jasmine",
        "shared_interaction" : "cut310",
        "name" : "Sora (cut310) Jasmine",
        "interaction" : "cut310",
        "SUID" : 583,
        "BEND_MAP_ID" : 583,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "582",
        "source" : "84",
        "target" : "581",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Sora (cut310) Snow Whtie",
        "shared_interaction" : "cut310",
        "name" : "Sora (cut310) Snow Whtie",
        "interaction" : "cut310",
        "SUID" : 582,
        "BEND_MAP_ID" : 582,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "580",
        "source" : "84",
        "target" : "265",
        "EdgeBetweenness" : 158.5619047619048,
        "shared_name" : "Sora (cut310) Alice",
        "shared_interaction" : "cut310",
        "name" : "Sora (cut310) Alice",
        "interaction" : "cut310",
        "SUID" : 580,
        "BEND_MAP_ID" : 580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "579",
        "source" : "84",
        "target" : "556",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Sora (cut310) Cinderella",
        "shared_interaction" : "cut310",
        "name" : "Sora (cut310) Cinderella",
        "interaction" : "cut310",
        "SUID" : 579,
        "BEND_MAP_ID" : 579,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "source" : "84",
        "target" : "558",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Sora (cut310) Aurora",
        "shared_interaction" : "cut310",
        "name" : "Sora (cut310) Aurora",
        "interaction" : "cut310",
        "SUID" : 578,
        "BEND_MAP_ID" : 578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "577",
        "source" : "84",
        "target" : "562",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Sora (cut310) Snow White",
        "shared_interaction" : "cut310",
        "name" : "Sora (cut310) Snow White",
        "interaction" : "cut310",
        "SUID" : 577,
        "BEND_MAP_ID" : 577,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "576",
        "source" : "84",
        "target" : "556",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Sora (cut309) Cinderella",
        "shared_interaction" : "cut309",
        "name" : "Sora (cut309) Cinderella",
        "interaction" : "cut309",
        "SUID" : 576,
        "BEND_MAP_ID" : 576,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "575",
        "source" : "84",
        "target" : "558",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Sora (cut309) Aurora",
        "shared_interaction" : "cut309",
        "name" : "Sora (cut309) Aurora",
        "interaction" : "cut309",
        "SUID" : 575,
        "BEND_MAP_ID" : 575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "574",
        "source" : "84",
        "target" : "120",
        "EdgeBetweenness" : 89.43333333333335,
        "shared_name" : "Sora (cut309) Jasmine",
        "shared_interaction" : "cut309",
        "name" : "Sora (cut309) Jasmine",
        "interaction" : "cut309",
        "SUID" : 574,
        "BEND_MAP_ID" : 574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "573",
        "source" : "84",
        "target" : "265",
        "EdgeBetweenness" : 158.5619047619048,
        "shared_name" : "Sora (cut309) Alice",
        "shared_interaction" : "cut309",
        "name" : "Sora (cut309) Alice",
        "interaction" : "cut309",
        "SUID" : 573,
        "BEND_MAP_ID" : 573,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "572",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut308) Donald",
        "shared_interaction" : "cut308",
        "name" : "Sora (cut308) Donald",
        "interaction" : "cut308",
        "SUID" : 572,
        "BEND_MAP_ID" : 572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "571",
        "source" : "84",
        "target" : "177",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Sora (cut308) Yuffie",
        "shared_interaction" : "cut308",
        "name" : "Sora (cut308) Yuffie",
        "interaction" : "cut308",
        "SUID" : 571,
        "BEND_MAP_ID" : 571,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "570",
        "source" : "84",
        "target" : "179",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Sora (cut308) Aerith",
        "shared_interaction" : "cut308",
        "name" : "Sora (cut308) Aerith",
        "interaction" : "cut308",
        "SUID" : 570,
        "BEND_MAP_ID" : 570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut308) Leon",
        "shared_interaction" : "cut308",
        "name" : "Sora (cut308) Leon",
        "interaction" : "cut308",
        "SUID" : 569,
        "BEND_MAP_ID" : 569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "568",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut307) Leon",
        "shared_interaction" : "cut307",
        "name" : "Sora (cut307) Leon",
        "interaction" : "cut307",
        "SUID" : 568,
        "BEND_MAP_ID" : 568,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "567",
        "source" : "84",
        "target" : "179",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Sora (cut307) Aerith",
        "shared_interaction" : "cut307",
        "name" : "Sora (cut307) Aerith",
        "interaction" : "cut307",
        "SUID" : 567,
        "BEND_MAP_ID" : 567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "566",
        "source" : "84",
        "target" : "177",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Sora (cut307) Yuffie",
        "shared_interaction" : "cut307",
        "name" : "Sora (cut307) Yuffie",
        "interaction" : "cut307",
        "SUID" : 566,
        "BEND_MAP_ID" : 566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "565",
        "source" : "84",
        "target" : "556",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Sora (cut306) Cinderella",
        "shared_interaction" : "cut306",
        "name" : "Sora (cut306) Cinderella",
        "interaction" : "cut306",
        "SUID" : 565,
        "BEND_MAP_ID" : 565,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "564",
        "source" : "84",
        "target" : "558",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Sora (cut306) Aurora",
        "shared_interaction" : "cut306",
        "name" : "Sora (cut306) Aurora",
        "interaction" : "cut306",
        "SUID" : 564,
        "BEND_MAP_ID" : 564,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "source" : "84",
        "target" : "562",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Sora (cut306) Snow White",
        "shared_interaction" : "cut306",
        "name" : "Sora (cut306) Snow White",
        "interaction" : "cut306",
        "SUID" : 563,
        "BEND_MAP_ID" : 563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "561",
        "source" : "84",
        "target" : "265",
        "EdgeBetweenness" : 158.5619047619048,
        "shared_name" : "Sora (cut306) Alice",
        "shared_interaction" : "cut306",
        "name" : "Sora (cut306) Alice",
        "interaction" : "cut306",
        "SUID" : 561,
        "BEND_MAP_ID" : 561,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "560",
        "source" : "84",
        "target" : "120",
        "EdgeBetweenness" : 89.43333333333335,
        "shared_name" : "Sora (cut306) Jasmine",
        "shared_interaction" : "cut306",
        "name" : "Sora (cut306) Jasmine",
        "interaction" : "cut306",
        "SUID" : 560,
        "BEND_MAP_ID" : 560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "559",
        "source" : "84",
        "target" : "558",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Sora (cut305) Aurora",
        "shared_interaction" : "cut305",
        "name" : "Sora (cut305) Aurora",
        "interaction" : "cut305",
        "SUID" : 559,
        "BEND_MAP_ID" : 559,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "557",
        "source" : "84",
        "target" : "556",
        "EdgeBetweenness" : 138.60000000000002,
        "shared_name" : "Sora (cut305) Cinderella",
        "shared_interaction" : "cut305",
        "name" : "Sora (cut305) Cinderella",
        "interaction" : "cut305",
        "SUID" : 557,
        "BEND_MAP_ID" : 557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "555",
        "source" : "84",
        "target" : "554",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Sora (cut304) Belle",
        "shared_interaction" : "cut304",
        "name" : "Sora (cut304) Belle",
        "interaction" : "cut304",
        "SUID" : 555,
        "BEND_MAP_ID" : 555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "553",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut303) Donald",
        "shared_interaction" : "cut303",
        "name" : "Sora (cut303) Donald",
        "interaction" : "cut303",
        "SUID" : 553,
        "BEND_MAP_ID" : 553,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "552",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut303) Goofy",
        "shared_interaction" : "cut303",
        "name" : "Sora (cut303) Goofy",
        "interaction" : "cut303",
        "SUID" : 552,
        "BEND_MAP_ID" : 552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "551",
        "source" : "84",
        "target" : "534",
        "EdgeBetweenness" : 84.7201465201465,
        "shared_name" : "Sora (cut303) Beast",
        "shared_interaction" : "cut303",
        "name" : "Sora (cut303) Beast",
        "interaction" : "cut303",
        "SUID" : 551,
        "BEND_MAP_ID" : 551,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "550",
        "source" : "84",
        "target" : "466",
        "EdgeBetweenness" : 191.06536796536807,
        "shared_name" : "Sora (cut302) Owl",
        "shared_interaction" : "cut302",
        "name" : "Sora (cut302) Owl",
        "interaction" : "cut302",
        "SUID" : 550,
        "BEND_MAP_ID" : 550,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "549",
        "source" : "84",
        "target" : "548",
        "EdgeBetweenness" : 154.66666666666669,
        "shared_name" : "Sora (cut302) Roo",
        "shared_interaction" : "cut302",
        "name" : "Sora (cut302) Roo",
        "interaction" : "cut302",
        "SUID" : 549,
        "BEND_MAP_ID" : 549,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "547",
        "source" : "84",
        "target" : "441",
        "EdgeBetweenness" : 147.30952380952385,
        "shared_name" : "Sora (cut302) Tigger",
        "shared_interaction" : "cut302",
        "name" : "Sora (cut302) Tigger",
        "interaction" : "cut302",
        "SUID" : 547,
        "BEND_MAP_ID" : 547,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "546",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut301) Kairi",
        "shared_interaction" : "cut301",
        "name" : "Sora (cut301) Kairi",
        "interaction" : "cut301",
        "SUID" : 546,
        "BEND_MAP_ID" : 546,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut300) Kairi",
        "shared_interaction" : "cut300",
        "name" : "Sora (cut300) Kairi",
        "interaction" : "cut300",
        "SUID" : 545,
        "BEND_MAP_ID" : 545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "544",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut299) Kairi",
        "shared_interaction" : "cut299",
        "name" : "Sora (cut299) Kairi",
        "interaction" : "cut299",
        "SUID" : 544,
        "BEND_MAP_ID" : 544,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "543",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut298) Kairi",
        "shared_interaction" : "cut298",
        "name" : "Sora (cut298) Kairi",
        "interaction" : "cut298",
        "SUID" : 543,
        "BEND_MAP_ID" : 543,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "542",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut297) Kairi",
        "shared_interaction" : "cut297",
        "name" : "Sora (cut297) Kairi",
        "interaction" : "cut297",
        "SUID" : 542,
        "BEND_MAP_ID" : 542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "541",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut296) Kairi",
        "shared_interaction" : "cut296",
        "name" : "Sora (cut296) Kairi",
        "interaction" : "cut296",
        "SUID" : 541,
        "BEND_MAP_ID" : 541,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "540",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut295) Kairi",
        "shared_interaction" : "cut295",
        "name" : "Sora (cut295) Kairi",
        "interaction" : "cut295",
        "SUID" : 540,
        "BEND_MAP_ID" : 540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "539",
        "source" : "84",
        "target" : "220",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Sora (cut294) Cid",
        "shared_interaction" : "cut294",
        "name" : "Sora (cut294) Cid",
        "interaction" : "cut294",
        "SUID" : 539,
        "BEND_MAP_ID" : 539,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "538",
        "source" : "84",
        "target" : "179",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Sora (cut293) Aerith",
        "shared_interaction" : "cut293",
        "name" : "Sora (cut293) Aerith",
        "interaction" : "cut293",
        "SUID" : 538,
        "BEND_MAP_ID" : 538,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "537",
        "source" : "84",
        "target" : "179",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Sora (cut292) Aerith",
        "shared_interaction" : "cut292",
        "name" : "Sora (cut292) Aerith",
        "interaction" : "cut292",
        "SUID" : 537,
        "BEND_MAP_ID" : 537,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "536",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut292) Leon",
        "shared_interaction" : "cut292",
        "name" : "Sora (cut292) Leon",
        "interaction" : "cut292",
        "SUID" : 536,
        "BEND_MAP_ID" : 536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "535",
        "source" : "84",
        "target" : "534",
        "EdgeBetweenness" : 84.7201465201465,
        "shared_name" : "Sora (cut291) Beast",
        "shared_interaction" : "cut291",
        "name" : "Sora (cut291) Beast",
        "interaction" : "cut291",
        "SUID" : 535,
        "BEND_MAP_ID" : 535,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut288) Goofy",
        "shared_interaction" : "cut288",
        "name" : "Sora (cut288) Goofy",
        "interaction" : "cut288",
        "SUID" : 533,
        "BEND_MAP_ID" : 533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "532",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut286) Goofy",
        "shared_interaction" : "cut286",
        "name" : "Sora (cut286) Goofy",
        "interaction" : "cut286",
        "SUID" : 532,
        "BEND_MAP_ID" : 532,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "531",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut283) Riku",
        "shared_interaction" : "cut283",
        "name" : "Sora (cut283) Riku",
        "interaction" : "cut283",
        "SUID" : 531,
        "BEND_MAP_ID" : 531,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "530",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut282) Riku",
        "shared_interaction" : "cut282",
        "name" : "Sora (cut282) Riku",
        "interaction" : "cut282",
        "SUID" : 530,
        "BEND_MAP_ID" : 530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "529",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut281) Riku",
        "shared_interaction" : "cut281",
        "name" : "Sora (cut281) Riku",
        "interaction" : "cut281",
        "SUID" : 529,
        "BEND_MAP_ID" : 529,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "528",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut281) Donald",
        "shared_interaction" : "cut281",
        "name" : "Sora (cut281) Donald",
        "interaction" : "cut281",
        "SUID" : 528,
        "BEND_MAP_ID" : 528,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "527",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut280) Riku",
        "shared_interaction" : "cut280",
        "name" : "Sora (cut280) Riku",
        "interaction" : "cut280",
        "SUID" : 527,
        "BEND_MAP_ID" : 527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "526",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut279) Riku",
        "shared_interaction" : "cut279",
        "name" : "Sora (cut279) Riku",
        "interaction" : "cut279",
        "SUID" : 526,
        "BEND_MAP_ID" : 526,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "525",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut278) Riku",
        "shared_interaction" : "cut278",
        "name" : "Sora (cut278) Riku",
        "interaction" : "cut278",
        "SUID" : 525,
        "BEND_MAP_ID" : 525,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "524",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut276) Riku",
        "shared_interaction" : "cut276",
        "name" : "Sora (cut276) Riku",
        "interaction" : "cut276",
        "SUID" : 524,
        "BEND_MAP_ID" : 524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "523",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut272) Riku",
        "shared_interaction" : "cut272",
        "name" : "Sora (cut272) Riku",
        "interaction" : "cut272",
        "SUID" : 523,
        "BEND_MAP_ID" : 523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "522",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut270) Riku",
        "shared_interaction" : "cut270",
        "name" : "Sora (cut270) Riku",
        "interaction" : "cut270",
        "SUID" : 522,
        "BEND_MAP_ID" : 522,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "521",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut270) Goofy",
        "shared_interaction" : "cut270",
        "name" : "Sora (cut270) Goofy",
        "interaction" : "cut270",
        "SUID" : 521,
        "BEND_MAP_ID" : 521,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "520",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut270) Donald",
        "shared_interaction" : "cut270",
        "name" : "Sora (cut270) Donald",
        "interaction" : "cut270",
        "SUID" : 520,
        "BEND_MAP_ID" : 520,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "519",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut269) Riku",
        "shared_interaction" : "cut269",
        "name" : "Sora (cut269) Riku",
        "interaction" : "cut269",
        "SUID" : 519,
        "BEND_MAP_ID" : 519,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "518",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut267) Riku",
        "shared_interaction" : "cut267",
        "name" : "Sora (cut267) Riku",
        "interaction" : "cut267",
        "SUID" : 518,
        "BEND_MAP_ID" : 518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "517",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut264) Riku",
        "shared_interaction" : "cut264",
        "name" : "Sora (cut264) Riku",
        "interaction" : "cut264",
        "SUID" : 517,
        "BEND_MAP_ID" : 517,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "516",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut263) Riku",
        "shared_interaction" : "cut263",
        "name" : "Sora (cut263) Riku",
        "interaction" : "cut263",
        "SUID" : 516,
        "BEND_MAP_ID" : 516,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut260) Donald",
        "shared_interaction" : "cut260",
        "name" : "Sora (cut260) Donald",
        "interaction" : "cut260",
        "SUID" : 515,
        "BEND_MAP_ID" : 515,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "514",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut259) Goofy",
        "shared_interaction" : "cut259",
        "name" : "Sora (cut259) Goofy",
        "interaction" : "cut259",
        "SUID" : 514,
        "BEND_MAP_ID" : 514,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "513",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut258) Goofy",
        "shared_interaction" : "cut258",
        "name" : "Sora (cut258) Goofy",
        "interaction" : "cut258",
        "SUID" : 513,
        "BEND_MAP_ID" : 513,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "512",
        "source" : "84",
        "target" : "443",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut257) Hercules",
        "shared_interaction" : "cut257",
        "name" : "Sora (cut257) Hercules",
        "interaction" : "cut257",
        "SUID" : 512,
        "BEND_MAP_ID" : 512,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "511",
        "source" : "84",
        "target" : "292",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut257) Philoctetes",
        "shared_interaction" : "cut257",
        "name" : "Sora (cut257) Philoctetes",
        "interaction" : "cut257",
        "SUID" : 511,
        "BEND_MAP_ID" : 511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "510",
        "source" : "84",
        "target" : "292",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut256) Philoctetes",
        "shared_interaction" : "cut256",
        "name" : "Sora (cut256) Philoctetes",
        "interaction" : "cut256",
        "SUID" : 510,
        "BEND_MAP_ID" : 510,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "509",
        "source" : "84",
        "target" : "443",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut256) Hercules",
        "shared_interaction" : "cut256",
        "name" : "Sora (cut256) Hercules",
        "interaction" : "cut256",
        "SUID" : 509,
        "BEND_MAP_ID" : 509,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "508",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut255) Goofy",
        "shared_interaction" : "cut255",
        "name" : "Sora (cut255) Goofy",
        "interaction" : "cut255",
        "SUID" : 508,
        "BEND_MAP_ID" : 508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "507",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut255) Donald",
        "shared_interaction" : "cut255",
        "name" : "Sora (cut255) Donald",
        "interaction" : "cut255",
        "SUID" : 507,
        "BEND_MAP_ID" : 507,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "506",
        "source" : "84",
        "target" : "443",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut255) Hercules",
        "shared_interaction" : "cut255",
        "name" : "Sora (cut255) Hercules",
        "interaction" : "cut255",
        "SUID" : 506,
        "BEND_MAP_ID" : 506,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "505",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut254) Goofy",
        "shared_interaction" : "cut254",
        "name" : "Sora (cut254) Goofy",
        "interaction" : "cut254",
        "SUID" : 505,
        "BEND_MAP_ID" : 505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "504",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut251) Goofy",
        "shared_interaction" : "cut251",
        "name" : "Sora (cut251) Goofy",
        "interaction" : "cut251",
        "SUID" : 504,
        "BEND_MAP_ID" : 504,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut251) Donald",
        "shared_interaction" : "cut251",
        "name" : "Sora (cut251) Donald",
        "interaction" : "cut251",
        "SUID" : 503,
        "BEND_MAP_ID" : 503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "502",
        "source" : "84",
        "target" : "387",
        "EdgeBetweenness" : 103.76666666666667,
        "shared_name" : "Sora (cut250) Pinocchio",
        "shared_interaction" : "cut250",
        "name" : "Sora (cut250) Pinocchio",
        "interaction" : "cut250",
        "SUID" : 502,
        "BEND_MAP_ID" : 502,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "501",
        "source" : "84",
        "target" : "432",
        "EdgeBetweenness" : 135.5761904761905,
        "shared_name" : "Sora (cut250) Geppetto",
        "shared_interaction" : "cut250",
        "name" : "Sora (cut250) Geppetto",
        "interaction" : "cut250",
        "SUID" : 501,
        "BEND_MAP_ID" : 501,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "500",
        "source" : "84",
        "target" : "432",
        "EdgeBetweenness" : 135.5761904761905,
        "shared_name" : "Sora (cut249) Geppetto",
        "shared_interaction" : "cut249",
        "name" : "Sora (cut249) Geppetto",
        "interaction" : "cut249",
        "SUID" : 500,
        "BEND_MAP_ID" : 500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "499",
        "source" : "84",
        "target" : "387",
        "EdgeBetweenness" : 103.76666666666667,
        "shared_name" : "Sora (cut249) Pinocchio",
        "shared_interaction" : "cut249",
        "name" : "Sora (cut249) Pinocchio",
        "interaction" : "cut249",
        "SUID" : 499,
        "BEND_MAP_ID" : 499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "498",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut248) Donald",
        "shared_interaction" : "cut248",
        "name" : "Sora (cut248) Donald",
        "interaction" : "cut248",
        "SUID" : 498,
        "BEND_MAP_ID" : 498,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut245) Riku",
        "shared_interaction" : "cut245",
        "name" : "Sora (cut245) Riku",
        "interaction" : "cut245",
        "SUID" : 497,
        "BEND_MAP_ID" : 497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "496",
        "source" : "84",
        "target" : "488",
        "EdgeBetweenness" : 106.25396825396825,
        "shared_name" : "Sora (cut244) Peter Pan",
        "shared_interaction" : "cut244",
        "name" : "Sora (cut244) Peter Pan",
        "interaction" : "cut244",
        "SUID" : 496,
        "BEND_MAP_ID" : 496,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "495",
        "source" : "84",
        "target" : "488",
        "EdgeBetweenness" : 106.25396825396825,
        "shared_name" : "Sora (cut243) Peter Pan",
        "shared_interaction" : "cut243",
        "name" : "Sora (cut243) Peter Pan",
        "interaction" : "cut243",
        "SUID" : 495,
        "BEND_MAP_ID" : 495,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "494",
        "source" : "84",
        "target" : "488",
        "EdgeBetweenness" : 106.25396825396825,
        "shared_name" : "Sora (cut241) Peter Pan",
        "shared_interaction" : "cut241",
        "name" : "Sora (cut241) Peter Pan",
        "interaction" : "cut241",
        "SUID" : 494,
        "BEND_MAP_ID" : 494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "493",
        "source" : "84",
        "target" : "490",
        "EdgeBetweenness" : 158.66666666666669,
        "shared_name" : "Sora (cut238) Wendy",
        "shared_interaction" : "cut238",
        "name" : "Sora (cut238) Wendy",
        "interaction" : "cut238",
        "SUID" : 493,
        "BEND_MAP_ID" : 493,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "492",
        "source" : "84",
        "target" : "490",
        "EdgeBetweenness" : 158.66666666666669,
        "shared_name" : "Sora (cut237) Wendy",
        "shared_interaction" : "cut237",
        "name" : "Sora (cut237) Wendy",
        "interaction" : "cut237",
        "SUID" : 492,
        "BEND_MAP_ID" : 492,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "491",
        "source" : "84",
        "target" : "490",
        "EdgeBetweenness" : 158.66666666666669,
        "shared_name" : "Sora (cut236) Wendy",
        "shared_interaction" : "cut236",
        "name" : "Sora (cut236) Wendy",
        "interaction" : "cut236",
        "SUID" : 491,
        "BEND_MAP_ID" : 491,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "489",
        "source" : "84",
        "target" : "488",
        "EdgeBetweenness" : 106.25396825396825,
        "shared_name" : "Sora (cut236) Peter Pan",
        "shared_interaction" : "cut236",
        "name" : "Sora (cut236) Peter Pan",
        "interaction" : "cut236",
        "SUID" : 489,
        "BEND_MAP_ID" : 489,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "487",
        "source" : "84",
        "target" : "78",
        "EdgeBetweenness" : 103.42123987123989,
        "shared_name" : "Sora (cut234) ?????",
        "shared_interaction" : "cut234",
        "name" : "Sora (cut234) ?????",
        "interaction" : "cut234",
        "SUID" : 487,
        "BEND_MAP_ID" : 487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "486",
        "source" : "84",
        "target" : "78",
        "EdgeBetweenness" : 103.42123987123989,
        "shared_name" : "Sora (cut233) ?????",
        "shared_interaction" : "cut233",
        "name" : "Sora (cut233) ?????",
        "interaction" : "cut233",
        "SUID" : 486,
        "BEND_MAP_ID" : 486,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut231) Donald",
        "shared_interaction" : "cut231",
        "name" : "Sora (cut231) Donald",
        "interaction" : "cut231",
        "SUID" : 485,
        "BEND_MAP_ID" : 485,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "484",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut231) Goofy",
        "shared_interaction" : "cut231",
        "name" : "Sora (cut231) Goofy",
        "interaction" : "cut231",
        "SUID" : 484,
        "BEND_MAP_ID" : 484,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut230) Riku",
        "shared_interaction" : "cut230",
        "name" : "Sora (cut230) Riku",
        "interaction" : "cut230",
        "SUID" : 483,
        "BEND_MAP_ID" : 483,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "482",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut229) Riku",
        "shared_interaction" : "cut229",
        "name" : "Sora (cut229) Riku",
        "interaction" : "cut229",
        "SUID" : 482,
        "BEND_MAP_ID" : 482,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "481",
        "source" : "84",
        "target" : "71",
        "EdgeBetweenness" : 216.28249528249523,
        "shared_name" : "Sora (cut228) ????",
        "shared_interaction" : "cut228",
        "name" : "Sora (cut228) ????",
        "interaction" : "cut228",
        "SUID" : 481,
        "BEND_MAP_ID" : 481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "480",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut228) Riku",
        "shared_interaction" : "cut228",
        "name" : "Sora (cut228) Riku",
        "interaction" : "cut228",
        "SUID" : 480,
        "BEND_MAP_ID" : 480,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut227) Riku",
        "shared_interaction" : "cut227",
        "name" : "Sora (cut227) Riku",
        "interaction" : "cut227",
        "SUID" : 479,
        "BEND_MAP_ID" : 479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "478",
        "source" : "84",
        "target" : "474",
        "EdgeBetweenness" : 610.6666666666667,
        "shared_name" : "Sora (cut225) Jack",
        "shared_interaction" : "cut225",
        "name" : "Sora (cut225) Jack",
        "interaction" : "cut225",
        "SUID" : 478,
        "BEND_MAP_ID" : 478,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "477",
        "source" : "84",
        "target" : "474",
        "EdgeBetweenness" : 610.6666666666667,
        "shared_name" : "Sora (cut222) Jack",
        "shared_interaction" : "cut222",
        "name" : "Sora (cut222) Jack",
        "interaction" : "cut222",
        "SUID" : 477,
        "BEND_MAP_ID" : 477,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "476",
        "source" : "84",
        "target" : "471",
        "EdgeBetweenness" : 110.92063492063492,
        "shared_name" : "Sora (cut222) Finkelstein",
        "shared_interaction" : "cut222",
        "name" : "Sora (cut222) Finkelstein",
        "interaction" : "cut222",
        "SUID" : 476,
        "BEND_MAP_ID" : 476,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "475",
        "source" : "84",
        "target" : "474",
        "EdgeBetweenness" : 610.6666666666667,
        "shared_name" : "Sora (cut221) Jack",
        "shared_interaction" : "cut221",
        "name" : "Sora (cut221) Jack",
        "interaction" : "cut221",
        "SUID" : 475,
        "BEND_MAP_ID" : 475,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut219) Donald",
        "shared_interaction" : "cut219",
        "name" : "Sora (cut219) Donald",
        "interaction" : "cut219",
        "SUID" : 473,
        "BEND_MAP_ID" : 473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "472",
        "source" : "84",
        "target" : "471",
        "EdgeBetweenness" : 110.92063492063492,
        "shared_name" : "Sora (cut219) Finkelstein",
        "shared_interaction" : "cut219",
        "name" : "Sora (cut219) Finkelstein",
        "interaction" : "cut219",
        "SUID" : 472,
        "BEND_MAP_ID" : 472,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "470",
        "source" : "84",
        "target" : "94",
        "EdgeBetweenness" : 168.765367965368,
        "shared_name" : "Sora (cut218) Pooh",
        "shared_interaction" : "cut218",
        "name" : "Sora (cut218) Pooh",
        "interaction" : "cut218",
        "SUID" : 470,
        "BEND_MAP_ID" : 470,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "469",
        "source" : "84",
        "target" : "466",
        "EdgeBetweenness" : 191.06536796536807,
        "shared_name" : "Sora (cut217) Owl",
        "shared_interaction" : "cut217",
        "name" : "Sora (cut217) Owl",
        "interaction" : "cut217",
        "SUID" : 469,
        "BEND_MAP_ID" : 469,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "468",
        "source" : "84",
        "target" : "466",
        "EdgeBetweenness" : 191.06536796536807,
        "shared_name" : "Sora (cut215) Owl",
        "shared_interaction" : "cut215",
        "name" : "Sora (cut215) Owl",
        "interaction" : "cut215",
        "SUID" : 468,
        "BEND_MAP_ID" : 468,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "source" : "84",
        "target" : "466",
        "EdgeBetweenness" : 191.06536796536807,
        "shared_name" : "Sora (cut214) Owl",
        "shared_interaction" : "cut214",
        "name" : "Sora (cut214) Owl",
        "interaction" : "cut214",
        "SUID" : 467,
        "BEND_MAP_ID" : 467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "465",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut213) Goofy",
        "shared_interaction" : "cut213",
        "name" : "Sora (cut213) Goofy",
        "interaction" : "cut213",
        "SUID" : 465,
        "BEND_MAP_ID" : 465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "464",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut213) Donald",
        "shared_interaction" : "cut213",
        "name" : "Sora (cut213) Donald",
        "interaction" : "cut213",
        "SUID" : 464,
        "BEND_MAP_ID" : 464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "463",
        "source" : "84",
        "target" : "447",
        "EdgeBetweenness" : 636.4939393939393,
        "shared_name" : "Sora (cut212) Ariel",
        "shared_interaction" : "cut212",
        "name" : "Sora (cut212) Ariel",
        "interaction" : "cut212",
        "SUID" : 463,
        "BEND_MAP_ID" : 463,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "462",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut211) Goofy",
        "shared_interaction" : "cut211",
        "name" : "Sora (cut211) Goofy",
        "interaction" : "cut211",
        "SUID" : 462,
        "BEND_MAP_ID" : 462,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "461",
        "source" : "84",
        "target" : "450",
        "EdgeBetweenness" : 99.0,
        "shared_name" : "Sora (cut211) Triton",
        "shared_interaction" : "cut211",
        "name" : "Sora (cut211) Triton",
        "interaction" : "cut211",
        "SUID" : 461,
        "BEND_MAP_ID" : 461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "460",
        "source" : "84",
        "target" : "447",
        "EdgeBetweenness" : 636.4939393939393,
        "shared_name" : "Sora (cut211) Ariel",
        "shared_interaction" : "cut211",
        "name" : "Sora (cut211) Ariel",
        "interaction" : "cut211",
        "SUID" : 460,
        "BEND_MAP_ID" : 460,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "459",
        "source" : "84",
        "target" : "136",
        "EdgeBetweenness" : 121.80346320346314,
        "shared_name" : "Sora (cut210) Sebastian",
        "shared_interaction" : "cut210",
        "name" : "Sora (cut210) Sebastian",
        "interaction" : "cut210",
        "SUID" : 459,
        "BEND_MAP_ID" : 459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "458",
        "source" : "84",
        "target" : "450",
        "EdgeBetweenness" : 99.0,
        "shared_name" : "Sora (cut209) Triton",
        "shared_interaction" : "cut209",
        "name" : "Sora (cut209) Triton",
        "interaction" : "cut209",
        "SUID" : 458,
        "BEND_MAP_ID" : 458,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "457",
        "source" : "84",
        "target" : "447",
        "EdgeBetweenness" : 636.4939393939393,
        "shared_name" : "Sora (cut209) Ariel",
        "shared_interaction" : "cut209",
        "name" : "Sora (cut209) Ariel",
        "interaction" : "cut209",
        "SUID" : 457,
        "BEND_MAP_ID" : 457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "456",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut208) Goofy",
        "shared_interaction" : "cut208",
        "name" : "Sora (cut208) Goofy",
        "interaction" : "cut208",
        "SUID" : 456,
        "BEND_MAP_ID" : 456,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "source" : "84",
        "target" : "450",
        "EdgeBetweenness" : 99.0,
        "shared_name" : "Sora (cut208) Triton",
        "shared_interaction" : "cut208",
        "name" : "Sora (cut208) Triton",
        "interaction" : "cut208",
        "SUID" : 455,
        "BEND_MAP_ID" : 455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "454",
        "source" : "84",
        "target" : "447",
        "EdgeBetweenness" : 636.4939393939393,
        "shared_name" : "Sora (cut207) Ariel",
        "shared_interaction" : "cut207",
        "name" : "Sora (cut207) Ariel",
        "interaction" : "cut207",
        "SUID" : 454,
        "BEND_MAP_ID" : 454,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut206) Goofy",
        "shared_interaction" : "cut206",
        "name" : "Sora (cut206) Goofy",
        "interaction" : "cut206",
        "SUID" : 453,
        "BEND_MAP_ID" : 453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "452",
        "source" : "84",
        "target" : "447",
        "EdgeBetweenness" : 636.4939393939393,
        "shared_name" : "Sora (cut206) Ariel",
        "shared_interaction" : "cut206",
        "name" : "Sora (cut206) Ariel",
        "interaction" : "cut206",
        "SUID" : 452,
        "BEND_MAP_ID" : 452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "451",
        "source" : "84",
        "target" : "450",
        "EdgeBetweenness" : 99.0,
        "shared_name" : "Sora (cut206) Triton",
        "shared_interaction" : "cut206",
        "name" : "Sora (cut206) Triton",
        "interaction" : "cut206",
        "SUID" : 451,
        "BEND_MAP_ID" : 451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "449",
        "source" : "84",
        "target" : "136",
        "EdgeBetweenness" : 121.80346320346314,
        "shared_name" : "Sora (cut206) Sebastian",
        "shared_interaction" : "cut206",
        "name" : "Sora (cut206) Sebastian",
        "interaction" : "cut206",
        "SUID" : 449,
        "BEND_MAP_ID" : 449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "448",
        "source" : "84",
        "target" : "447",
        "EdgeBetweenness" : 636.4939393939393,
        "shared_name" : "Sora (cut205) Ariel",
        "shared_interaction" : "cut205",
        "name" : "Sora (cut205) Ariel",
        "interaction" : "cut205",
        "SUID" : 448,
        "BEND_MAP_ID" : 448,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "446",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut203) Donald",
        "shared_interaction" : "cut203",
        "name" : "Sora (cut203) Donald",
        "interaction" : "cut203",
        "SUID" : 446,
        "BEND_MAP_ID" : 446,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "445",
        "source" : "84",
        "target" : "292",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut202) Philoctetes",
        "shared_interaction" : "cut202",
        "name" : "Sora (cut202) Philoctetes",
        "interaction" : "cut202",
        "SUID" : 445,
        "BEND_MAP_ID" : 445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "444",
        "source" : "84",
        "target" : "443",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut202) Hercules",
        "shared_interaction" : "cut202",
        "name" : "Sora (cut202) Hercules",
        "interaction" : "cut202",
        "SUID" : 444,
        "BEND_MAP_ID" : 444,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "442",
        "source" : "84",
        "target" : "441",
        "EdgeBetweenness" : 147.30952380952385,
        "shared_name" : "Sora (cut201) Tigger",
        "shared_interaction" : "cut201",
        "name" : "Sora (cut201) Tigger",
        "interaction" : "cut201",
        "SUID" : 442,
        "BEND_MAP_ID" : 442,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "440",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut200) Donald",
        "shared_interaction" : "cut200",
        "name" : "Sora (cut200) Donald",
        "interaction" : "cut200",
        "SUID" : 440,
        "BEND_MAP_ID" : 440,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "439",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut200) Goofy",
        "shared_interaction" : "cut200",
        "name" : "Sora (cut200) Goofy",
        "interaction" : "cut200",
        "SUID" : 439,
        "BEND_MAP_ID" : 439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "438",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut199) Donald",
        "shared_interaction" : "cut199",
        "name" : "Sora (cut199) Donald",
        "interaction" : "cut199",
        "SUID" : 438,
        "BEND_MAP_ID" : 438,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "437",
        "source" : "84",
        "target" : "387",
        "EdgeBetweenness" : 103.76666666666667,
        "shared_name" : "Sora (cut198) Pinocchio",
        "shared_interaction" : "cut198",
        "name" : "Sora (cut198) Pinocchio",
        "interaction" : "cut198",
        "SUID" : 437,
        "BEND_MAP_ID" : 437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "436",
        "source" : "84",
        "target" : "253",
        "EdgeBetweenness" : 82.72014652014653,
        "shared_name" : "Sora (cut198) Jiminy",
        "shared_interaction" : "cut198",
        "name" : "Sora (cut198) Jiminy",
        "interaction" : "cut198",
        "SUID" : 436,
        "BEND_MAP_ID" : 436,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut198) Riku",
        "shared_interaction" : "cut198",
        "name" : "Sora (cut198) Riku",
        "interaction" : "cut198",
        "SUID" : 435,
        "BEND_MAP_ID" : 435,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "434",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut197) Riku",
        "shared_interaction" : "cut197",
        "name" : "Sora (cut197) Riku",
        "interaction" : "cut197",
        "SUID" : 434,
        "BEND_MAP_ID" : 434,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "433",
        "source" : "84",
        "target" : "432",
        "EdgeBetweenness" : 135.5761904761905,
        "shared_name" : "Sora (cut195) Geppetto",
        "shared_interaction" : "cut195",
        "name" : "Sora (cut195) Geppetto",
        "interaction" : "cut195",
        "SUID" : 433,
        "BEND_MAP_ID" : 433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut195) Riku",
        "shared_interaction" : "cut195",
        "name" : "Sora (cut195) Riku",
        "interaction" : "cut195",
        "SUID" : 431,
        "BEND_MAP_ID" : 431,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "430",
        "source" : "84",
        "target" : "387",
        "EdgeBetweenness" : 103.76666666666667,
        "shared_name" : "Sora (cut194) Pinocchio",
        "shared_interaction" : "cut194",
        "name" : "Sora (cut194) Pinocchio",
        "interaction" : "cut194",
        "SUID" : 430,
        "BEND_MAP_ID" : 430,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "429",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut193) Riku",
        "shared_interaction" : "cut193",
        "name" : "Sora (cut193) Riku",
        "interaction" : "cut193",
        "SUID" : 429,
        "BEND_MAP_ID" : 429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "428",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut192) Riku",
        "shared_interaction" : "cut192",
        "name" : "Sora (cut192) Riku",
        "interaction" : "cut192",
        "SUID" : 428,
        "BEND_MAP_ID" : 428,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "427",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut191) Goofy",
        "shared_interaction" : "cut191",
        "name" : "Sora (cut191) Goofy",
        "interaction" : "cut191",
        "SUID" : 427,
        "BEND_MAP_ID" : 427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "426",
        "source" : "84",
        "target" : "424",
        "EdgeBetweenness" : 153.66666666666669,
        "shared_name" : "Sora (cut190) ????????",
        "shared_interaction" : "cut190",
        "name" : "Sora (cut190) ????????",
        "interaction" : "cut190",
        "SUID" : 426,
        "BEND_MAP_ID" : 426,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "source" : "84",
        "target" : "424",
        "EdgeBetweenness" : 153.66666666666669,
        "shared_name" : "Sora (cut188) ????????",
        "shared_interaction" : "cut188",
        "name" : "Sora (cut188) ????????",
        "interaction" : "cut188",
        "SUID" : 425,
        "BEND_MAP_ID" : 425,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "423",
        "source" : "84",
        "target" : "387",
        "EdgeBetweenness" : 103.76666666666667,
        "shared_name" : "Sora (cut188) Pinocchio",
        "shared_interaction" : "cut188",
        "name" : "Sora (cut188) Pinocchio",
        "interaction" : "cut188",
        "SUID" : 423,
        "BEND_MAP_ID" : 423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "422",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut187) Goofy",
        "shared_interaction" : "cut187",
        "name" : "Sora (cut187) Goofy",
        "interaction" : "cut187",
        "SUID" : 422,
        "BEND_MAP_ID" : 422,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "421",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut186) Goofy",
        "shared_interaction" : "cut186",
        "name" : "Sora (cut186) Goofy",
        "interaction" : "cut186",
        "SUID" : 421,
        "BEND_MAP_ID" : 421,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "420",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut184) Riku",
        "shared_interaction" : "cut184",
        "name" : "Sora (cut184) Riku",
        "interaction" : "cut184",
        "SUID" : 420,
        "BEND_MAP_ID" : 420,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut183) Riku",
        "shared_interaction" : "cut183",
        "name" : "Sora (cut183) Riku",
        "interaction" : "cut183",
        "SUID" : 419,
        "BEND_MAP_ID" : 419,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "418",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut182) Riku",
        "shared_interaction" : "cut182",
        "name" : "Sora (cut182) Riku",
        "interaction" : "cut182",
        "SUID" : 418,
        "BEND_MAP_ID" : 418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut181) Riku",
        "shared_interaction" : "cut181",
        "name" : "Sora (cut181) Riku",
        "interaction" : "cut181",
        "SUID" : 417,
        "BEND_MAP_ID" : 417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "416",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut180) Riku",
        "shared_interaction" : "cut180",
        "name" : "Sora (cut180) Riku",
        "interaction" : "cut180",
        "SUID" : 416,
        "BEND_MAP_ID" : 416,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut178) Donald",
        "shared_interaction" : "cut178",
        "name" : "Sora (cut178) Donald",
        "interaction" : "cut178",
        "SUID" : 415,
        "BEND_MAP_ID" : 415,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "414",
        "source" : "84",
        "target" : "94",
        "EdgeBetweenness" : 168.765367965368,
        "shared_name" : "Sora (cut177) Pooh",
        "shared_interaction" : "cut177",
        "name" : "Sora (cut177) Pooh",
        "interaction" : "cut177",
        "SUID" : 414,
        "BEND_MAP_ID" : 414,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "source" : "84",
        "target" : "412",
        "EdgeBetweenness" : 182.73203463203487,
        "shared_name" : "Sora (cut176) Piglet",
        "shared_interaction" : "cut176",
        "name" : "Sora (cut176) Piglet",
        "interaction" : "cut176",
        "SUID" : 413,
        "BEND_MAP_ID" : 413,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "411",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut175) Goofy",
        "shared_interaction" : "cut175",
        "name" : "Sora (cut175) Goofy",
        "interaction" : "cut175",
        "SUID" : 411,
        "BEND_MAP_ID" : 411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "source" : "84",
        "target" : "395",
        "EdgeBetweenness" : 118.15173160173158,
        "shared_name" : "Sora (cut174) Aladdin",
        "shared_interaction" : "cut174",
        "name" : "Sora (cut174) Aladdin",
        "interaction" : "cut174",
        "SUID" : 410,
        "BEND_MAP_ID" : 410,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "409",
        "source" : "84",
        "target" : "400",
        "EdgeBetweenness" : 87.56666666666663,
        "shared_name" : "Sora (cut174) Genie",
        "shared_interaction" : "cut174",
        "name" : "Sora (cut174) Genie",
        "interaction" : "cut174",
        "SUID" : 409,
        "BEND_MAP_ID" : 409,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "408",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut174) Donald",
        "shared_interaction" : "cut174",
        "name" : "Sora (cut174) Donald",
        "interaction" : "cut174",
        "SUID" : 408,
        "BEND_MAP_ID" : 408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut174) Goofy",
        "shared_interaction" : "cut174",
        "name" : "Sora (cut174) Goofy",
        "interaction" : "cut174",
        "SUID" : 407,
        "BEND_MAP_ID" : 407,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "406",
        "source" : "84",
        "target" : "395",
        "EdgeBetweenness" : 118.15173160173158,
        "shared_name" : "Sora (cut173) Aladdin",
        "shared_interaction" : "cut173",
        "name" : "Sora (cut173) Aladdin",
        "interaction" : "cut173",
        "SUID" : 406,
        "BEND_MAP_ID" : 406,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut169) Donald",
        "shared_interaction" : "cut169",
        "name" : "Sora (cut169) Donald",
        "interaction" : "cut169",
        "SUID" : 405,
        "BEND_MAP_ID" : 405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "404",
        "source" : "84",
        "target" : "400",
        "EdgeBetweenness" : 87.56666666666663,
        "shared_name" : "Sora (cut169) Genie",
        "shared_interaction" : "cut169",
        "name" : "Sora (cut169) Genie",
        "interaction" : "cut169",
        "SUID" : 404,
        "BEND_MAP_ID" : 404,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "source" : "84",
        "target" : "395",
        "EdgeBetweenness" : 118.15173160173158,
        "shared_name" : "Sora (cut169) Aladdin",
        "shared_interaction" : "cut169",
        "name" : "Sora (cut169) Aladdin",
        "interaction" : "cut169",
        "SUID" : 403,
        "BEND_MAP_ID" : 403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "402",
        "source" : "84",
        "target" : "395",
        "EdgeBetweenness" : 118.15173160173158,
        "shared_name" : "Sora (cut168) Aladdin",
        "shared_interaction" : "cut168",
        "name" : "Sora (cut168) Aladdin",
        "interaction" : "cut168",
        "SUID" : 402,
        "BEND_MAP_ID" : 402,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "source" : "84",
        "target" : "400",
        "EdgeBetweenness" : 87.56666666666663,
        "shared_name" : "Sora (cut168) Genie",
        "shared_interaction" : "cut168",
        "name" : "Sora (cut168) Genie",
        "interaction" : "cut168",
        "SUID" : 401,
        "BEND_MAP_ID" : 401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "source" : "84",
        "target" : "395",
        "EdgeBetweenness" : 118.15173160173158,
        "shared_name" : "Sora (cut167) Aladdin",
        "shared_interaction" : "cut167",
        "name" : "Sora (cut167) Aladdin",
        "interaction" : "cut167",
        "SUID" : 399,
        "BEND_MAP_ID" : 399,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut167) Goofy",
        "shared_interaction" : "cut167",
        "name" : "Sora (cut167) Goofy",
        "interaction" : "cut167",
        "SUID" : 398,
        "BEND_MAP_ID" : 398,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "397",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut167) Donald",
        "shared_interaction" : "cut167",
        "name" : "Sora (cut167) Donald",
        "interaction" : "cut167",
        "SUID" : 397,
        "BEND_MAP_ID" : 397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "396",
        "source" : "84",
        "target" : "395",
        "EdgeBetweenness" : 118.15173160173158,
        "shared_name" : "Sora (cut166) Aladdin",
        "shared_interaction" : "cut166",
        "name" : "Sora (cut166) Aladdin",
        "interaction" : "cut166",
        "SUID" : 396,
        "BEND_MAP_ID" : 396,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "394",
        "source" : "84",
        "target" : "123",
        "EdgeBetweenness" : 127.37701742701748,
        "shared_name" : "Sora (cut165) Jafar",
        "shared_interaction" : "cut165",
        "name" : "Sora (cut165) Jafar",
        "interaction" : "cut165",
        "SUID" : 394,
        "BEND_MAP_ID" : 394,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "393",
        "source" : "84",
        "target" : "123",
        "EdgeBetweenness" : 127.37701742701748,
        "shared_name" : "Sora (cut164) Jafar",
        "shared_interaction" : "cut164",
        "name" : "Sora (cut164) Jafar",
        "interaction" : "cut164",
        "SUID" : 393,
        "BEND_MAP_ID" : 393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "392",
        "source" : "84",
        "target" : "120",
        "EdgeBetweenness" : 89.43333333333335,
        "shared_name" : "Sora (cut164) Jasmine",
        "shared_interaction" : "cut164",
        "name" : "Sora (cut164) Jasmine",
        "interaction" : "cut164",
        "SUID" : 392,
        "BEND_MAP_ID" : 392,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "391",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut164) Goofy",
        "shared_interaction" : "cut164",
        "name" : "Sora (cut164) Goofy",
        "interaction" : "cut164",
        "SUID" : 391,
        "BEND_MAP_ID" : 391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "390",
        "source" : "84",
        "target" : "76",
        "EdgeBetweenness" : 86.7333333333333,
        "shared_name" : "Sora (cut164) ???????",
        "shared_interaction" : "cut164",
        "name" : "Sora (cut164) ???????",
        "interaction" : "cut164",
        "SUID" : 390,
        "BEND_MAP_ID" : 390,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "source" : "84",
        "target" : "253",
        "EdgeBetweenness" : 82.72014652014653,
        "shared_name" : "Sora (cut163) Jiminy",
        "shared_interaction" : "cut163",
        "name" : "Sora (cut163) Jiminy",
        "interaction" : "cut163",
        "SUID" : 389,
        "BEND_MAP_ID" : 389,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "388",
        "source" : "84",
        "target" : "387",
        "EdgeBetweenness" : 103.76666666666667,
        "shared_name" : "Sora (cut162) Pinocchio",
        "shared_interaction" : "cut162",
        "name" : "Sora (cut162) Pinocchio",
        "interaction" : "cut162",
        "SUID" : 388,
        "BEND_MAP_ID" : 388,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "386",
        "source" : "84",
        "target" : "253",
        "EdgeBetweenness" : 82.72014652014653,
        "shared_name" : "Sora (cut162) Jiminy",
        "shared_interaction" : "cut162",
        "name" : "Sora (cut162) Jiminy",
        "interaction" : "cut162",
        "SUID" : 386,
        "BEND_MAP_ID" : 386,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "385",
        "source" : "84",
        "target" : "220",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Sora (cut161) Cid",
        "shared_interaction" : "cut161",
        "name" : "Sora (cut161) Cid",
        "interaction" : "cut161",
        "SUID" : 385,
        "BEND_MAP_ID" : 385,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "384",
        "source" : "84",
        "target" : "177",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Sora (cut160) Yuffie",
        "shared_interaction" : "cut160",
        "name" : "Sora (cut160) Yuffie",
        "interaction" : "cut160",
        "SUID" : 384,
        "BEND_MAP_ID" : 384,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "source" : "84",
        "target" : "179",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Sora (cut160) Aerith",
        "shared_interaction" : "cut160",
        "name" : "Sora (cut160) Aerith",
        "interaction" : "cut160",
        "SUID" : 383,
        "BEND_MAP_ID" : 383,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "382",
        "source" : "84",
        "target" : "220",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Sora (cut160) Cid",
        "shared_interaction" : "cut160",
        "name" : "Sora (cut160) Cid",
        "interaction" : "cut160",
        "SUID" : 382,
        "BEND_MAP_ID" : 382,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "381",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut159) Donald",
        "shared_interaction" : "cut159",
        "name" : "Sora (cut159) Donald",
        "interaction" : "cut159",
        "SUID" : 381,
        "BEND_MAP_ID" : 381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "source" : "84",
        "target" : "179",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Sora (cut159) Aerith",
        "shared_interaction" : "cut159",
        "name" : "Sora (cut159) Aerith",
        "interaction" : "cut159",
        "SUID" : 380,
        "BEND_MAP_ID" : 380,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut159) Leon",
        "shared_interaction" : "cut159",
        "name" : "Sora (cut159) Leon",
        "interaction" : "cut159",
        "SUID" : 379,
        "BEND_MAP_ID" : 379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "378",
        "source" : "84",
        "target" : "220",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Sora (cut159) Cid",
        "shared_interaction" : "cut159",
        "name" : "Sora (cut159) Cid",
        "interaction" : "cut159",
        "SUID" : 378,
        "BEND_MAP_ID" : 378,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut155) Donald",
        "shared_interaction" : "cut155",
        "name" : "Sora (cut155) Donald",
        "interaction" : "cut155",
        "SUID" : 377,
        "BEND_MAP_ID" : 377,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "376",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut154) Riku",
        "shared_interaction" : "cut154",
        "name" : "Sora (cut154) Riku",
        "interaction" : "cut154",
        "SUID" : 376,
        "BEND_MAP_ID" : 376,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut151) Riku",
        "shared_interaction" : "cut151",
        "name" : "Sora (cut151) Riku",
        "interaction" : "cut151",
        "SUID" : 375,
        "BEND_MAP_ID" : 375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut151) Donald",
        "shared_interaction" : "cut151",
        "name" : "Sora (cut151) Donald",
        "interaction" : "cut151",
        "SUID" : 374,
        "BEND_MAP_ID" : 374,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "373",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut151) Goofy",
        "shared_interaction" : "cut151",
        "name" : "Sora (cut151) Goofy",
        "interaction" : "cut151",
        "SUID" : 373,
        "BEND_MAP_ID" : 373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "372",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut150) Donald",
        "shared_interaction" : "cut150",
        "name" : "Sora (cut150) Donald",
        "interaction" : "cut150",
        "SUID" : 372,
        "BEND_MAP_ID" : 372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut150) Riku",
        "shared_interaction" : "cut150",
        "name" : "Sora (cut150) Riku",
        "interaction" : "cut150",
        "SUID" : 371,
        "BEND_MAP_ID" : 371,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "370",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut149) Riku",
        "shared_interaction" : "cut149",
        "name" : "Sora (cut149) Riku",
        "interaction" : "cut149",
        "SUID" : 370,
        "BEND_MAP_ID" : 370,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut148) Riku",
        "shared_interaction" : "cut148",
        "name" : "Sora (cut148) Riku",
        "interaction" : "cut148",
        "SUID" : 369,
        "BEND_MAP_ID" : 369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut146) Riku",
        "shared_interaction" : "cut146",
        "name" : "Sora (cut146) Riku",
        "interaction" : "cut146",
        "SUID" : 368,
        "BEND_MAP_ID" : 368,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "367",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut145) Riku",
        "shared_interaction" : "cut145",
        "name" : "Sora (cut145) Riku",
        "interaction" : "cut145",
        "SUID" : 367,
        "BEND_MAP_ID" : 367,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "366",
        "source" : "84",
        "target" : "94",
        "EdgeBetweenness" : 168.765367965368,
        "shared_name" : "Sora (cut144) Pooh",
        "shared_interaction" : "cut144",
        "name" : "Sora (cut144) Pooh",
        "interaction" : "cut144",
        "SUID" : 366,
        "BEND_MAP_ID" : 366,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "source" : "84",
        "target" : "94",
        "EdgeBetweenness" : 168.765367965368,
        "shared_name" : "Sora (cut143) Pooh",
        "shared_interaction" : "cut143",
        "name" : "Sora (cut143) Pooh",
        "interaction" : "cut143",
        "SUID" : 365,
        "BEND_MAP_ID" : 365,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "364",
        "source" : "84",
        "target" : "71",
        "EdgeBetweenness" : 216.28249528249523,
        "shared_name" : "Sora (cut143) ????",
        "shared_interaction" : "cut143",
        "name" : "Sora (cut143) ????",
        "interaction" : "cut143",
        "SUID" : 364,
        "BEND_MAP_ID" : 364,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "source" : "84",
        "target" : "361",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Sora (cut142) Fairy Godmother",
        "shared_interaction" : "cut142",
        "name" : "Sora (cut142) Fairy Godmother",
        "interaction" : "cut142",
        "SUID" : 363,
        "BEND_MAP_ID" : 363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "362",
        "source" : "84",
        "target" : "361",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Sora (cut141) Fairy Godmother",
        "shared_interaction" : "cut141",
        "name" : "Sora (cut141) Fairy Godmother",
        "interaction" : "cut141",
        "SUID" : 362,
        "BEND_MAP_ID" : 362,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "360",
        "source" : "84",
        "target" : "133",
        "EdgeBetweenness" : 83.5095238095238,
        "shared_name" : "Sora (cut140) Merlin",
        "shared_interaction" : "cut140",
        "name" : "Sora (cut140) Merlin",
        "interaction" : "cut140",
        "SUID" : 360,
        "BEND_MAP_ID" : 360,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut140) Goofy",
        "shared_interaction" : "cut140",
        "name" : "Sora (cut140) Goofy",
        "interaction" : "cut140",
        "SUID" : 359,
        "BEND_MAP_ID" : 359,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "358",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut140) Donald",
        "shared_interaction" : "cut140",
        "name" : "Sora (cut140) Donald",
        "interaction" : "cut140",
        "SUID" : 358,
        "BEND_MAP_ID" : 358,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut140) ??????",
        "shared_interaction" : "cut140",
        "name" : "Sora (cut140) ??????",
        "interaction" : "cut140",
        "SUID" : 357,
        "BEND_MAP_ID" : 357,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut139) Goofy",
        "shared_interaction" : "cut139",
        "name" : "Sora (cut139) Goofy",
        "interaction" : "cut139",
        "SUID" : 356,
        "BEND_MAP_ID" : 356,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "355",
        "source" : "84",
        "target" : "220",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Sora (cut138) Cid",
        "shared_interaction" : "cut138",
        "name" : "Sora (cut138) Cid",
        "interaction" : "cut138",
        "SUID" : 355,
        "BEND_MAP_ID" : 355,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "354",
        "source" : "84",
        "target" : "220",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Sora (cut137) Cid",
        "shared_interaction" : "cut137",
        "name" : "Sora (cut137) Cid",
        "interaction" : "cut137",
        "SUID" : 354,
        "BEND_MAP_ID" : 354,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "source" : "84",
        "target" : "220",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Sora (cut136) Cid",
        "shared_interaction" : "cut136",
        "name" : "Sora (cut136) Cid",
        "interaction" : "cut136",
        "SUID" : 353,
        "BEND_MAP_ID" : 353,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "352",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut135) Goofy",
        "shared_interaction" : "cut135",
        "name" : "Sora (cut135) Goofy",
        "interaction" : "cut135",
        "SUID" : 352,
        "BEND_MAP_ID" : 352,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut135) Donald",
        "shared_interaction" : "cut135",
        "name" : "Sora (cut135) Donald",
        "interaction" : "cut135",
        "SUID" : 351,
        "BEND_MAP_ID" : 351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "source" : "84",
        "target" : "220",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Sora (cut135) Cid",
        "shared_interaction" : "cut135",
        "name" : "Sora (cut135) Cid",
        "interaction" : "cut135",
        "SUID" : 350,
        "BEND_MAP_ID" : 350,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "349",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut133) Leon",
        "shared_interaction" : "cut133",
        "name" : "Sora (cut133) Leon",
        "interaction" : "cut133",
        "SUID" : 349,
        "BEND_MAP_ID" : 349,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "348",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut131) Goofy",
        "shared_interaction" : "cut131",
        "name" : "Sora (cut131) Goofy",
        "interaction" : "cut131",
        "SUID" : 348,
        "BEND_MAP_ID" : 348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut131) Donald",
        "shared_interaction" : "cut131",
        "name" : "Sora (cut131) Donald",
        "interaction" : "cut131",
        "SUID" : 347,
        "BEND_MAP_ID" : 347,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "346",
        "source" : "84",
        "target" : "345",
        "EdgeBetweenness" : 88.7025641025641,
        "shared_name" : "Sora (cut131) Sora, Donald & Goofy",
        "shared_interaction" : "cut131",
        "name" : "Sora (cut131) Sora, Donald & Goofy",
        "interaction" : "cut131",
        "SUID" : 346,
        "BEND_MAP_ID" : 346,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "source" : "84",
        "target" : "179",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Sora (cut131) Aerith",
        "shared_interaction" : "cut131",
        "name" : "Sora (cut131) Aerith",
        "interaction" : "cut131",
        "SUID" : 344,
        "BEND_MAP_ID" : 344,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "343",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut131) Leon",
        "shared_interaction" : "cut131",
        "name" : "Sora (cut131) Leon",
        "interaction" : "cut131",
        "SUID" : 343,
        "BEND_MAP_ID" : 343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut130) Goofy",
        "shared_interaction" : "cut130",
        "name" : "Sora (cut130) Goofy",
        "interaction" : "cut130",
        "SUID" : 342,
        "BEND_MAP_ID" : 342,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "341",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut130) Donald",
        "shared_interaction" : "cut130",
        "name" : "Sora (cut130) Donald",
        "interaction" : "cut130",
        "SUID" : 341,
        "BEND_MAP_ID" : 341,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "340",
        "source" : "84",
        "target" : "328",
        "EdgeBetweenness" : 87.8358974358974,
        "shared_name" : "Sora (cut129) Tarzan",
        "shared_interaction" : "cut129",
        "name" : "Sora (cut129) Tarzan",
        "interaction" : "cut129",
        "SUID" : 340,
        "BEND_MAP_ID" : 340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "339",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut129) Donald",
        "shared_interaction" : "cut129",
        "name" : "Sora (cut129) Donald",
        "interaction" : "cut129",
        "SUID" : 339,
        "BEND_MAP_ID" : 339,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "source" : "84",
        "target" : "117",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Sora (cut129) Jane",
        "shared_interaction" : "cut129",
        "name" : "Sora (cut129) Jane",
        "interaction" : "cut129",
        "SUID" : 338,
        "BEND_MAP_ID" : 338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "337",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut128) Goofy",
        "shared_interaction" : "cut128",
        "name" : "Sora (cut128) Goofy",
        "interaction" : "cut128",
        "SUID" : 337,
        "BEND_MAP_ID" : 337,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "336",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut128) Donald",
        "shared_interaction" : "cut128",
        "name" : "Sora (cut128) Donald",
        "interaction" : "cut128",
        "SUID" : 336,
        "BEND_MAP_ID" : 336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "source" : "84",
        "target" : "117",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Sora (cut128) Jane",
        "shared_interaction" : "cut128",
        "name" : "Sora (cut128) Jane",
        "interaction" : "cut128",
        "SUID" : 335,
        "BEND_MAP_ID" : 335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "334",
        "source" : "84",
        "target" : "328",
        "EdgeBetweenness" : 87.8358974358974,
        "shared_name" : "Sora (cut128) Tarzan",
        "shared_interaction" : "cut128",
        "name" : "Sora (cut128) Tarzan",
        "interaction" : "cut128",
        "SUID" : 334,
        "BEND_MAP_ID" : 334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "333",
        "source" : "84",
        "target" : "328",
        "EdgeBetweenness" : 87.8358974358974,
        "shared_name" : "Sora (cut126) Tarzan",
        "shared_interaction" : "cut126",
        "name" : "Sora (cut126) Tarzan",
        "interaction" : "cut126",
        "SUID" : 333,
        "BEND_MAP_ID" : 333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "source" : "84",
        "target" : "328",
        "EdgeBetweenness" : 87.8358974358974,
        "shared_name" : "Sora (cut124) Tarzan",
        "shared_interaction" : "cut124",
        "name" : "Sora (cut124) Tarzan",
        "interaction" : "cut124",
        "SUID" : 332,
        "BEND_MAP_ID" : 332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "331",
        "source" : "84",
        "target" : "117",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Sora (cut124) Jane",
        "shared_interaction" : "cut124",
        "name" : "Sora (cut124) Jane",
        "interaction" : "cut124",
        "SUID" : 331,
        "BEND_MAP_ID" : 331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut123) Donald",
        "shared_interaction" : "cut123",
        "name" : "Sora (cut123) Donald",
        "interaction" : "cut123",
        "SUID" : 330,
        "BEND_MAP_ID" : 330,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "329",
        "source" : "84",
        "target" : "328",
        "EdgeBetweenness" : 87.8358974358974,
        "shared_name" : "Sora (cut123) Tarzan",
        "shared_interaction" : "cut123",
        "name" : "Sora (cut123) Tarzan",
        "interaction" : "cut123",
        "SUID" : 329,
        "BEND_MAP_ID" : 329,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "327",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut123) Goofy",
        "shared_interaction" : "cut123",
        "name" : "Sora (cut123) Goofy",
        "interaction" : "cut123",
        "SUID" : 327,
        "BEND_MAP_ID" : 327,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "source" : "84",
        "target" : "325",
        "EdgeBetweenness" : 150.00000000000003,
        "shared_name" : "Sora (cut121) Clayton",
        "shared_interaction" : "cut121",
        "name" : "Sora (cut121) Clayton",
        "interaction" : "cut121",
        "SUID" : 326,
        "BEND_MAP_ID" : 326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "324",
        "source" : "84",
        "target" : "117",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Sora (cut120) Jane",
        "shared_interaction" : "cut120",
        "name" : "Sora (cut120) Jane",
        "interaction" : "cut120",
        "SUID" : 324,
        "BEND_MAP_ID" : 324,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut119) Goofy",
        "shared_interaction" : "cut119",
        "name" : "Sora (cut119) Goofy",
        "interaction" : "cut119",
        "SUID" : 323,
        "BEND_MAP_ID" : 323,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "322",
        "source" : "84",
        "target" : "117",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Sora (cut118) Jane",
        "shared_interaction" : "cut118",
        "name" : "Sora (cut118) Jane",
        "interaction" : "cut118",
        "SUID" : 322,
        "BEND_MAP_ID" : 322,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "321",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut117) Donald",
        "shared_interaction" : "cut117",
        "name" : "Sora (cut117) Donald",
        "interaction" : "cut117",
        "SUID" : 321,
        "BEND_MAP_ID" : 321,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut117) Goofy",
        "shared_interaction" : "cut117",
        "name" : "Sora (cut117) Goofy",
        "interaction" : "cut117",
        "SUID" : 320,
        "BEND_MAP_ID" : 320,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "319",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut116) Goofy",
        "shared_interaction" : "cut116",
        "name" : "Sora (cut116) Goofy",
        "interaction" : "cut116",
        "SUID" : 319,
        "BEND_MAP_ID" : 319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "source" : "84",
        "target" : "317",
        "EdgeBetweenness" : 104.92063492063492,
        "shared_name" : "Sora (cut116) Donald & Sora",
        "shared_interaction" : "cut116",
        "name" : "Sora (cut116) Donald & Sora",
        "interaction" : "cut116",
        "SUID" : 318,
        "BEND_MAP_ID" : 318,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "316",
        "source" : "84",
        "target" : "117",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Sora (cut116) Jane",
        "shared_interaction" : "cut116",
        "name" : "Sora (cut116) Jane",
        "interaction" : "cut116",
        "SUID" : 316,
        "BEND_MAP_ID" : 316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "315",
        "source" : "84",
        "target" : "117",
        "EdgeBetweenness" : 84.9320346320346,
        "shared_name" : "Sora (cut114) Jane",
        "shared_interaction" : "cut114",
        "name" : "Sora (cut114) Jane",
        "interaction" : "cut114",
        "SUID" : 315,
        "BEND_MAP_ID" : 315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut113) ??????",
        "shared_interaction" : "cut113",
        "name" : "Sora (cut113) ??????",
        "interaction" : "cut113",
        "SUID" : 314,
        "BEND_MAP_ID" : 314,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "313",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut111) ??????",
        "shared_interaction" : "cut111",
        "name" : "Sora (cut111) ??????",
        "interaction" : "cut111",
        "SUID" : 313,
        "BEND_MAP_ID" : 313,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut110) ??????",
        "shared_interaction" : "cut110",
        "name" : "Sora (cut110) ??????",
        "interaction" : "cut110",
        "SUID" : 312,
        "BEND_MAP_ID" : 312,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "311",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut109) ??????",
        "shared_interaction" : "cut109",
        "name" : "Sora (cut109) ??????",
        "interaction" : "cut109",
        "SUID" : 311,
        "BEND_MAP_ID" : 311,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut108) ??????",
        "shared_interaction" : "cut108",
        "name" : "Sora (cut108) ??????",
        "interaction" : "cut108",
        "SUID" : 310,
        "BEND_MAP_ID" : 310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "309",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut106) ??????",
        "shared_interaction" : "cut106",
        "name" : "Sora (cut106) ??????",
        "interaction" : "cut106",
        "SUID" : 309,
        "BEND_MAP_ID" : 309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut105) ??????",
        "shared_interaction" : "cut105",
        "name" : "Sora (cut105) ??????",
        "interaction" : "cut105",
        "SUID" : 308,
        "BEND_MAP_ID" : 308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "307",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut102) Donald",
        "shared_interaction" : "cut102",
        "name" : "Sora (cut102) Donald",
        "interaction" : "cut102",
        "SUID" : 307,
        "BEND_MAP_ID" : 307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "306",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut101) Donald",
        "shared_interaction" : "cut101",
        "name" : "Sora (cut101) Donald",
        "interaction" : "cut101",
        "SUID" : 306,
        "BEND_MAP_ID" : 306,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "305",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut101) Goofy",
        "shared_interaction" : "cut101",
        "name" : "Sora (cut101) Goofy",
        "interaction" : "cut101",
        "SUID" : 305,
        "BEND_MAP_ID" : 305,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "source" : "84",
        "target" : "302",
        "EdgeBetweenness" : 298.6666666666667,
        "shared_name" : "Sora (cut99) Cloud",
        "shared_interaction" : "cut99",
        "name" : "Sora (cut99) Cloud",
        "interaction" : "cut99",
        "SUID" : 304,
        "BEND_MAP_ID" : 304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "303",
        "source" : "84",
        "target" : "302",
        "EdgeBetweenness" : 298.6666666666667,
        "shared_name" : "Sora (cut98) Cloud",
        "shared_interaction" : "cut98",
        "name" : "Sora (cut98) Cloud",
        "interaction" : "cut98",
        "SUID" : 303,
        "BEND_MAP_ID" : 303,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "301",
        "source" : "84",
        "target" : "292",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut96) Philoctetes",
        "shared_interaction" : "cut96",
        "name" : "Sora (cut96) Philoctetes",
        "interaction" : "cut96",
        "SUID" : 301,
        "BEND_MAP_ID" : 301,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "300",
        "source" : "84",
        "target" : "292",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut94) Philoctetes",
        "shared_interaction" : "cut94",
        "name" : "Sora (cut94) Philoctetes",
        "interaction" : "cut94",
        "SUID" : 300,
        "BEND_MAP_ID" : 300,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "source" : "84",
        "target" : "292",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut93) Philoctetes",
        "shared_interaction" : "cut93",
        "name" : "Sora (cut93) Philoctetes",
        "interaction" : "cut93",
        "SUID" : 299,
        "BEND_MAP_ID" : 299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "source" : "84",
        "target" : "292",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut92) Philoctetes",
        "shared_interaction" : "cut92",
        "name" : "Sora (cut92) Philoctetes",
        "interaction" : "cut92",
        "SUID" : 298,
        "BEND_MAP_ID" : 298,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "297",
        "source" : "84",
        "target" : "296",
        "EdgeBetweenness" : 129.62123987123988,
        "shared_name" : "Sora (cut91) Hades",
        "shared_interaction" : "cut91",
        "name" : "Sora (cut91) Hades",
        "interaction" : "cut91",
        "SUID" : 297,
        "BEND_MAP_ID" : 297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "295",
        "source" : "84",
        "target" : "292",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut90) Philoctetes",
        "shared_interaction" : "cut90",
        "name" : "Sora (cut90) Philoctetes",
        "interaction" : "cut90",
        "SUID" : 295,
        "BEND_MAP_ID" : 295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "source" : "84",
        "target" : "292",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut89) Philoctetes",
        "shared_interaction" : "cut89",
        "name" : "Sora (cut89) Philoctetes",
        "interaction" : "cut89",
        "SUID" : 294,
        "BEND_MAP_ID" : 294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "source" : "84",
        "target" : "292",
        "EdgeBetweenness" : 90.50256410256407,
        "shared_name" : "Sora (cut87) Philoctetes",
        "shared_interaction" : "cut87",
        "name" : "Sora (cut87) Philoctetes",
        "interaction" : "cut87",
        "SUID" : 293,
        "BEND_MAP_ID" : 293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "291",
        "source" : "84",
        "target" : "71",
        "EdgeBetweenness" : 216.28249528249523,
        "shared_name" : "Sora (cut85) ????",
        "shared_interaction" : "cut85",
        "name" : "Sora (cut85) ????",
        "interaction" : "cut85",
        "SUID" : 291,
        "BEND_MAP_ID" : 291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "source" : "84",
        "target" : "71",
        "EdgeBetweenness" : 216.28249528249523,
        "shared_name" : "Sora (cut83) ????",
        "shared_interaction" : "cut83",
        "name" : "Sora (cut83) ????",
        "interaction" : "cut83",
        "SUID" : 290,
        "BEND_MAP_ID" : 290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "289",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut82) Goofy",
        "shared_interaction" : "cut82",
        "name" : "Sora (cut82) Goofy",
        "interaction" : "cut82",
        "SUID" : 289,
        "BEND_MAP_ID" : 289,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut82) Donald",
        "shared_interaction" : "cut82",
        "name" : "Sora (cut82) Donald",
        "interaction" : "cut82",
        "SUID" : 288,
        "BEND_MAP_ID" : 288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "287",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut81) Donald",
        "shared_interaction" : "cut81",
        "name" : "Sora (cut81) Donald",
        "interaction" : "cut81",
        "SUID" : 287,
        "BEND_MAP_ID" : 287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "286",
        "source" : "84",
        "target" : "275",
        "EdgeBetweenness" : 91.16923076923075,
        "shared_name" : "Sora (cut80) Cheshire Cat",
        "shared_interaction" : "cut80",
        "name" : "Sora (cut80) Cheshire Cat",
        "interaction" : "cut80",
        "SUID" : 286,
        "BEND_MAP_ID" : 286,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut79) Goofy",
        "shared_interaction" : "cut79",
        "name" : "Sora (cut79) Goofy",
        "interaction" : "cut79",
        "SUID" : 285,
        "BEND_MAP_ID" : 285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "source" : "84",
        "target" : "275",
        "EdgeBetweenness" : 91.16923076923075,
        "shared_name" : "Sora (cut79) Cheshire Cat",
        "shared_interaction" : "cut79",
        "name" : "Sora (cut79) Cheshire Cat",
        "interaction" : "cut79",
        "SUID" : 284,
        "BEND_MAP_ID" : 284,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "source" : "84",
        "target" : "263",
        "EdgeBetweenness" : 85.33589743589744,
        "shared_name" : "Sora (cut78) Queen of Hearts",
        "shared_interaction" : "cut78",
        "name" : "Sora (cut78) Queen of Hearts",
        "interaction" : "cut78",
        "SUID" : 283,
        "BEND_MAP_ID" : 283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "282",
        "source" : "84",
        "target" : "263",
        "EdgeBetweenness" : 85.33589743589744,
        "shared_name" : "Sora (cut77) Queen of Hearts",
        "shared_interaction" : "cut77",
        "name" : "Sora (cut77) Queen of Hearts",
        "interaction" : "cut77",
        "SUID" : 282,
        "BEND_MAP_ID" : 282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "source" : "84",
        "target" : "263",
        "EdgeBetweenness" : 85.33589743589744,
        "shared_name" : "Sora (cut76) Queen of Hearts",
        "shared_interaction" : "cut76",
        "name" : "Sora (cut76) Queen of Hearts",
        "interaction" : "cut76",
        "SUID" : 281,
        "BEND_MAP_ID" : 281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "280",
        "source" : "84",
        "target" : "272",
        "EdgeBetweenness" : 85.33589743589742,
        "shared_name" : "Sora (cut75) Card Soldier",
        "shared_interaction" : "cut75",
        "name" : "Sora (cut75) Card Soldier",
        "interaction" : "cut75",
        "SUID" : 280,
        "BEND_MAP_ID" : 280,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "279",
        "source" : "84",
        "target" : "275",
        "EdgeBetweenness" : 91.16923076923075,
        "shared_name" : "Sora (cut74) Cheshire Cat",
        "shared_interaction" : "cut74",
        "name" : "Sora (cut74) Cheshire Cat",
        "interaction" : "cut74",
        "SUID" : 279,
        "BEND_MAP_ID" : 279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut73) Donald",
        "shared_interaction" : "cut73",
        "name" : "Sora (cut73) Donald",
        "interaction" : "cut73",
        "SUID" : 278,
        "BEND_MAP_ID" : 278,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "source" : "84",
        "target" : "275",
        "EdgeBetweenness" : 91.16923076923075,
        "shared_name" : "Sora (cut73) Cheshire Cat",
        "shared_interaction" : "cut73",
        "name" : "Sora (cut73) Cheshire Cat",
        "interaction" : "cut73",
        "SUID" : 277,
        "BEND_MAP_ID" : 277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "276",
        "source" : "84",
        "target" : "275",
        "EdgeBetweenness" : 91.16923076923075,
        "shared_name" : "Sora (cut72) Cheshire Cat",
        "shared_interaction" : "cut72",
        "name" : "Sora (cut72) Cheshire Cat",
        "interaction" : "cut72",
        "SUID" : 276,
        "BEND_MAP_ID" : 276,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut72) Donald",
        "shared_interaction" : "cut72",
        "name" : "Sora (cut72) Donald",
        "interaction" : "cut72",
        "SUID" : 274,
        "BEND_MAP_ID" : 274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "273",
        "source" : "84",
        "target" : "272",
        "EdgeBetweenness" : 85.33589743589742,
        "shared_name" : "Sora (cut71) Card Soldier",
        "shared_interaction" : "cut71",
        "name" : "Sora (cut71) Card Soldier",
        "interaction" : "cut71",
        "SUID" : 273,
        "BEND_MAP_ID" : 273,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "271",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut71) Donald",
        "shared_interaction" : "cut71",
        "name" : "Sora (cut71) Donald",
        "interaction" : "cut71",
        "SUID" : 271,
        "BEND_MAP_ID" : 271,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut71) Goofy",
        "shared_interaction" : "cut71",
        "name" : "Sora (cut71) Goofy",
        "interaction" : "cut71",
        "SUID" : 270,
        "BEND_MAP_ID" : 270,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "269",
        "source" : "84",
        "target" : "265",
        "EdgeBetweenness" : 158.5619047619048,
        "shared_name" : "Sora (cut71) Alice",
        "shared_interaction" : "cut71",
        "name" : "Sora (cut71) Alice",
        "interaction" : "cut71",
        "SUID" : 269,
        "BEND_MAP_ID" : 269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut69) Goofy",
        "shared_interaction" : "cut69",
        "name" : "Sora (cut69) Goofy",
        "interaction" : "cut69",
        "SUID" : 268,
        "BEND_MAP_ID" : 268,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "267",
        "source" : "84",
        "target" : "263",
        "EdgeBetweenness" : 85.33589743589744,
        "shared_name" : "Sora (cut69) Queen of Hearts",
        "shared_interaction" : "cut69",
        "name" : "Sora (cut69) Queen of Hearts",
        "interaction" : "cut69",
        "SUID" : 267,
        "BEND_MAP_ID" : 267,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "source" : "84",
        "target" : "265",
        "EdgeBetweenness" : 158.5619047619048,
        "shared_name" : "Sora (cut68) Alice",
        "shared_interaction" : "cut68",
        "name" : "Sora (cut68) Alice",
        "interaction" : "cut68",
        "SUID" : 266,
        "BEND_MAP_ID" : 266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "264",
        "source" : "84",
        "target" : "263",
        "EdgeBetweenness" : 85.33589743589744,
        "shared_name" : "Sora (cut67) Queen of Hearts",
        "shared_interaction" : "cut67",
        "name" : "Sora (cut67) Queen of Hearts",
        "interaction" : "cut67",
        "SUID" : 264,
        "BEND_MAP_ID" : 264,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "262",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut67) Goofy",
        "shared_interaction" : "cut67",
        "name" : "Sora (cut67) Goofy",
        "interaction" : "cut67",
        "SUID" : 262,
        "BEND_MAP_ID" : 262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "261",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut67) Donald",
        "shared_interaction" : "cut67",
        "name" : "Sora (cut67) Donald",
        "interaction" : "cut67",
        "SUID" : 261,
        "BEND_MAP_ID" : 261,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "source" : "84",
        "target" : "258",
        "EdgeBetweenness" : 108.25396825396825,
        "shared_name" : "Sora (cut66) Doorknob",
        "shared_interaction" : "cut66",
        "name" : "Sora (cut66) Doorknob",
        "interaction" : "cut66",
        "SUID" : 260,
        "BEND_MAP_ID" : 260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "259",
        "source" : "84",
        "target" : "258",
        "EdgeBetweenness" : 108.25396825396825,
        "shared_name" : "Sora (cut65) Doorknob",
        "shared_interaction" : "cut65",
        "name" : "Sora (cut65) Doorknob",
        "interaction" : "cut65",
        "SUID" : 259,
        "BEND_MAP_ID" : 259,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "source" : "84",
        "target" : "179",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Sora (cut64) Aerith",
        "shared_interaction" : "cut64",
        "name" : "Sora (cut64) Aerith",
        "interaction" : "cut64",
        "SUID" : 257,
        "BEND_MAP_ID" : 257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "256",
        "source" : "84",
        "target" : "177",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Sora (cut64) Yuffie",
        "shared_interaction" : "cut64",
        "name" : "Sora (cut64) Yuffie",
        "interaction" : "cut64",
        "SUID" : 256,
        "BEND_MAP_ID" : 256,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut64) Leon",
        "shared_interaction" : "cut64",
        "name" : "Sora (cut64) Leon",
        "interaction" : "cut64",
        "SUID" : 255,
        "BEND_MAP_ID" : 255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "source" : "84",
        "target" : "253",
        "EdgeBetweenness" : 82.72014652014653,
        "shared_name" : "Sora (cut63) Jiminy",
        "shared_interaction" : "cut63",
        "name" : "Sora (cut63) Jiminy",
        "interaction" : "cut63",
        "SUID" : 254,
        "BEND_MAP_ID" : 254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "252",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut63) Donald",
        "shared_interaction" : "cut63",
        "name" : "Sora (cut63) Donald",
        "interaction" : "cut63",
        "SUID" : 252,
        "BEND_MAP_ID" : 252,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut63) Goofy",
        "shared_interaction" : "cut63",
        "name" : "Sora (cut63) Goofy",
        "interaction" : "cut63",
        "SUID" : 251,
        "BEND_MAP_ID" : 251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "250",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut62) Goofy",
        "shared_interaction" : "cut62",
        "name" : "Sora (cut62) Goofy",
        "interaction" : "cut62",
        "SUID" : 250,
        "BEND_MAP_ID" : 250,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "249",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut62) Donald",
        "shared_interaction" : "cut62",
        "name" : "Sora (cut62) Donald",
        "interaction" : "cut62",
        "SUID" : 249,
        "BEND_MAP_ID" : 249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut61) Donald",
        "shared_interaction" : "cut61",
        "name" : "Sora (cut61) Donald",
        "interaction" : "cut61",
        "SUID" : 248,
        "BEND_MAP_ID" : 248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "247",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut61) Goofy",
        "shared_interaction" : "cut61",
        "name" : "Sora (cut61) Goofy",
        "interaction" : "cut61",
        "SUID" : 247,
        "BEND_MAP_ID" : 247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "246",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut60) Donald",
        "shared_interaction" : "cut60",
        "name" : "Sora (cut60) Donald",
        "interaction" : "cut60",
        "SUID" : 246,
        "BEND_MAP_ID" : 246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut59) Donald",
        "shared_interaction" : "cut59",
        "name" : "Sora (cut59) Donald",
        "interaction" : "cut59",
        "SUID" : 245,
        "BEND_MAP_ID" : 245,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "244",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut59) Leon",
        "shared_interaction" : "cut59",
        "name" : "Sora (cut59) Leon",
        "interaction" : "cut59",
        "SUID" : 244,
        "BEND_MAP_ID" : 244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "243",
        "source" : "84",
        "target" : "106",
        "EdgeBetweenness" : 116.55757575757578,
        "shared_name" : "Sora (cut58) Goofy",
        "shared_interaction" : "cut58",
        "name" : "Sora (cut58) Goofy",
        "interaction" : "cut58",
        "SUID" : 243,
        "BEND_MAP_ID" : 243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut57) Leon",
        "shared_interaction" : "cut57",
        "name" : "Sora (cut57) Leon",
        "interaction" : "cut57",
        "SUID" : 242,
        "BEND_MAP_ID" : 242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "241",
        "source" : "84",
        "target" : "173",
        "EdgeBetweenness" : 110.70909090909093,
        "shared_name" : "Sora (cut57) Donald & Goofy",
        "shared_interaction" : "cut57",
        "name" : "Sora (cut57) Donald & Goofy",
        "interaction" : "cut57",
        "SUID" : 241,
        "BEND_MAP_ID" : 241,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut56) Leon",
        "shared_interaction" : "cut56",
        "name" : "Sora (cut56) Leon",
        "interaction" : "cut56",
        "SUID" : 240,
        "BEND_MAP_ID" : 240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "239",
        "source" : "84",
        "target" : "177",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Sora (cut56) Yuffie",
        "shared_interaction" : "cut56",
        "name" : "Sora (cut56) Yuffie",
        "interaction" : "cut56",
        "SUID" : 239,
        "BEND_MAP_ID" : 239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "238",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut55) Leon",
        "shared_interaction" : "cut55",
        "name" : "Sora (cut55) Leon",
        "interaction" : "cut55",
        "SUID" : 238,
        "BEND_MAP_ID" : 238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "237",
        "source" : "84",
        "target" : "177",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Sora (cut53) Yuffie",
        "shared_interaction" : "cut53",
        "name" : "Sora (cut53) Yuffie",
        "interaction" : "cut53",
        "SUID" : 237,
        "BEND_MAP_ID" : 237,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut53) Leon",
        "shared_interaction" : "cut53",
        "name" : "Sora (cut53) Leon",
        "interaction" : "cut53",
        "SUID" : 236,
        "BEND_MAP_ID" : 236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "235",
        "source" : "84",
        "target" : "179",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Sora (cut52) Aerith",
        "shared_interaction" : "cut52",
        "name" : "Sora (cut52) Aerith",
        "interaction" : "cut52",
        "SUID" : 235,
        "BEND_MAP_ID" : 235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "source" : "84",
        "target" : "114",
        "EdgeBetweenness" : 120.92424242424244,
        "shared_name" : "Sora (cut52) Donald",
        "shared_interaction" : "cut52",
        "name" : "Sora (cut52) Donald",
        "interaction" : "cut52",
        "SUID" : 234,
        "BEND_MAP_ID" : 234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut51) Leon",
        "shared_interaction" : "cut51",
        "name" : "Sora (cut51) Leon",
        "interaction" : "cut51",
        "SUID" : 233,
        "BEND_MAP_ID" : 233,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "232",
        "source" : "84",
        "target" : "177",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Sora (cut51) Yuffie",
        "shared_interaction" : "cut51",
        "name" : "Sora (cut51) Yuffie",
        "interaction" : "cut51",
        "SUID" : 232,
        "BEND_MAP_ID" : 232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "231",
        "source" : "84",
        "target" : "179",
        "EdgeBetweenness" : 85.9320346320346,
        "shared_name" : "Sora (cut51) Aerith",
        "shared_interaction" : "cut51",
        "name" : "Sora (cut51) Aerith",
        "interaction" : "cut51",
        "SUID" : 231,
        "BEND_MAP_ID" : 231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut50) Leon",
        "shared_interaction" : "cut50",
        "name" : "Sora (cut50) Leon",
        "interaction" : "cut50",
        "SUID" : 230,
        "BEND_MAP_ID" : 230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "229",
        "source" : "84",
        "target" : "175",
        "EdgeBetweenness" : 85.4320346320346,
        "shared_name" : "Sora (cut49) Leon",
        "shared_interaction" : "cut49",
        "name" : "Sora (cut49) Leon",
        "interaction" : "cut49",
        "SUID" : 229,
        "BEND_MAP_ID" : 229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "source" : "84",
        "target" : "177",
        "EdgeBetweenness" : 86.33203463203459,
        "shared_name" : "Sora (cut49) Yuffie",
        "shared_interaction" : "cut49",
        "name" : "Sora (cut49) Yuffie",
        "interaction" : "cut49",
        "SUID" : 228,
        "BEND_MAP_ID" : 228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "227",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut48) ??????",
        "shared_interaction" : "cut48",
        "name" : "Sora (cut48) ??????",
        "interaction" : "cut48",
        "SUID" : 227,
        "BEND_MAP_ID" : 227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "226",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut47) Kairi",
        "shared_interaction" : "cut47",
        "name" : "Sora (cut47) Kairi",
        "interaction" : "cut47",
        "SUID" : 226,
        "BEND_MAP_ID" : 226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "225",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut46) ??????",
        "shared_interaction" : "cut46",
        "name" : "Sora (cut46) ??????",
        "interaction" : "cut46",
        "SUID" : 225,
        "BEND_MAP_ID" : 225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "224",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut45) ??????",
        "shared_interaction" : "cut45",
        "name" : "Sora (cut45) ??????",
        "interaction" : "cut45",
        "SUID" : 224,
        "BEND_MAP_ID" : 224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "223",
        "source" : "84",
        "target" : "222",
        "EdgeBetweenness" : 94.79436674436674,
        "shared_name" : "Sora (cut44) ??????",
        "shared_interaction" : "cut44",
        "name" : "Sora (cut44) ??????",
        "interaction" : "cut44",
        "SUID" : 223,
        "BEND_MAP_ID" : 223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "221",
        "source" : "84",
        "target" : "220",
        "EdgeBetweenness" : 88.23589743589743,
        "shared_name" : "Sora (cut42) Cid",
        "shared_interaction" : "cut42",
        "name" : "Sora (cut42) Cid",
        "interaction" : "cut42",
        "SUID" : 221,
        "BEND_MAP_ID" : 221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "219",
        "source" : "84",
        "target" : "217",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Sora (cut41) ???",
        "shared_interaction" : "cut41",
        "name" : "Sora (cut41) ???",
        "interaction" : "cut41",
        "SUID" : 219,
        "BEND_MAP_ID" : 219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "218",
        "source" : "84",
        "target" : "217",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "Sora (cut40) ???",
        "shared_interaction" : "cut40",
        "name" : "Sora (cut40) ???",
        "interaction" : "cut40",
        "SUID" : 218,
        "BEND_MAP_ID" : 218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut29) Riku",
        "shared_interaction" : "cut29",
        "name" : "Sora (cut29) Riku",
        "interaction" : "cut29",
        "SUID" : 216,
        "BEND_MAP_ID" : 216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "215",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut24) Kairi",
        "shared_interaction" : "cut24",
        "name" : "Sora (cut24) Kairi",
        "interaction" : "cut24",
        "SUID" : 215,
        "BEND_MAP_ID" : 215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut23) Kairi",
        "shared_interaction" : "cut23",
        "name" : "Sora (cut23) Kairi",
        "interaction" : "cut23",
        "SUID" : 214,
        "BEND_MAP_ID" : 214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "213",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut22) Kairi",
        "shared_interaction" : "cut22",
        "name" : "Sora (cut22) Kairi",
        "interaction" : "cut22",
        "SUID" : 213,
        "BEND_MAP_ID" : 213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "212",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut21) Kairi",
        "shared_interaction" : "cut21",
        "name" : "Sora (cut21) Kairi",
        "interaction" : "cut21",
        "SUID" : 212,
        "BEND_MAP_ID" : 212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut20) Kairi",
        "shared_interaction" : "cut20",
        "name" : "Sora (cut20) Kairi",
        "interaction" : "cut20",
        "SUID" : 211,
        "BEND_MAP_ID" : 211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "210",
        "source" : "84",
        "target" : "78",
        "EdgeBetweenness" : 103.42123987123989,
        "shared_name" : "Sora (cut19) ?????",
        "shared_interaction" : "cut19",
        "name" : "Sora (cut19) ?????",
        "interaction" : "cut19",
        "SUID" : 210,
        "BEND_MAP_ID" : 210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "209",
        "source" : "84",
        "target" : "78",
        "EdgeBetweenness" : 103.42123987123989,
        "shared_name" : "Sora (cut18) ?????",
        "shared_interaction" : "cut18",
        "name" : "Sora (cut18) ?????",
        "interaction" : "cut18",
        "SUID" : 209,
        "BEND_MAP_ID" : 209,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut17) Riku",
        "shared_interaction" : "cut17",
        "name" : "Sora (cut17) Riku",
        "interaction" : "cut17",
        "SUID" : 208,
        "BEND_MAP_ID" : 208,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "207",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut16) Kairi",
        "shared_interaction" : "cut16",
        "name" : "Sora (cut16) Kairi",
        "interaction" : "cut16",
        "SUID" : 207,
        "BEND_MAP_ID" : 207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut16) Riku",
        "shared_interaction" : "cut16",
        "name" : "Sora (cut16) Riku",
        "interaction" : "cut16",
        "SUID" : 206,
        "BEND_MAP_ID" : 206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "205",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut15) Riku",
        "shared_interaction" : "cut15",
        "name" : "Sora (cut15) Riku",
        "interaction" : "cut15",
        "SUID" : 205,
        "BEND_MAP_ID" : 205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut14) Riku",
        "shared_interaction" : "cut14",
        "name" : "Sora (cut14) Riku",
        "interaction" : "cut14",
        "SUID" : 204,
        "BEND_MAP_ID" : 204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "203",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut13) Riku",
        "shared_interaction" : "cut13",
        "name" : "Sora (cut13) Riku",
        "interaction" : "cut13",
        "SUID" : 203,
        "BEND_MAP_ID" : 203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut12) Kairi",
        "shared_interaction" : "cut12",
        "name" : "Sora (cut12) Kairi",
        "interaction" : "cut12",
        "SUID" : 202,
        "BEND_MAP_ID" : 202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "201",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut12) Riku",
        "shared_interaction" : "cut12",
        "name" : "Sora (cut12) Riku",
        "interaction" : "cut12",
        "SUID" : 201,
        "BEND_MAP_ID" : 201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut11) Kairi",
        "shared_interaction" : "cut11",
        "name" : "Sora (cut11) Kairi",
        "interaction" : "cut11",
        "SUID" : 200,
        "BEND_MAP_ID" : 200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "199",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut11) Riku",
        "shared_interaction" : "cut11",
        "name" : "Sora (cut11) Riku",
        "interaction" : "cut11",
        "SUID" : 199,
        "BEND_MAP_ID" : 199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut9) Kairi",
        "shared_interaction" : "cut9",
        "name" : "Sora (cut9) Kairi",
        "interaction" : "cut9",
        "SUID" : 198,
        "BEND_MAP_ID" : 198,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "197",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut7) Kairi",
        "shared_interaction" : "cut7",
        "name" : "Sora (cut7) Kairi",
        "interaction" : "cut7",
        "SUID" : 197,
        "BEND_MAP_ID" : 197,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "196",
        "source" : "84",
        "target" : "96",
        "EdgeBetweenness" : 187.5817793317793,
        "shared_name" : "Sora (cut6) Riku",
        "shared_interaction" : "cut6",
        "name" : "Sora (cut6) Riku",
        "interaction" : "cut6",
        "SUID" : 196,
        "BEND_MAP_ID" : 196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "195",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut6) Kairi",
        "shared_interaction" : "cut6",
        "name" : "Sora (cut6) Kairi",
        "interaction" : "cut6",
        "SUID" : 195,
        "BEND_MAP_ID" : 195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "194",
        "source" : "84",
        "target" : "71",
        "EdgeBetweenness" : 216.28249528249523,
        "shared_name" : "Sora (cut5) ????",
        "shared_interaction" : "cut5",
        "name" : "Sora (cut5) ????",
        "interaction" : "cut5",
        "SUID" : 194,
        "BEND_MAP_ID" : 194,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "193",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut5) Kairi",
        "shared_interaction" : "cut5",
        "name" : "Sora (cut5) Kairi",
        "interaction" : "cut5",
        "SUID" : 193,
        "BEND_MAP_ID" : 193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "192",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut3) Kairi",
        "shared_interaction" : "cut3",
        "name" : "Sora (cut3) Kairi",
        "interaction" : "cut3",
        "SUID" : 192,
        "BEND_MAP_ID" : 192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "191",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut2) Kairi",
        "shared_interaction" : "cut2",
        "name" : "Sora (cut2) Kairi",
        "interaction" : "cut2",
        "SUID" : 191,
        "BEND_MAP_ID" : 191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "source" : "84",
        "target" : "82",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Sora (cut1) Kairi",
        "shared_interaction" : "cut1",
        "name" : "Sora (cut1) Kairi",
        "interaction" : "cut1",
        "SUID" : 190,
        "BEND_MAP_ID" : 190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "189",
        "source" : "84",
        "target" : "71",
        "EdgeBetweenness" : 216.28249528249523,
        "shared_name" : "Sora (cut1) ????",
        "shared_interaction" : "cut1",
        "name" : "Sora (cut1) ????",
        "interaction" : "cut1",
        "SUID" : 189,
        "BEND_MAP_ID" : 189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "188",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut54) Sora",
        "shared_interaction" : "cut54",
        "name" : "Kairi (cut54) Sora",
        "interaction" : "cut54",
        "SUID" : 188,
        "BEND_MAP_ID" : 188,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "187",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut52) Sora",
        "shared_interaction" : "cut52",
        "name" : "Kairi (cut52) Sora",
        "interaction" : "cut52",
        "SUID" : 187,
        "BEND_MAP_ID" : 187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "186",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut49) Sora",
        "shared_interaction" : "cut49",
        "name" : "Kairi (cut49) Sora",
        "interaction" : "cut49",
        "SUID" : 186,
        "BEND_MAP_ID" : 186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut48) Sora",
        "shared_interaction" : "cut48",
        "name" : "Kairi (cut48) Sora",
        "interaction" : "cut48",
        "SUID" : 185,
        "BEND_MAP_ID" : 185,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "184",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut47) Sora",
        "shared_interaction" : "cut47",
        "name" : "Kairi (cut47) Sora",
        "interaction" : "cut47",
        "SUID" : 184,
        "BEND_MAP_ID" : 184,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut46) Sora",
        "shared_interaction" : "cut46",
        "name" : "Kairi (cut46) Sora",
        "interaction" : "cut46",
        "SUID" : 183,
        "BEND_MAP_ID" : 183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "182",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut45) Sora",
        "shared_interaction" : "cut45",
        "name" : "Kairi (cut45) Sora",
        "interaction" : "cut45",
        "SUID" : 182,
        "BEND_MAP_ID" : 182,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "181",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut44) Sora",
        "shared_interaction" : "cut44",
        "name" : "Kairi (cut44) Sora",
        "interaction" : "cut44",
        "SUID" : 181,
        "BEND_MAP_ID" : 181,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "180",
        "source" : "82",
        "target" : "179",
        "EdgeBetweenness" : 6.586580086580087,
        "shared_name" : "Kairi (cut42) Aerith",
        "shared_interaction" : "cut42",
        "name" : "Kairi (cut42) Aerith",
        "interaction" : "cut42",
        "SUID" : 180,
        "BEND_MAP_ID" : 180,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "178",
        "source" : "82",
        "target" : "177",
        "EdgeBetweenness" : 6.186580086580087,
        "shared_name" : "Kairi (cut42) Yuffie",
        "shared_interaction" : "cut42",
        "name" : "Kairi (cut42) Yuffie",
        "interaction" : "cut42",
        "SUID" : 178,
        "BEND_MAP_ID" : 178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176",
        "source" : "82",
        "target" : "175",
        "EdgeBetweenness" : 6.086580086580087,
        "shared_name" : "Kairi (cut42) Leon",
        "shared_interaction" : "cut42",
        "name" : "Kairi (cut42) Leon",
        "interaction" : "cut42",
        "SUID" : 176,
        "BEND_MAP_ID" : 176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "174",
        "source" : "82",
        "target" : "173",
        "EdgeBetweenness" : 8.746969696969696,
        "shared_name" : "Kairi (cut41) Donald & Goofy",
        "shared_interaction" : "cut41",
        "name" : "Kairi (cut41) Donald & Goofy",
        "interaction" : "cut41",
        "SUID" : 174,
        "BEND_MAP_ID" : 174,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "172",
        "source" : "82",
        "target" : "114",
        "EdgeBetweenness" : 23.699999999999996,
        "shared_name" : "Kairi (cut37) Donald",
        "shared_interaction" : "cut37",
        "name" : "Kairi (cut37) Donald",
        "interaction" : "cut37",
        "SUID" : 172,
        "BEND_MAP_ID" : 172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "171",
        "source" : "82",
        "target" : "106",
        "EdgeBetweenness" : 33.6,
        "shared_name" : "Kairi (cut37) Goofy",
        "shared_interaction" : "cut37",
        "name" : "Kairi (cut37) Goofy",
        "interaction" : "cut37",
        "SUID" : 171,
        "BEND_MAP_ID" : 171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "170",
        "source" : "82",
        "target" : "96",
        "EdgeBetweenness" : 16.655627705627705,
        "shared_name" : "Kairi (cut36) Riku",
        "shared_interaction" : "cut36",
        "name" : "Kairi (cut36) Riku",
        "interaction" : "cut36",
        "SUID" : 170,
        "BEND_MAP_ID" : 170,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "169",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut29) Sora",
        "shared_interaction" : "cut29",
        "name" : "Kairi (cut29) Sora",
        "interaction" : "cut29",
        "SUID" : 169,
        "BEND_MAP_ID" : 169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "168",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut24) Sora",
        "shared_interaction" : "cut24",
        "name" : "Kairi (cut24) Sora",
        "interaction" : "cut24",
        "SUID" : 168,
        "BEND_MAP_ID" : 168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "167",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut23) Sora",
        "shared_interaction" : "cut23",
        "name" : "Kairi (cut23) Sora",
        "interaction" : "cut23",
        "SUID" : 167,
        "BEND_MAP_ID" : 167,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "166",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut22) Sora",
        "shared_interaction" : "cut22",
        "name" : "Kairi (cut22) Sora",
        "interaction" : "cut22",
        "SUID" : 166,
        "BEND_MAP_ID" : 166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "165",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut21) Sora",
        "shared_interaction" : "cut21",
        "name" : "Kairi (cut21) Sora",
        "interaction" : "cut21",
        "SUID" : 165,
        "BEND_MAP_ID" : 165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "164",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut20) Sora",
        "shared_interaction" : "cut20",
        "name" : "Kairi (cut20) Sora",
        "interaction" : "cut20",
        "SUID" : 164,
        "BEND_MAP_ID" : 164,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "163",
        "source" : "82",
        "target" : "96",
        "EdgeBetweenness" : 16.655627705627705,
        "shared_name" : "Kairi (cut13) Riku",
        "shared_interaction" : "cut13",
        "name" : "Kairi (cut13) Riku",
        "interaction" : "cut13",
        "SUID" : 163,
        "BEND_MAP_ID" : 163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "162",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut13) Sora",
        "shared_interaction" : "cut13",
        "name" : "Kairi (cut13) Sora",
        "interaction" : "cut13",
        "SUID" : 162,
        "BEND_MAP_ID" : 162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "161",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut11) Sora",
        "shared_interaction" : "cut11",
        "name" : "Kairi (cut11) Sora",
        "interaction" : "cut11",
        "SUID" : 161,
        "BEND_MAP_ID" : 161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "160",
        "source" : "82",
        "target" : "96",
        "EdgeBetweenness" : 16.655627705627705,
        "shared_name" : "Kairi (cut11) Riku",
        "shared_interaction" : "cut11",
        "name" : "Kairi (cut11) Riku",
        "interaction" : "cut11",
        "SUID" : 160,
        "BEND_MAP_ID" : 160,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "159",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut10) Sora",
        "shared_interaction" : "cut10",
        "name" : "Kairi (cut10) Sora",
        "interaction" : "cut10",
        "SUID" : 159,
        "BEND_MAP_ID" : 159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "158",
        "source" : "82",
        "target" : "96",
        "EdgeBetweenness" : 16.655627705627705,
        "shared_name" : "Kairi (cut10) Riku",
        "shared_interaction" : "cut10",
        "name" : "Kairi (cut10) Riku",
        "interaction" : "cut10",
        "SUID" : 158,
        "BEND_MAP_ID" : 158,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "157",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut9) Sora",
        "shared_interaction" : "cut9",
        "name" : "Kairi (cut9) Sora",
        "interaction" : "cut9",
        "SUID" : 157,
        "BEND_MAP_ID" : 157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "156",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut7) Sora",
        "shared_interaction" : "cut7",
        "name" : "Kairi (cut7) Sora",
        "interaction" : "cut7",
        "SUID" : 156,
        "BEND_MAP_ID" : 156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "155",
        "source" : "82",
        "target" : "96",
        "EdgeBetweenness" : 16.655627705627705,
        "shared_name" : "Kairi (cut6) Riku",
        "shared_interaction" : "cut6",
        "name" : "Kairi (cut6) Riku",
        "interaction" : "cut6",
        "SUID" : 155,
        "BEND_MAP_ID" : 155,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "154",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut6) Sora",
        "shared_interaction" : "cut6",
        "name" : "Kairi (cut6) Sora",
        "interaction" : "cut6",
        "SUID" : 154,
        "BEND_MAP_ID" : 154,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "153",
        "source" : "82",
        "target" : "96",
        "EdgeBetweenness" : 16.655627705627705,
        "shared_name" : "Kairi (cut5) Riku",
        "shared_interaction" : "cut5",
        "name" : "Kairi (cut5) Riku",
        "interaction" : "cut5",
        "SUID" : 153,
        "BEND_MAP_ID" : 153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "152",
        "source" : "82",
        "target" : "71",
        "EdgeBetweenness" : 21.284415584415584,
        "shared_name" : "Kairi (cut4) ????",
        "shared_interaction" : "cut4",
        "name" : "Kairi (cut4) ????",
        "interaction" : "cut4",
        "SUID" : 152,
        "BEND_MAP_ID" : 152,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "151",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut4) Sora",
        "shared_interaction" : "cut4",
        "name" : "Kairi (cut4) Sora",
        "interaction" : "cut4",
        "SUID" : 151,
        "BEND_MAP_ID" : 151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "150",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "Kairi (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 150,
        "BEND_MAP_ID" : 150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "149",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut2) Sora",
        "shared_interaction" : "cut2",
        "name" : "Kairi (cut2) Sora",
        "interaction" : "cut2",
        "SUID" : 149,
        "BEND_MAP_ID" : 149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "148",
        "source" : "82",
        "target" : "84",
        "EdgeBetweenness" : 77.1,
        "shared_name" : "Kairi (cut1) Sora",
        "shared_interaction" : "cut1",
        "name" : "Kairi (cut1) Sora",
        "interaction" : "cut1",
        "SUID" : 148,
        "BEND_MAP_ID" : 148,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "147",
        "source" : "82",
        "target" : "71",
        "EdgeBetweenness" : 21.284415584415584,
        "shared_name" : "Kairi (cut1) ????",
        "shared_interaction" : "cut1",
        "name" : "Kairi (cut1) ????",
        "interaction" : "cut1",
        "SUID" : 147,
        "BEND_MAP_ID" : 147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "146",
        "source" : "78",
        "target" : "96",
        "EdgeBetweenness" : 15.233832833832833,
        "shared_name" : "????? (cut34) Riku",
        "shared_interaction" : "cut34",
        "name" : "????? (cut34) Riku",
        "interaction" : "cut34",
        "SUID" : 146,
        "BEND_MAP_ID" : 146,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "145",
        "source" : "78",
        "target" : "96",
        "EdgeBetweenness" : 15.233832833832833,
        "shared_name" : "????? (cut33) Riku",
        "shared_interaction" : "cut33",
        "name" : "????? (cut33) Riku",
        "interaction" : "cut33",
        "SUID" : 145,
        "BEND_MAP_ID" : 145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "144",
        "source" : "78",
        "target" : "96",
        "EdgeBetweenness" : 15.233832833832833,
        "shared_name" : "????? (cut32) Riku",
        "shared_interaction" : "cut32",
        "name" : "????? (cut32) Riku",
        "interaction" : "cut32",
        "SUID" : 144,
        "BEND_MAP_ID" : 144,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "143",
        "source" : "78",
        "target" : "96",
        "EdgeBetweenness" : 15.233832833832833,
        "shared_name" : "????? (cut30) Riku",
        "shared_interaction" : "cut30",
        "name" : "????? (cut30) Riku",
        "interaction" : "cut30",
        "SUID" : 143,
        "BEND_MAP_ID" : 143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "142",
        "source" : "78",
        "target" : "96",
        "EdgeBetweenness" : 15.233832833832833,
        "shared_name" : "????? (cut26) Riku",
        "shared_interaction" : "cut26",
        "name" : "????? (cut26) Riku",
        "interaction" : "cut26",
        "SUID" : 142,
        "BEND_MAP_ID" : 142,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "141",
        "source" : "78",
        "target" : "84",
        "EdgeBetweenness" : 103.42123987123989,
        "shared_name" : "????? (cut23) Sora",
        "shared_interaction" : "cut23",
        "name" : "????? (cut23) Sora",
        "interaction" : "cut23",
        "SUID" : 141,
        "BEND_MAP_ID" : 141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "140",
        "source" : "78",
        "target" : "114",
        "EdgeBetweenness" : 34.23235098235098,
        "shared_name" : "????? (cut22) Donald",
        "shared_interaction" : "cut22",
        "name" : "????? (cut22) Donald",
        "interaction" : "cut22",
        "SUID" : 140,
        "BEND_MAP_ID" : 140,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "139",
        "source" : "78",
        "target" : "84",
        "EdgeBetweenness" : 103.42123987123989,
        "shared_name" : "????? (cut18) Sora",
        "shared_interaction" : "cut18",
        "name" : "????? (cut18) Sora",
        "interaction" : "cut18",
        "SUID" : 139,
        "BEND_MAP_ID" : 139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "138",
        "source" : "78",
        "target" : "106",
        "EdgeBetweenness" : 45.624342324342315,
        "shared_name" : "????? (cut17) Goofy",
        "shared_interaction" : "cut17",
        "name" : "????? (cut17) Goofy",
        "interaction" : "cut17",
        "SUID" : 138,
        "BEND_MAP_ID" : 138,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "137",
        "source" : "78",
        "target" : "136",
        "EdgeBetweenness" : 27.019264069264075,
        "shared_name" : "????? (cut13) Sebastian",
        "shared_interaction" : "cut13",
        "name" : "????? (cut13) Sebastian",
        "interaction" : "cut13",
        "SUID" : 137,
        "BEND_MAP_ID" : 137,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "135",
        "source" : "78",
        "target" : "98",
        "EdgeBetweenness" : 38.35363525363525,
        "shared_name" : "????? (cut12) Maleficent",
        "shared_interaction" : "cut12",
        "name" : "????? (cut12) Maleficent",
        "interaction" : "cut12",
        "SUID" : 135,
        "BEND_MAP_ID" : 135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "134",
        "source" : "78",
        "target" : "133",
        "EdgeBetweenness" : 10.201587301587304,
        "shared_name" : "????? (cut11) Merlin",
        "shared_interaction" : "cut11",
        "name" : "????? (cut11) Merlin",
        "interaction" : "cut11",
        "SUID" : 134,
        "BEND_MAP_ID" : 134,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "132",
        "source" : "78",
        "target" : "89",
        "EdgeBetweenness" : 46.29384504384504,
        "shared_name" : "????? (cut10) ??????????",
        "shared_interaction" : "cut10",
        "name" : "????? (cut10) ??????????",
        "interaction" : "cut10",
        "SUID" : 132,
        "BEND_MAP_ID" : 132,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "131",
        "source" : "78",
        "target" : "89",
        "EdgeBetweenness" : 46.29384504384504,
        "shared_name" : "????? (cut8) ??????????",
        "shared_interaction" : "cut8",
        "name" : "????? (cut8) ??????????",
        "interaction" : "cut8",
        "SUID" : 131,
        "BEND_MAP_ID" : 131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "130",
        "source" : "78",
        "target" : "71",
        "EdgeBetweenness" : 12.953246753246752,
        "shared_name" : "????? (cut7) ????",
        "shared_interaction" : "cut7",
        "name" : "????? (cut7) ????",
        "interaction" : "cut7",
        "SUID" : 130,
        "BEND_MAP_ID" : 130,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "129",
        "source" : "78",
        "target" : "84",
        "EdgeBetweenness" : 103.42123987123989,
        "shared_name" : "????? (cut4) Sora",
        "shared_interaction" : "cut4",
        "name" : "????? (cut4) Sora",
        "interaction" : "cut4",
        "SUID" : 129,
        "BEND_MAP_ID" : 129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "128",
        "source" : "78",
        "target" : "84",
        "EdgeBetweenness" : 103.42123987123989,
        "shared_name" : "????? (cut3) Sora",
        "shared_interaction" : "cut3",
        "name" : "????? (cut3) Sora",
        "interaction" : "cut3",
        "SUID" : 128,
        "BEND_MAP_ID" : 128,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "127",
        "source" : "78",
        "target" : "72",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "????? (cut2) Voice",
        "shared_interaction" : "cut2",
        "name" : "????? (cut2) Voice",
        "interaction" : "cut2",
        "SUID" : 127,
        "BEND_MAP_ID" : 127,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "126",
        "source" : "78",
        "target" : "71",
        "EdgeBetweenness" : 12.953246753246752,
        "shared_name" : "????? (cut2) ????",
        "shared_interaction" : "cut2",
        "name" : "????? (cut2) ????",
        "interaction" : "cut2",
        "SUID" : 126,
        "BEND_MAP_ID" : 126,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "125",
        "source" : "78",
        "target" : "71",
        "EdgeBetweenness" : 12.953246753246752,
        "shared_name" : "????? (cut1) ????",
        "shared_interaction" : "cut1",
        "name" : "????? (cut1) ????",
        "interaction" : "cut1",
        "SUID" : 125,
        "BEND_MAP_ID" : 125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "124",
        "source" : "76",
        "target" : "123",
        "EdgeBetweenness" : 9.478571428571428,
        "shared_name" : "??????? (cut5) Jafar",
        "shared_interaction" : "cut5",
        "name" : "??????? (cut5) Jafar",
        "interaction" : "cut5",
        "SUID" : 124,
        "BEND_MAP_ID" : 124,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "122",
        "source" : "76",
        "target" : "84",
        "EdgeBetweenness" : 86.7333333333333,
        "shared_name" : "??????? (cut5) Sora",
        "shared_interaction" : "cut5",
        "name" : "??????? (cut5) Sora",
        "interaction" : "cut5",
        "SUID" : 122,
        "BEND_MAP_ID" : 122,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "121",
        "source" : "76",
        "target" : "120",
        "EdgeBetweenness" : 10.483333333333334,
        "shared_name" : "??????? (cut5) Jasmine",
        "shared_interaction" : "cut5",
        "name" : "??????? (cut5) Jasmine",
        "interaction" : "cut5",
        "SUID" : 121,
        "BEND_MAP_ID" : 121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "119",
        "source" : "76",
        "target" : "106",
        "EdgeBetweenness" : 42.23333333333335,
        "shared_name" : "??????? (cut5) Goofy",
        "shared_interaction" : "cut5",
        "name" : "??????? (cut5) Goofy",
        "interaction" : "cut5",
        "SUID" : 119,
        "BEND_MAP_ID" : 119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "118",
        "source" : "76",
        "target" : "117",
        "EdgeBetweenness" : 8.9008658008658,
        "shared_name" : "??????? (cut2) Jane",
        "shared_interaction" : "cut2",
        "name" : "??????? (cut2) Jane",
        "interaction" : "cut2",
        "SUID" : 118,
        "BEND_MAP_ID" : 118,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "116",
        "source" : "76",
        "target" : "71",
        "EdgeBetweenness" : 20.05800865800866,
        "shared_name" : "??????? (cut1) ????",
        "shared_interaction" : "cut1",
        "name" : "??????? (cut1) ????",
        "interaction" : "cut1",
        "SUID" : 116,
        "BEND_MAP_ID" : 116,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "115",
        "source" : "72",
        "target" : "114",
        "EdgeBetweenness" : 39.16666666666667,
        "shared_name" : "Voice (cut24) Donald",
        "shared_interaction" : "cut24",
        "name" : "Voice (cut24) Donald",
        "interaction" : "cut24",
        "SUID" : 115,
        "BEND_MAP_ID" : 115,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "113",
        "source" : "72",
        "target" : "84",
        "EdgeBetweenness" : 103.99999999999999,
        "shared_name" : "Voice (cut24) Sora",
        "shared_interaction" : "cut24",
        "name" : "Voice (cut24) Sora",
        "interaction" : "cut24",
        "SUID" : 113,
        "BEND_MAP_ID" : 113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "112",
        "source" : "72",
        "target" : "71",
        "EdgeBetweenness" : 15.166666666666666,
        "shared_name" : "Voice (cut16) ????",
        "shared_interaction" : "cut16",
        "name" : "Voice (cut16) ????",
        "interaction" : "cut16",
        "SUID" : 112,
        "BEND_MAP_ID" : 112,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "111",
        "source" : "72",
        "target" : "78",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "Voice (cut16) ?????",
        "shared_interaction" : "cut16",
        "name" : "Voice (cut16) ?????",
        "interaction" : "cut16",
        "SUID" : 111,
        "BEND_MAP_ID" : 111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "110",
        "source" : "72",
        "target" : "71",
        "EdgeBetweenness" : 15.166666666666666,
        "shared_name" : "Voice (cut10) ????",
        "shared_interaction" : "cut10",
        "name" : "Voice (cut10) ????",
        "interaction" : "cut10",
        "SUID" : 110,
        "BEND_MAP_ID" : 110,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "109",
        "source" : "72",
        "target" : "71",
        "EdgeBetweenness" : 15.166666666666666,
        "shared_name" : "Voice (cut9) ????",
        "shared_interaction" : "cut9",
        "name" : "Voice (cut9) ????",
        "interaction" : "cut9",
        "SUID" : 109,
        "BEND_MAP_ID" : 109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "108",
        "source" : "72",
        "target" : "71",
        "EdgeBetweenness" : 15.166666666666666,
        "shared_name" : "Voice (cut6) ????",
        "shared_interaction" : "cut6",
        "name" : "Voice (cut6) ????",
        "interaction" : "cut6",
        "SUID" : 108,
        "BEND_MAP_ID" : 108,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "107",
        "source" : "71",
        "target" : "106",
        "EdgeBetweenness" : 114.98256743256738,
        "shared_name" : "???? (cut22) Goofy",
        "shared_interaction" : "cut22",
        "name" : "???? (cut22) Goofy",
        "interaction" : "cut22",
        "SUID" : 107,
        "BEND_MAP_ID" : 107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "105",
        "source" : "71",
        "target" : "104",
        "EdgeBetweenness" : 75.904329004329,
        "shared_name" : "???? (cut21) Captain Hook",
        "shared_interaction" : "cut21",
        "name" : "???? (cut21) Captain Hook",
        "interaction" : "cut21",
        "SUID" : 105,
        "BEND_MAP_ID" : 105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "103",
        "source" : "71",
        "target" : "102",
        "EdgeBetweenness" : 155.23333333333332,
        "shared_name" : "???? (cut20) Hook",
        "shared_interaction" : "cut20",
        "name" : "???? (cut20) Hook",
        "interaction" : "cut20",
        "SUID" : 103,
        "BEND_MAP_ID" : 103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "101",
        "source" : "71",
        "target" : "96",
        "EdgeBetweenness" : 17.78058608058608,
        "shared_name" : "???? (cut19) Riku",
        "shared_interaction" : "cut19",
        "name" : "???? (cut19) Riku",
        "interaction" : "cut19",
        "SUID" : 101,
        "BEND_MAP_ID" : 101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "100",
        "source" : "71",
        "target" : "84",
        "EdgeBetweenness" : 216.28249528249523,
        "shared_name" : "???? (cut19) Sora",
        "shared_interaction" : "cut19",
        "name" : "???? (cut19) Sora",
        "interaction" : "cut19",
        "SUID" : 100,
        "BEND_MAP_ID" : 100,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "99",
        "source" : "71",
        "target" : "98",
        "EdgeBetweenness" : 42.56961926961927,
        "shared_name" : "???? (cut18) Maleficent",
        "shared_interaction" : "cut18",
        "name" : "???? (cut18) Maleficent",
        "interaction" : "cut18",
        "SUID" : 99,
        "BEND_MAP_ID" : 99,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "97",
        "source" : "71",
        "target" : "96",
        "EdgeBetweenness" : 17.78058608058608,
        "shared_name" : "???? (cut18) Riku",
        "shared_interaction" : "cut18",
        "name" : "???? (cut18) Riku",
        "interaction" : "cut18",
        "SUID" : 97,
        "BEND_MAP_ID" : 97,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "95",
        "source" : "71",
        "target" : "94",
        "EdgeBetweenness" : 46.08427128427128,
        "shared_name" : "???? (cut17) Pooh",
        "shared_interaction" : "cut17",
        "name" : "???? (cut17) Pooh",
        "interaction" : "cut17",
        "SUID" : 95,
        "BEND_MAP_ID" : 95,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "93",
        "source" : "71",
        "target" : "84",
        "EdgeBetweenness" : 216.28249528249523,
        "shared_name" : "???? (cut17) Sora",
        "shared_interaction" : "cut17",
        "name" : "???? (cut17) Sora",
        "interaction" : "cut17",
        "SUID" : 93,
        "BEND_MAP_ID" : 93,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "92",
        "source" : "71",
        "target" : "84",
        "EdgeBetweenness" : 216.28249528249523,
        "shared_name" : "???? (cut16) Sora",
        "shared_interaction" : "cut16",
        "name" : "???? (cut16) Sora",
        "interaction" : "cut16",
        "SUID" : 92,
        "BEND_MAP_ID" : 92,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "91",
        "source" : "71",
        "target" : "84",
        "EdgeBetweenness" : 216.28249528249523,
        "shared_name" : "???? (cut14) Sora",
        "shared_interaction" : "cut14",
        "name" : "???? (cut14) Sora",
        "interaction" : "cut14",
        "SUID" : 91,
        "BEND_MAP_ID" : 91,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "90",
        "source" : "71",
        "target" : "89",
        "EdgeBetweenness" : 47.13706848706849,
        "shared_name" : "???? (cut13) ??????????",
        "shared_interaction" : "cut13",
        "name" : "???? (cut13) ??????????",
        "interaction" : "cut13",
        "SUID" : 90,
        "BEND_MAP_ID" : 90,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "88",
        "source" : "71",
        "target" : "78",
        "EdgeBetweenness" : 12.953246753246752,
        "shared_name" : "???? (cut12) ?????",
        "shared_interaction" : "cut12",
        "name" : "???? (cut12) ?????",
        "interaction" : "cut12",
        "SUID" : 88,
        "BEND_MAP_ID" : 88,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "87",
        "source" : "71",
        "target" : "84",
        "EdgeBetweenness" : 216.28249528249523,
        "shared_name" : "???? (cut11) Sora",
        "shared_interaction" : "cut11",
        "name" : "???? (cut11) Sora",
        "interaction" : "cut11",
        "SUID" : 87,
        "BEND_MAP_ID" : 87,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "86",
        "source" : "71",
        "target" : "82",
        "EdgeBetweenness" : 21.284415584415584,
        "shared_name" : "???? (cut11) Kairi",
        "shared_interaction" : "cut11",
        "name" : "???? (cut11) Kairi",
        "interaction" : "cut11",
        "SUID" : 86,
        "BEND_MAP_ID" : 86,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "85",
        "source" : "71",
        "target" : "84",
        "EdgeBetweenness" : 216.28249528249523,
        "shared_name" : "???? (cut10) Sora",
        "shared_interaction" : "cut10",
        "name" : "???? (cut10) Sora",
        "interaction" : "cut10",
        "SUID" : 85,
        "BEND_MAP_ID" : 85,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83",
        "source" : "71",
        "target" : "82",
        "EdgeBetweenness" : 21.284415584415584,
        "shared_name" : "???? (cut10) Kairi",
        "shared_interaction" : "cut10",
        "name" : "???? (cut10) Kairi",
        "interaction" : "cut10",
        "SUID" : 83,
        "BEND_MAP_ID" : 83,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81",
        "source" : "71",
        "target" : "72",
        "EdgeBetweenness" : 15.166666666666666,
        "shared_name" : "???? (cut8) Voice",
        "shared_interaction" : "cut8",
        "name" : "???? (cut8) Voice",
        "interaction" : "cut8",
        "SUID" : 81,
        "BEND_MAP_ID" : 81,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80",
        "source" : "71",
        "target" : "78",
        "EdgeBetweenness" : 12.953246753246752,
        "shared_name" : "???? (cut8) ?????",
        "shared_interaction" : "cut8",
        "name" : "???? (cut8) ?????",
        "interaction" : "cut8",
        "SUID" : 80,
        "BEND_MAP_ID" : 80,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "79",
        "source" : "71",
        "target" : "78",
        "EdgeBetweenness" : 12.953246753246752,
        "shared_name" : "???? (cut7) ?????",
        "shared_interaction" : "cut7",
        "name" : "???? (cut7) ?????",
        "interaction" : "cut7",
        "SUID" : 79,
        "BEND_MAP_ID" : 79,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "77",
        "source" : "71",
        "target" : "76",
        "EdgeBetweenness" : 20.05800865800866,
        "shared_name" : "???? (cut6) ???????",
        "shared_interaction" : "cut6",
        "name" : "???? (cut6) ???????",
        "interaction" : "cut6",
        "SUID" : 77,
        "BEND_MAP_ID" : 77,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "75",
        "source" : "71",
        "target" : "72",
        "EdgeBetweenness" : 15.166666666666666,
        "shared_name" : "???? (cut4) Voice",
        "shared_interaction" : "cut4",
        "name" : "???? (cut4) Voice",
        "interaction" : "cut4",
        "SUID" : 75,
        "BEND_MAP_ID" : 75,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "74",
        "source" : "71",
        "target" : "72",
        "EdgeBetweenness" : 15.166666666666666,
        "shared_name" : "???? (cut3) Voice",
        "shared_interaction" : "cut3",
        "name" : "???? (cut3) Voice",
        "interaction" : "cut3",
        "SUID" : 74,
        "BEND_MAP_ID" : 74,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "73",
        "source" : "71",
        "target" : "72",
        "EdgeBetweenness" : 15.166666666666666,
        "shared_name" : "???? (cut2) Voice",
        "shared_interaction" : "cut2",
        "name" : "???? (cut2) Voice",
        "interaction" : "cut2",
        "SUID" : 73,
        "BEND_MAP_ID" : 73,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}