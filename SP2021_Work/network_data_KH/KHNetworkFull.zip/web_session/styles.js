var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.8.2",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "border-color" : "rgb(204,204,204)",
      "font-size" : 12,
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "height" : 35.0,
      "font-family" : "GillSans-Bold",
      "font-weight" : "normal",
      "width" : 35.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "background-color" : "rgb(51,255,51)",
      "border-width" : 0.0,
      "shape" : "roundrectangle",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[name = 'Goofy']",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "node[name = 'Sora']",
    "css" : {
      "background-color" : "rgb(0,204,204)"
    }
  }, {
    "selector" : "node[name = 'Donald']",
    "css" : {
      "background-color" : "rgb(255,0,204)"
    }
  }, {
    "selector" : "node[Degree > 762]",
    "css" : {
      "font-size" : 1
    }
  }, {
    "selector" : "node[Degree = 762]",
    "css" : {
      "font-size" : 30
    }
  }, {
    "selector" : "node[Degree > 2][Degree < 762]",
    "css" : {
      "font-size" : "mapData(Degree,2,762,10,30)"
    }
  }, {
    "selector" : "node[Degree = 2]",
    "css" : {
      "font-size" : 10
    }
  }, {
    "selector" : "node[Degree < 2]",
    "css" : {
      "font-size" : 1
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-size" : 10,
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "text-opacity" : 1.0,
      "opacity" : 1.0,
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(132,132,132)",
      "width" : 2.0,
      "content" : "",
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "target-arrow-shape" : "none"
    }
  }, {
    "selector" : "edge[EdgeBetweenness > 636.49393939]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[EdgeBetweenness = 636.49393939]",
    "css" : {
      "width" : 8.824355283177885
    }
  }, {
    "selector" : "edge[EdgeBetweenness > 2][EdgeBetweenness < 636.49393939]",
    "css" : {
      "width" : "mapData(EdgeBetweenness,2,636.49393939,4.06015037593985,8.824355283177885)"
    }
  }, {
    "selector" : "edge[EdgeBetweenness = 2]",
    "css" : {
      "width" : 4.06015037593985
    }
  }, {
    "selector" : "edge[EdgeBetweenness < 2]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]