var networks = {"KHXBetweenCutsceneNetwork.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.8.2",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "KHXBetweenCutsceneNetwork.tsv",
    "name" : "KHXBetweenCutsceneNetwork.tsv",
    "SUID" : 61,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "300",
        "ClosenessCentrality" : 0.3142857142857143,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8716577540106952,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Young Xehanort",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Young Xehanort",
        "SelfLoops" : 0,
        "SUID" : 300,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.1818181818181817,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : -60.916985259145974,
        "y" : 52.868283100494466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "289",
        "ClosenessCentrality" : 0.1853932584269663,
        "Eccentricity" : 9,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.7415329768270944,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Xemnas",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "name" : "Xemnas",
        "SelfLoops" : 0,
        "SUID" : 289,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.393939393939394,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 46.08301474085397,
        "y" : 372.86828310049447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "ClosenessCentrality" : 0.2268041237113402,
        "Eccentricity" : 8,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.7994652406417112,
        "Stress" : 242,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "Xion",
        "BetweennessCentrality" : 0.030303030303030304,
        "NumberOfUndirectedEdges" : 7,
        "name" : "Xion",
        "SelfLoops" : 0,
        "SUID" : 288,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.409090909090909,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 19.083014740854026,
        "y" : 321.36828310049435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "286",
        "ClosenessCentrality" : 0.22525597269624573,
        "Eccentricity" : 8,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.7976827094474154,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Woman",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Woman",
        "SelfLoops" : 0,
        "SUID" : 286,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.4393939393939394,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -39.916985259145974,
        "y" : 302.86828310049447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "282",
        "ClosenessCentrality" : 0.1687979539641944,
        "Eccentricity" : 9,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.7103386809269162,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Luxord",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Luxord",
        "SelfLoops" : 0,
        "SUID" : 282,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.924242424242424,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 175.58301474085408,
        "y" : -145.13171689950553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "ClosenessCentrality" : 0.20245398773006135,
        "Eccentricity" : 8,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.768270944741533,
        "Stress" : 242,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "Vexen",
        "BetweennessCentrality" : 0.030303030303030304,
        "NumberOfUndirectedEdges" : 3,
        "name" : "Vexen",
        "SelfLoops" : 0,
        "SUID" : 281,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.9393939393939394,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.5
      },
      "position" : {
        "x" : 125.08301474085397,
        "y" : -122.63171689950553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "279",
        "ClosenessCentrality" : 0.6666666666666666,
        "Eccentricity" : 2,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.75,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Elizabeth",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Elizabeth",
        "SelfLoops" : 0,
        "SUID" : 279,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.5,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 312.2075576934294,
        "y" : -351.3324084127185
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "ClosenessCentrality" : 0.6666666666666666,
        "Eccentricity" : 2,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.75,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Will",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Will",
        "SelfLoops" : 0,
        "SUID" : 277,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.5,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 310.81085489354615,
        "y" : -240.27338144122328
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "276",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 2,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Tia Dalma",
        "BetweennessCentrality" : 1.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Tia Dalma",
        "SelfLoops" : 0,
        "SUID" : 276,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 311.92833241730006,
        "y" : -297.97939942222007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "273",
        "ClosenessCentrality" : 0.21498371335504887,
        "Eccentricity" : 8,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.785204991087344,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Sulley",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Sulley",
        "SelfLoops" : 0,
        "SUID" : 273,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.651515151515151,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : -74.41698525914597,
        "y" : 231.86828310049447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "ClosenessCentrality" : 0.24175824175824173,
        "Eccentricity" : 7,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8155080213903743,
        "Stress" : 1344,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "Sora & Donald",
        "BetweennessCentrality" : 0.05967365967365967,
        "NumberOfUndirectedEdges" : 4,
        "name" : "Sora & Donald",
        "SelfLoops" : 0,
        "SUID" : 268,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.136363636363637,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.5
      },
      "position" : {
        "x" : -253.38185832025206,
        "y" : -176.7749656069096
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "262",
        "ClosenessCentrality" : 0.35106382978723405,
        "Eccentricity" : 5,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8912655971479502,
        "Stress" : 760,
        "TopologicalCoefficient" : 0.543859649122807,
        "shared_name" : "Scrooge",
        "BetweennessCentrality" : 0.02621822621822618,
        "NumberOfUndirectedEdges" : 5,
        "name" : "Scrooge",
        "SelfLoops" : 0,
        "SUID" : 262,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.8484848484848486,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.333333333333334
      },
      "position" : {
        "x" : -97.0470347453066,
        "y" : -110.27669537991758
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "258",
        "ClosenessCentrality" : 0.24719101123595502,
        "Eccentricity" : 7,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.820855614973262,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Saïx",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "name" : "Saïx",
        "SelfLoops" : 0,
        "SUID" : 258,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.045454545454546,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 58.79098753939709,
        "y" : -26.940315504786927
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "256",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Rex",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Rex",
        "SelfLoops" : 0,
        "SUID" : 256,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 463.32678430232437,
        "y" : 27.585478996692583
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Sarge",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Sarge",
        "SelfLoops" : 0,
        "SUID" : 255,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 463.85807601096104,
        "y" : 73.90949128019396
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "249",
        "ClosenessCentrality" : 0.358695652173913,
        "Eccentricity" : 5,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.2,
        "Radiality" : 0.8948306595365418,
        "Stress" : 1008,
        "TopologicalCoefficient" : 0.34545454545454546,
        "shared_name" : "Riku & Mickey",
        "BetweennessCentrality" : 0.05543345543345539,
        "NumberOfUndirectedEdges" : 5,
        "name" : "Riku & Mickey",
        "SelfLoops" : 0,
        "SUID" : 249,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.787878787878788,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : -84.86597832575394,
        "y" : -70.19988732057519
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "246",
        "ClosenessCentrality" : 0.2453531598513011,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8190730837789661,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Cloud",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Cloud",
        "SelfLoops" : 0,
        "SUID" : 246,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.075757575757576,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : -106.91698525914597,
        "y" : 151.86828310049447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "ClosenessCentrality" : 0.27385892116182575,
        "Eccentricity" : 7,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8440285204991087,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Star 13",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Star 13",
        "SelfLoops" : 0,
        "SUID" : 230,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6515151515151514,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 151.88692489836342,
        "y" : 212.9418108064471
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "ClosenessCentrality" : 0.27385892116182575,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8440285204991087,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Star 12",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Star 12",
        "SelfLoops" : 0,
        "SUID" : 228,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6515151515151514,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 192.661492278531,
        "y" : 75.18607715468335
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "226",
        "ClosenessCentrality" : 0.27385892116182575,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8440285204991087,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Star 10",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Star 10",
        "SelfLoops" : 0,
        "SUID" : 226,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6515151515151514,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 207.68448461002265,
        "y" : 126.44137121883631
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "224",
        "ClosenessCentrality" : 0.27385892116182575,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8440285204991087,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Star 9",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Star 9",
        "SelfLoops" : 0,
        "SUID" : 224,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6515151515151514,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 192.661492278531,
        "y" : 177.6966652829894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "222",
        "ClosenessCentrality" : 0.27385892116182575,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8440285204991087,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Star 8",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Star 8",
        "SelfLoops" : 0,
        "SUID" : 222,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6515151515151514,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 98.49761461126366,
        "y" : 220.31522080978635
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "ClosenessCentrality" : 0.27385892116182575,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8440285204991087,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Star 7",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Star 7",
        "SelfLoops" : 0,
        "SUID" : 220,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6515151515151514,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 50.07497056418191,
        "y" : 197.77541132335836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "218",
        "ClosenessCentrality" : 0.27385892116182575,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8440285204991087,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Star 6",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Star 6",
        "SelfLoops" : 0,
        "SUID" : 218,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6515151515151514,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 21.481544871685458,
        "y" : 152.66209316383328
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "ClosenessCentrality" : 0.27385892116182575,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8440285204991087,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Star 5",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Star 5",
        "SelfLoops" : 0,
        "SUID" : 216,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6515151515151514,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 21.76566764261696,
        "y" : 99.2512820630281
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "ClosenessCentrality" : 0.27385892116182575,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8440285204991087,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Star 4",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Star 4",
        "SelfLoops" : 0,
        "SUID" : 214,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6515151515151514,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 50.83742881686413,
        "y" : 54.44471814185255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "212",
        "ClosenessCentrality" : 0.27385892116182575,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8440285204991087,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Star 3",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Star 3",
        "SelfLoops" : 0,
        "SUID" : 212,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6515151515151514,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 99.49713001694124,
        "y" : 32.42134539120258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "210",
        "ClosenessCentrality" : 0.27385892116182575,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8440285204991087,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Star 2",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Star 2",
        "SelfLoops" : 0,
        "SUID" : 210,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6515151515151514,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 152.34650997150004,
        "y" : 40.15041432694977
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "209",
        "ClosenessCentrality" : 0.375,
        "Eccentricity" : 6,
        "Degree" : 21,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9019607843137255,
        "Stress" : 3582,
        "TopologicalCoefficient" : 0.07692307692307693,
        "shared_name" : "Naminé",
        "BetweennessCentrality" : 0.4172494172494173,
        "NumberOfUndirectedEdges" : 21,
        "name" : "Naminé",
        "SelfLoops" : 0,
        "SUID" : 209,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6666666666666665,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.5384615384615383
      },
      "position" : {
        "x" : 112.73684018452582,
        "y" : 126.44137121883631
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "ClosenessCentrality" : 0.25287356321839083,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8262032085561497,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Ansem",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Ansem",
        "SelfLoops" : 0,
        "SUID" : 206,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.9545454545454546,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 8.083014740854026,
        "y" : -108.13171689950553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "203",
        "ClosenessCentrality" : 0.26720647773279355,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 1.0,
        "Radiality" : 0.8386809269162211,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.75,
        "shared_name" : "Riku",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "name" : "Riku",
        "SelfLoops" : 0,
        "SUID" : 203,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.742424242424242,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.5
      },
      "position" : {
        "x" : -48.501727084040084,
        "y" : -99.708007775035
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "ClosenessCentrality" : 0.336734693877551,
        "Eccentricity" : 6,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.3333333333333333,
        "Radiality" : 0.8841354723707665,
        "Stress" : 262,
        "TopologicalCoefficient" : 0.3,
        "shared_name" : "Mickey",
        "BetweennessCentrality" : 0.04071484071484072,
        "NumberOfUndirectedEdges" : 5,
        "name" : "Mickey",
        "SelfLoops" : 0,
        "SUID" : 202,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.9696969696969697,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.25
      },
      "position" : {
        "x" : -34.06739619005182,
        "y" : -52.85841870594085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "ClosenessCentrality" : 0.1970149253731343,
        "Eccentricity" : 8,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.7602495543672014,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Aerith",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Aerith",
        "SelfLoops" : 0,
        "SUID" : 200,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.075757575757576,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -111.6739619287265,
        "y" : -303.13171689950553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "ClosenessCentrality" : 0.1970149253731343,
        "Eccentricity" : 8,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.7602495543672014,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Sora, Donald, and Goofy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Sora, Donald, and Goofy",
        "SelfLoops" : 0,
        "SUID" : 198,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.075757575757576,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -208.77735746514648,
        "y" : -262.1936114532692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "196",
        "ClosenessCentrality" : 0.1970149253731343,
        "Eccentricity" : 8,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.7602495543672014,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Yuffie",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Yuffie",
        "SelfLoops" : 0,
        "SUID" : 196,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.075757575757576,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -195.16000858956545,
        "y" : -351.3324084127185
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "194",
        "ClosenessCentrality" : 0.24444444444444444,
        "Eccentricity" : 7,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8181818181818182,
        "Stress" : 1740,
        "TopologicalCoefficient" : 0.25,
        "shared_name" : "Merlin",
        "BetweennessCentrality" : 0.08951048951048951,
        "NumberOfUndirectedEdges" : 4,
        "name" : "Merlin",
        "SelfLoops" : 0,
        "SUID" : 194,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.090909090909091,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.75
      },
      "position" : {
        "x" : -167.33132636928576,
        "y" : -303.13171689950553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "189",
        "ClosenessCentrality" : 0.19642857142857142,
        "Eccentricity" : 8,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.7593582887700535,
        "Stress" : 674,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "Hercules",
        "BetweennessCentrality" : 0.030303030303030304,
        "NumberOfUndirectedEdges" : 6,
        "name" : "Hercules",
        "SelfLoops" : 0,
        "SUID" : 189,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.090909090909091,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.5
      },
      "position" : {
        "x" : -293.6980729752795,
        "y" : -226.6830729344233
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "188",
        "ClosenessCentrality" : 0.16458852867830423,
        "Eccentricity" : 9,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.7014260249554367,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Meg",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "name" : "Meg",
        "SelfLoops" : 0,
        "SUID" : 188,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 6.075757575757576,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : -343.61159000146785,
        "y" : -292.6884826330979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Terra-Xehanort",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Terra-Xehanort",
        "SelfLoops" : 0,
        "SUID" : 185,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 267.5634022428381,
        "y" : 329.490446176874
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "184",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Lingering Will",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Lingering Will",
        "SelfLoops" : 0,
        "SUID" : 184,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 267.68582518320034,
        "y" : 280.98038840614583
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "182",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Kairi",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Kairi",
        "SelfLoops" : 0,
        "SUID" : 182,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 383.5886750271867,
        "y" : -34.638776742483465
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "181",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Lea",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Lea",
        "SelfLoops" : 0,
        "SUID" : 181,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 384.21005144395826,
        "y" : -104.67373083010851
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "179",
        "ClosenessCentrality" : 0.34736842105263155,
        "Eccentricity" : 5,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.6666666666666666,
        "Radiality" : 0.8894830659536542,
        "Stress" : 320,
        "TopologicalCoefficient" : 0.463768115942029,
        "shared_name" : "Yen Sid",
        "BetweennessCentrality" : 0.010123210123210115,
        "NumberOfUndirectedEdges" : 4,
        "name" : "Yen Sid",
        "SelfLoops" : 0,
        "SUID" : 179,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.878787878787879,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.666666666666666
      },
      "position" : {
        "x" : -150.91698525914597,
        "y" : -22.631716899505534
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "174",
        "ClosenessCentrality" : 0.2661290322580645,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8377896613190731,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Sora, Donald & Goofy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Sora, Donald & Goofy",
        "SelfLoops" : 0,
        "SUID" : 174,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.757575757575758,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : -296.0196973289815,
        "y" : -53.54252907635655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "172",
        "ClosenessCentrality" : 0.2661290322580645,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8377896613190731,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Jiminy Cricket",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Jiminy Cricket",
        "SelfLoops" : 0,
        "SUID" : 172,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.757575757575758,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : -299.7980801957777,
        "y" : 8.462880622318075
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "171",
        "ClosenessCentrality" : 0.360655737704918,
        "Eccentricity" : 5,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.13333333333333333,
        "Radiality" : 0.8957219251336898,
        "Stress" : 1128,
        "TopologicalCoefficient" : 0.2857142857142857,
        "shared_name" : "Jiminy",
        "BetweennessCentrality" : 0.08868908868908881,
        "NumberOfUndirectedEdges" : 6,
        "name" : "Jiminy",
        "SelfLoops" : 0,
        "SUID" : 171,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.772727272727273,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.5
      },
      "position" : {
        "x" : -196.6467169403617,
        "y" : -6.847924334034698
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "169",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Sally",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Sally",
        "SelfLoops" : 0,
        "SUID" : 169,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 302.70894192424475,
        "y" : 106.66759158728149
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "168",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Jack",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Jack",
        "SelfLoops" : 0,
        "SUID" : 168,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 302.53184468803255,
        "y" : 41.231284524268204
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "166",
        "ClosenessCentrality" : 0.6666666666666666,
        "Eccentricity" : 2,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.75,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Olette",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Olette",
        "SelfLoops" : 0,
        "SUID" : 166,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.5,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 447.9876809243616,
        "y" : -262.56143605059657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "164",
        "ClosenessCentrality" : 0.6666666666666666,
        "Eccentricity" : 2,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.75,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Pence",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Pence",
        "SelfLoops" : 0,
        "SUID" : 164,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.5,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : 446.57090303466407,
        "y" : -132.62401946786974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "163",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 2,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Hayner",
        "BetweennessCentrality" : 1.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Hayner",
        "SelfLoops" : 0,
        "SUID" : 163,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 447.0211916724252,
        "y" : -198.35082806632067
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "160",
        "ClosenessCentrality" : 0.34196891191709844,
        "Eccentricity" : 5,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8868092691622104,
        "Stress" : 336,
        "TopologicalCoefficient" : 0.5263157894736842,
        "shared_name" : "Hades",
        "BetweennessCentrality" : 0.03636363636363636,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Hades",
        "SelfLoops" : 0,
        "SUID" : 160,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.9242424242424243,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : -220.11159000146782,
        "y" : 20.83315616160057
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "157",
        "ClosenessCentrality" : 0.2,
        "Eccentricity" : 8,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.7647058823529411,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Pooh",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Pooh",
        "SelfLoops" : 0,
        "SUID" : 157,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : -187.41698525914597,
        "y" : 186.36828310049447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "155",
        "ClosenessCentrality" : 0.3235294117647059,
        "Eccentricity" : 6,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.877005347593583,
        "Stress" : 704,
        "TopologicalCoefficient" : 0.35294117647058826,
        "shared_name" : "Piglet",
        "BetweennessCentrality" : 0.05920745920745921,
        "NumberOfUndirectedEdges" : 4,
        "name" : "Piglet",
        "SelfLoops" : 0,
        "SUID" : 155,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.090909090909091,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -110.91698525914597,
        "y" : 91.36828310049447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "153",
        "ClosenessCentrality" : 0.32038834951456313,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.875222816399287,
        "Stress" : 464,
        "TopologicalCoefficient" : 0.5294117647058824,
        "shared_name" : "Lumpy",
        "BetweennessCentrality" : 0.028904428904428903,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Lumpy",
        "SelfLoops" : 0,
        "SUID" : 153,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.121212121212121,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : -140.41698525914597,
        "y" : 66.36828310049447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "152",
        "ClosenessCentrality" : 0.24905660377358488,
        "Eccentricity" : 7,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8226381461675579,
        "Stress" : 474,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "Gopher",
        "BetweennessCentrality" : 0.03076923076923077,
        "NumberOfUndirectedEdges" : 4,
        "name" : "Gopher",
        "SelfLoops" : 0,
        "SUID" : 152,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.015151515151516,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : -157.41698525914597,
        "y" : 128.86828310049447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "148",
        "ClosenessCentrality" : 0.16136919315403422,
        "Eccentricity" : 9,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.6942959001782532,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Gibbs",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "name" : "Gibbs",
        "SelfLoops" : 0,
        "SUID" : 148,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 6.196969696969697,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : -417.416985259146,
        "y" : -132.63171689950553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "145",
        "ClosenessCentrality" : 0.26720647773279355,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8386809269162211,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Hiro",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Hiro",
        "SelfLoops" : 0,
        "SUID" : 145,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.742424242424242,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : -28.158733111898187,
        "y" : -157.63171689950553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "139",
        "ClosenessCentrality" : 0.26720647773279355,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8386809269162211,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Fred",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Fred",
        "SelfLoops" : 0,
        "SUID" : 139,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.742424242424242,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : -40.71966297336997,
        "y" : -205.92088425183928
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "137",
        "ClosenessCentrality" : 0.26720647773279355,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8386809269162211,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Go Go",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Go Go",
        "SelfLoops" : 0,
        "SUID" : 137,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.742424242424242,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : -114.67523740639376,
        "y" : -207.58204394327794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "136",
        "ClosenessCentrality" : 0.3626373626373626,
        "Eccentricity" : 5,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8966131907308378,
        "Stress" : 1288,
        "TopologicalCoefficient" : 0.2719298245614035,
        "shared_name" : "Everyone",
        "BetweennessCentrality" : 0.11572871572871593,
        "NumberOfUndirectedEdges" : 8,
        "name" : "Everyone",
        "SelfLoops" : 0,
        "SUID" : 136,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.757575757575758,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.166666666666667
      },
      "position" : {
        "x" : -85.8364026415619,
        "y" : -157.63171689950553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "134",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Sora, Donald, Goofy, Riku & Mickey",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Sora, Donald, Goofy, Riku & Mickey",
        "SelfLoops" : 0,
        "SUID" : 134,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 248.02922432884003,
        "y" : -7.892078211204007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "133",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Elsa",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Elsa",
        "SelfLoops" : 0,
        "SUID" : 133,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 249.02205553573427,
        "y" : -143.52062838420002
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "127",
        "ClosenessCentrality" : 0.358695652173913,
        "Eccentricity" : 5,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.3333333333333333,
        "Radiality" : 0.8948306595365418,
        "Stress" : 1096,
        "TopologicalCoefficient" : 0.4318181818181818,
        "shared_name" : "Donald & Goofy",
        "BetweennessCentrality" : 0.06258186258186253,
        "NumberOfUndirectedEdges" : 5,
        "name" : "Donald & Goofy",
        "SelfLoops" : 0,
        "SUID" : 127,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.787878787878788,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.75
      },
      "position" : {
        "x" : -189.02730059962843,
        "y" : -63.68926008159575
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "123",
        "ClosenessCentrality" : 0.24175824175824173,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8155080213903743,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Larxene",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Larxene",
        "SelfLoops" : 0,
        "SUID" : 123,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.136363636363637,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : -7.057475058599627,
        "y" : -21.27220669895918
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "122",
        "ClosenessCentrality" : 0.31730769230769235,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8734402852049911,
        "Stress" : 242,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "Demyx",
        "BetweennessCentrality" : 0.030303030303030304,
        "NumberOfUndirectedEdges" : 3,
        "name" : "Demyx",
        "SelfLoops" : 0,
        "SUID" : 122,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.1515151515151514,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : -37.916985259145974,
        "y" : 12.868283100494466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "117",
        "ClosenessCentrality" : 0.3113207547169812,
        "Eccentricity" : 6,
        "Degree" : 11,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.05555555555555555,
        "Radiality" : 0.8698752228163994,
        "Stress" : 2252,
        "TopologicalCoefficient" : 0.2222222222222222,
        "shared_name" : "Goofy",
        "BetweennessCentrality" : 0.11149961149961148,
        "NumberOfUndirectedEdges" : 11,
        "name" : "Goofy",
        "SelfLoops" : 0,
        "SUID" : 117,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.212121212121212,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.111111111111111
      },
      "position" : {
        "x" : -210.6115900014678,
        "y" : -141.6479459955294
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "115",
        "ClosenessCentrality" : 0.3127962085308057,
        "Eccentricity" : 6,
        "Degree" : 13,
        "PartnerOfMultiEdgedNodePairs" : 4,
        "ClusteringCoefficient" : 0.03571428571428571,
        "Radiality" : 0.8707664884135472,
        "Stress" : 2520,
        "TopologicalCoefficient" : 0.22058823529411764,
        "shared_name" : "Donald",
        "BetweennessCentrality" : 0.13512043512043512,
        "NumberOfUndirectedEdges" : 13,
        "name" : "Donald",
        "SelfLoops" : 0,
        "SUID" : 115,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.196969696969697,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.5
      },
      "position" : {
        "x" : -154.10554162781654,
        "y" : -109.61264418062316
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "114",
        "ClosenessCentrality" : 0.35106382978723405,
        "Eccentricity" : 5,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8912655971479502,
        "Stress" : 760,
        "TopologicalCoefficient" : 0.543859649122807,
        "shared_name" : "Dark Riku",
        "BetweennessCentrality" : 0.02621822621822618,
        "NumberOfUndirectedEdges" : 5,
        "name" : "Dark Riku",
        "SelfLoops" : 0,
        "SUID" : 114,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.8484848484848486,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.333333333333334
      },
      "position" : {
        "x" : -131.35983445612334,
        "y" : -43.99497437934302
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "112",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Boy in White",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Boy in White",
        "SelfLoops" : 0,
        "SUID" : 112,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 422.4853914948123,
        "y" : 211.56452628329902
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "111",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Boy in Black",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Boy in Black",
        "SelfLoops" : 0,
        "SUID" : 111,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 422.6787597353217,
        "y" : 153.5703879022311
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "108",
        "ClosenessCentrality" : 0.3283582089552239,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8796791443850268,
        "Stress" : 412,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "Baymax",
        "BetweennessCentrality" : 0.04382284382284382,
        "NumberOfUndirectedEdges" : 2,
        "name" : "Baymax",
        "SelfLoops" : 0,
        "SUID" : 108,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.0454545454545454,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : -64.91698525914597,
        "y" : 97.36828310049447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "105",
        "ClosenessCentrality" : 0.3,
        "Eccentricity" : 6,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 3,
        "ClusteringCoefficient" : 0.2,
        "Radiality" : 0.8627450980392156,
        "Stress" : 792,
        "TopologicalCoefficient" : 0.35384615384615387,
        "shared_name" : "Pete",
        "BetweennessCentrality" : 0.09387279387279389,
        "NumberOfUndirectedEdges" : 8,
        "name" : "Pete",
        "SelfLoops" : 0,
        "SUID" : 105,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3333333333333335,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -251.1088851521305,
        "y" : -96.09118026193701
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "103",
        "ClosenessCentrality" : 0.19186046511627908,
        "Eccentricity" : 8,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.75222816399287,
        "Stress" : 248,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "Jack Sparrow",
        "BetweennessCentrality" : 0.030303030303030304,
        "NumberOfUndirectedEdges" : 4,
        "name" : "Jack Sparrow",
        "SelfLoops" : 0,
        "SUID" : 103,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.212121212121212,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.5
      },
      "position" : {
        "x" : -359.916985259146,
        "y" : -119.13171689950553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "102",
        "ClosenessCentrality" : 0.23487544483985764,
        "Eccentricity" : 7,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8083778966131907,
        "Stress" : 492,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "Barbossa",
        "BetweennessCentrality" : 0.059673659673659674,
        "NumberOfUndirectedEdges" : 3,
        "name" : "Barbossa",
        "SelfLoops" : 0,
        "SUID" : 102,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.257575757575758,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.5
      },
      "position" : {
        "x" : -294.916985259146,
        "y" : -103.63171689950553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "100",
        "ClosenessCentrality" : 0.22525597269624573,
        "Eccentricity" : 8,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.7976827094474154,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Axel",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Axel",
        "SelfLoops" : 0,
        "SUID" : 100,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.4393939393939394,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 51.083014740854026,
        "y" : 286.86828310049447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "92",
        "ClosenessCentrality" : 0.19879518072289157,
        "Eccentricity" : 8,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.7629233511586452,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Aqua",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 5,
        "name" : "Aqua",
        "SelfLoops" : 0,
        "SUID" : 92,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.03030303030303,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : -317.416985259146,
        "y" : 106.36828310049447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "89",
        "ClosenessCentrality" : 0.24719101123595502,
        "Eccentricity" : 7,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.820855614973262,
        "Stress" : 242,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "Ansem the Wise",
        "BetweennessCentrality" : 0.030303030303030304,
        "NumberOfUndirectedEdges" : 9,
        "name" : "Ansem the Wise",
        "SelfLoops" : 0,
        "SUID" : 89,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.045454545454546,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : -259.916985259146,
        "y" : 74.86828310049441
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "86",
        "ClosenessCentrality" : 0.2453531598513011,
        "Eccentricity" : 7,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8190730837789661,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Woody",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "name" : "Woody",
        "SelfLoops" : 0,
        "SUID" : 86,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.075757575757576,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : -217.91698525914597,
        "y" : 105.86828310049447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84",
        "ClosenessCentrality" : 0.3235294117647059,
        "Eccentricity" : 6,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.877005347593583,
        "Stress" : 718,
        "TopologicalCoefficient" : 0.3333333333333333,
        "shared_name" : "????????",
        "BetweennessCentrality" : 0.08904428904428904,
        "NumberOfUndirectedEdges" : 7,
        "name" : "????????",
        "SelfLoops" : 0,
        "SUID" : 84,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.090909090909091,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.666666666666667
      },
      "position" : {
        "x" : -186.41698525914597,
        "y" : 52.368283100494466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "77",
        "ClosenessCentrality" : 0.2509505703422053,
        "Eccentricity" : 7,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8244206773618539,
        "Stress" : 480,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "??????",
        "BetweennessCentrality" : 0.059673659673659674,
        "NumberOfUndirectedEdges" : 7,
        "name" : "??????",
        "SelfLoops" : 0,
        "SUID" : 77,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.984848484848485,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.5
      },
      "position" : {
        "x" : 64.08301474085403,
        "y" : -91.13171689950548
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "75",
        "ClosenessCentrality" : 0.45517241379310347,
        "Eccentricity" : 5,
        "Degree" : 29,
        "PartnerOfMultiEdgedNodePairs" : 6,
        "ClusteringCoefficient" : 0.014705882352941176,
        "Radiality" : 0.9295900178253119,
        "Stress" : 7788,
        "TopologicalCoefficient" : 0.08996539792387544,
        "shared_name" : "Sora",
        "BetweennessCentrality" : 0.7461538461538463,
        "NumberOfUndirectedEdges" : 29,
        "name" : "Sora",
        "SelfLoops" : 0,
        "SUID" : 75,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.196969696969697,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.823529411764706
      },
      "position" : {
        "x" : -97.91698525914597,
        "y" : 1.868283100494466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "74",
        "ClosenessCentrality" : 0.32673267326732675,
        "Eccentricity" : 6,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 2,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8787878787878788,
        "Stress" : 950,
        "TopologicalCoefficient" : 0.3333333333333333,
        "shared_name" : "?????",
        "BetweennessCentrality" : 0.11701631701631701,
        "NumberOfUndirectedEdges" : 10,
        "name" : "?????",
        "SelfLoops" : 0,
        "SUID" : 74,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.0606060606060606,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.666666666666667
      },
      "position" : {
        "x" : -4.916985259145974,
        "y" : -45.131716899505534
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "72",
        "ClosenessCentrality" : 0.2894736842105263,
        "Eccentricity" : 7,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8556149732620321,
        "Stress" : 1002,
        "TopologicalCoefficient" : 0.2,
        "shared_name" : "Roxas",
        "BetweennessCentrality" : 0.12913752913752913,
        "NumberOfUndirectedEdges" : 7,
        "name" : "Roxas",
        "SelfLoops" : 0,
        "SUID" : 72,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4545454545454546,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -4.916985259145974,
        "y" : 274.36828310049447
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "71",
        "ClosenessCentrality" : 0.27272727272727276,
        "Eccentricity" : 7,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.8431372549019608,
        "Stress" : 252,
        "TopologicalCoefficient" : 0.3333333333333333,
        "shared_name" : "????",
        "BetweennessCentrality" : 0.03263403263403263,
        "NumberOfUndirectedEdges" : 4,
        "name" : "????",
        "SelfLoops" : 0,
        "SUID" : 71,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6666666666666665,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.6666666666666665
      },
      "position" : {
        "x" : -43.916985259145974,
        "y" : 182.86828310049447
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "301",
        "source" : "300",
        "target" : "75",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Young Xehanort (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Young Xehanort (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 301,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "source" : "288",
        "target" : "289",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Xion (afterCut-1) Xemnas",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Xion (afterCut-1) Xemnas",
        "interaction" : "afterCut-1",
        "SUID" : 296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "295",
        "source" : "288",
        "target" : "72",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "Xion (afterCut-1) Roxas",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Xion (afterCut-1) Roxas",
        "interaction" : "afterCut-1",
        "SUID" : 295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "source" : "288",
        "target" : "289",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Xion (afterCut-1) Xemnas",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Xion (afterCut-1) Xemnas",
        "interaction" : "afterCut-1",
        "SUID" : 294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "source" : "288",
        "target" : "72",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "Xion (afterCut-1) Roxas",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Xion (afterCut-1) Roxas",
        "interaction" : "afterCut-1",
        "SUID" : 293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "source" : "288",
        "target" : "289",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Xion (afterCut-1) Xemnas",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Xion (afterCut-1) Xemnas",
        "interaction" : "afterCut-1",
        "SUID" : 292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "291",
        "source" : "288",
        "target" : "72",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "Xion (afterCut-1) Roxas",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Xion (afterCut-1) Roxas",
        "interaction" : "afterCut-1",
        "SUID" : 291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "source" : "288",
        "target" : "289",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Xion (afterCut-1) Xemnas",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Xion (afterCut-1) Xemnas",
        "interaction" : "afterCut-1",
        "SUID" : 290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "287",
        "source" : "286",
        "target" : "72",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Woman (afterCut-5) Roxas",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-5",
        "name" : "Woman (afterCut-5) Roxas",
        "interaction" : "afterCut-5",
        "SUID" : 287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "source" : "281",
        "target" : "77",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "Vexen (afterCut-10) ??????",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-10",
        "name" : "Vexen (afterCut-10) ??????",
        "interaction" : "afterCut-10",
        "SUID" : 285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "source" : "281",
        "target" : "282",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Vexen (afterCut-1) Luxord",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Vexen (afterCut-1) Luxord",
        "interaction" : "afterCut-1",
        "SUID" : 284,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "source" : "281",
        "target" : "282",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Vexen (afterCut-1) Luxord",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Vexen (afterCut-1) Luxord",
        "interaction" : "afterCut-1",
        "SUID" : 283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "280",
        "source" : "276",
        "target" : "279",
        "EdgeBetweenness" : 4.0,
        "shared_name" : "Tia Dalma (afterCut-1) Elizabeth",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Tia Dalma (afterCut-1) Elizabeth",
        "interaction" : "afterCut-1",
        "SUID" : 280,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "source" : "276",
        "target" : "277",
        "EdgeBetweenness" : 4.0,
        "shared_name" : "Tia Dalma (afterCut-1) Will",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Tia Dalma (afterCut-1) Will",
        "interaction" : "afterCut-1",
        "SUID" : 278,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "source" : "273",
        "target" : "71",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Sulley (afterCut-1) ????",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Sulley (afterCut-1) ????",
        "interaction" : "afterCut-1",
        "SUID" : 275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "source" : "273",
        "target" : "71",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Sulley (afterCut-1) ????",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Sulley (afterCut-1) ????",
        "interaction" : "afterCut-1",
        "SUID" : 274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "source" : "268",
        "target" : "189",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "Sora & Donald (afterCut-3) Hercules",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-3",
        "name" : "Sora & Donald (afterCut-3) Hercules",
        "interaction" : "afterCut-3",
        "SUID" : 272,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "271",
        "source" : "268",
        "target" : "117",
        "EdgeBetweenness" : 384.0,
        "shared_name" : "Sora & Donald (afterCut-3) Goofy",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-3",
        "name" : "Sora & Donald (afterCut-3) Goofy",
        "interaction" : "afterCut-3",
        "SUID" : 271,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "source" : "268",
        "target" : "189",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "Sora & Donald (afterCut-3) Hercules",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-3",
        "name" : "Sora & Donald (afterCut-3) Hercules",
        "interaction" : "afterCut-3",
        "SUID" : 270,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "269",
        "source" : "268",
        "target" : "117",
        "EdgeBetweenness" : 384.0,
        "shared_name" : "Sora & Donald (afterCut-1) Goofy",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Sora & Donald (afterCut-1) Goofy",
        "interaction" : "afterCut-1",
        "SUID" : 269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "267",
        "source" : "262",
        "target" : "115",
        "EdgeBetweenness" : 90.21428571428562,
        "shared_name" : "Scrooge (afterCut-18) Donald",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-18",
        "name" : "Scrooge (afterCut-18) Donald",
        "interaction" : "afterCut-18",
        "SUID" : 267,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "source" : "262",
        "target" : "117",
        "EdgeBetweenness" : 69.30952380952374,
        "shared_name" : "Scrooge (afterCut-18) Goofy",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-18",
        "name" : "Scrooge (afterCut-18) Goofy",
        "interaction" : "afterCut-18",
        "SUID" : 266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "source" : "262",
        "target" : "75",
        "EdgeBetweenness" : 197.42857142857116,
        "shared_name" : "Scrooge (afterCut-18) Sora",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-18",
        "name" : "Scrooge (afterCut-18) Sora",
        "interaction" : "afterCut-18",
        "SUID" : 265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "264",
        "source" : "262",
        "target" : "115",
        "EdgeBetweenness" : 90.21428571428562,
        "shared_name" : "Scrooge (afterCut-18) Donald",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-18",
        "name" : "Scrooge (afterCut-18) Donald",
        "interaction" : "afterCut-18",
        "SUID" : 264,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "source" : "262",
        "target" : "75",
        "EdgeBetweenness" : 197.42857142857116,
        "shared_name" : "Scrooge (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Scrooge (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "261",
        "source" : "258",
        "target" : "74",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Saïx (afterCut-1) ?????",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Saïx (afterCut-1) ?????",
        "interaction" : "afterCut-1",
        "SUID" : 261,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "source" : "258",
        "target" : "74",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Saïx (afterCut-1) ?????",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Saïx (afterCut-1) ?????",
        "interaction" : "afterCut-1",
        "SUID" : 260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "259",
        "source" : "258",
        "target" : "74",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Saïx (afterCut-1) ?????",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Saïx (afterCut-1) ?????",
        "interaction" : "afterCut-1",
        "SUID" : 259,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "source" : "255",
        "target" : "256",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Sarge (afterCut-1) Rex",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Sarge (afterCut-1) Rex",
        "interaction" : "afterCut-1",
        "SUID" : 257,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "source" : "249",
        "target" : "203",
        "EdgeBetweenness" : 83.33333333333334,
        "shared_name" : "Riku & Mickey (afterCut-1) Riku",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Riku & Mickey (afterCut-1) Riku",
        "interaction" : "afterCut-1",
        "SUID" : 254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "253",
        "source" : "249",
        "target" : "202",
        "EdgeBetweenness" : 48.0,
        "shared_name" : "Riku & Mickey (afterCut-1) Mickey",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Riku & Mickey (afterCut-1) Mickey",
        "interaction" : "afterCut-1",
        "SUID" : 253,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "252",
        "source" : "249",
        "target" : "75",
        "EdgeBetweenness" : 237.09523809523785,
        "shared_name" : "Riku & Mickey (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Riku & Mickey (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 252,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "source" : "249",
        "target" : "117",
        "EdgeBetweenness" : 106.4761904761904,
        "shared_name" : "Riku & Mickey (afterCut-1) Goofy",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Riku & Mickey (afterCut-1) Goofy",
        "interaction" : "afterCut-1",
        "SUID" : 251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "250",
        "source" : "249",
        "target" : "115",
        "EdgeBetweenness" : 132.71428571428564,
        "shared_name" : "Riku & Mickey (afterCut-1) Donald",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Riku & Mickey (afterCut-1) Donald",
        "interaction" : "afterCut-1",
        "SUID" : 250,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "241",
        "source" : "209",
        "target" : "72",
        "EdgeBetweenness" : 638.0,
        "shared_name" : "Naminé (afterCut-6) Roxas",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-6",
        "name" : "Naminé (afterCut-6) Roxas",
        "interaction" : "afterCut-6",
        "SUID" : 241,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "source" : "209",
        "target" : "75",
        "EdgeBetweenness" : 1622.0,
        "shared_name" : "Naminé (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "239",
        "source" : "209",
        "target" : "75",
        "EdgeBetweenness" : 1622.0,
        "shared_name" : "Naminé (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 239,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "238",
        "source" : "209",
        "target" : "75",
        "EdgeBetweenness" : 1622.0,
        "shared_name" : "Naminé (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "237",
        "source" : "209",
        "target" : "75",
        "EdgeBetweenness" : 1622.0,
        "shared_name" : "Naminé (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 237,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "source" : "209",
        "target" : "75",
        "EdgeBetweenness" : 1622.0,
        "shared_name" : "Naminé (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "235",
        "source" : "209",
        "target" : "75",
        "EdgeBetweenness" : 1622.0,
        "shared_name" : "Naminé (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "source" : "209",
        "target" : "75",
        "EdgeBetweenness" : 1622.0,
        "shared_name" : "Naminé (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "source" : "209",
        "target" : "230",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Naminé (afterCut-1) Star 13",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Star 13",
        "interaction" : "afterCut-1",
        "SUID" : 233,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "232",
        "source" : "209",
        "target" : "75",
        "EdgeBetweenness" : 1622.0,
        "shared_name" : "Naminé (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "231",
        "source" : "209",
        "target" : "230",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Naminé (afterCut-1) Star 13",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Star 13",
        "interaction" : "afterCut-1",
        "SUID" : 231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "229",
        "source" : "209",
        "target" : "228",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Naminé (afterCut-1) Star 12",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Star 12",
        "interaction" : "afterCut-1",
        "SUID" : 229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "227",
        "source" : "209",
        "target" : "226",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Naminé (afterCut-1) Star 10",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Star 10",
        "interaction" : "afterCut-1",
        "SUID" : 227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "225",
        "source" : "209",
        "target" : "224",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Naminé (afterCut-1) Star 9",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Star 9",
        "interaction" : "afterCut-1",
        "SUID" : 225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "223",
        "source" : "209",
        "target" : "222",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Naminé (afterCut-1) Star 8",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Star 8",
        "interaction" : "afterCut-1",
        "SUID" : 223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "221",
        "source" : "209",
        "target" : "220",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Naminé (afterCut-1) Star 7",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Star 7",
        "interaction" : "afterCut-1",
        "SUID" : 221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "219",
        "source" : "209",
        "target" : "218",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Naminé (afterCut-1) Star 6",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Star 6",
        "interaction" : "afterCut-1",
        "SUID" : 219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "217",
        "source" : "209",
        "target" : "216",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Naminé (afterCut-1) Star 5",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Star 5",
        "interaction" : "afterCut-1",
        "SUID" : 217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "215",
        "source" : "209",
        "target" : "214",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Naminé (afterCut-1) Star 4",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Star 4",
        "interaction" : "afterCut-1",
        "SUID" : 215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "213",
        "source" : "209",
        "target" : "212",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Naminé (afterCut-1) Star 3",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Star 3",
        "interaction" : "afterCut-1",
        "SUID" : 213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "source" : "209",
        "target" : "210",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Naminé (afterCut-1) Star 2",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Naminé (afterCut-1) Star 2",
        "interaction" : "afterCut-1",
        "SUID" : 211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "source" : "202",
        "target" : "75",
        "EdgeBetweenness" : 252.66666666666666,
        "shared_name" : "Mickey (afterCut-92) Sora",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-92",
        "name" : "Mickey (afterCut-92) Sora",
        "interaction" : "afterCut-92",
        "SUID" : 208,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "207",
        "source" : "202",
        "target" : "206",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Mickey (afterCut-92) Ansem",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-92",
        "name" : "Mickey (afterCut-92) Ansem",
        "interaction" : "afterCut-92",
        "SUID" : 207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "205",
        "source" : "202",
        "target" : "203",
        "EdgeBetweenness" : 48.66666666666667,
        "shared_name" : "Mickey (afterCut-1) Riku",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Mickey (afterCut-1) Riku",
        "interaction" : "afterCut-1",
        "SUID" : 205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "source" : "202",
        "target" : "203",
        "EdgeBetweenness" : 48.66666666666667,
        "shared_name" : "Mickey (afterCut-1) Riku",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Mickey (afterCut-1) Riku",
        "interaction" : "afterCut-1",
        "SUID" : 204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "201",
        "source" : "194",
        "target" : "200",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Merlin (afterCut-9) Aerith",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-9",
        "name" : "Merlin (afterCut-9) Aerith",
        "interaction" : "afterCut-9",
        "SUID" : 201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "199",
        "source" : "194",
        "target" : "198",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Merlin (afterCut-9) Sora, Donald, and Goofy",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-9",
        "name" : "Merlin (afterCut-9) Sora, Donald, and Goofy",
        "interaction" : "afterCut-9",
        "SUID" : 199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "197",
        "source" : "194",
        "target" : "196",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Merlin (afterCut-9) Yuffie",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-9",
        "name" : "Merlin (afterCut-9) Yuffie",
        "interaction" : "afterCut-9",
        "SUID" : 197,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "195",
        "source" : "194",
        "target" : "115",
        "EdgeBetweenness" : 504.0,
        "shared_name" : "Merlin (afterCut-9) Donald",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-9",
        "name" : "Merlin (afterCut-9) Donald",
        "interaction" : "afterCut-9",
        "SUID" : 195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "193",
        "source" : "188",
        "target" : "189",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Meg (afterCut-1) Hercules",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Meg (afterCut-1) Hercules",
        "interaction" : "afterCut-1",
        "SUID" : 193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "192",
        "source" : "188",
        "target" : "189",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Meg (afterCut-1) Hercules",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Meg (afterCut-1) Hercules",
        "interaction" : "afterCut-1",
        "SUID" : 192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "191",
        "source" : "188",
        "target" : "189",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Meg (afterCut-1) Hercules",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Meg (afterCut-1) Hercules",
        "interaction" : "afterCut-1",
        "SUID" : 191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "source" : "188",
        "target" : "189",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Meg (afterCut-1) Hercules",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Meg (afterCut-1) Hercules",
        "interaction" : "afterCut-1",
        "SUID" : 190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "186",
        "source" : "184",
        "target" : "185",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Lingering Will (afterCut-1) Terra-Xehanort",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Lingering Will (afterCut-1) Terra-Xehanort",
        "interaction" : "afterCut-1",
        "SUID" : 186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "source" : "181",
        "target" : "182",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Lea (afterCut-1) Kairi",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Lea (afterCut-1) Kairi",
        "interaction" : "afterCut-1",
        "SUID" : 183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "source" : "179",
        "target" : "75",
        "EdgeBetweenness" : 134.7619047619048,
        "shared_name" : "Yen Sid (afterCut-27) Sora",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-27",
        "name" : "Yen Sid (afterCut-27) Sora",
        "interaction" : "afterCut-27",
        "SUID" : 299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "source" : "179",
        "target" : "75",
        "EdgeBetweenness" : 134.7619047619048,
        "shared_name" : "Yen Sid (afterCut-27) Sora",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-27",
        "name" : "Yen Sid (afterCut-27) Sora",
        "interaction" : "afterCut-27",
        "SUID" : 298,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "297",
        "source" : "179",
        "target" : "117",
        "EdgeBetweenness" : 68.09523809523807,
        "shared_name" : "Yen Sid (afterCut-27) Goofy",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-27",
        "name" : "Yen Sid (afterCut-27) Goofy",
        "interaction" : "afterCut-27",
        "SUID" : 297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "180",
        "source" : "171",
        "target" : "179",
        "EdgeBetweenness" : 16.0,
        "shared_name" : "Jiminy (afterCut-1) Yen Sid",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Jiminy (afterCut-1) Yen Sid",
        "interaction" : "afterCut-1",
        "SUID" : 180,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "178",
        "source" : "171",
        "target" : "115",
        "EdgeBetweenness" : 138.54761904761898,
        "shared_name" : "Jiminy (afterCut-1) Donald",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Jiminy (afterCut-1) Donald",
        "interaction" : "afterCut-1",
        "SUID" : 178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177",
        "source" : "171",
        "target" : "75",
        "EdgeBetweenness" : 371.76190476190516,
        "shared_name" : "Jiminy (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Jiminy (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176",
        "source" : "171",
        "target" : "117",
        "EdgeBetweenness" : 102.64285714285707,
        "shared_name" : "Jiminy (afterCut-1) Goofy",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Jiminy (afterCut-1) Goofy",
        "interaction" : "afterCut-1",
        "SUID" : 176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "175",
        "source" : "171",
        "target" : "174",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Jiminy (afterCut-1) Sora, Donald & Goofy",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Jiminy (afterCut-1) Sora, Donald & Goofy",
        "interaction" : "afterCut-1",
        "SUID" : 175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "173",
        "source" : "171",
        "target" : "172",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Jiminy (afterCut-1) Jiminy Cricket",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Jiminy (afterCut-1) Jiminy Cricket",
        "interaction" : "afterCut-1",
        "SUID" : 173,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "170",
        "source" : "168",
        "target" : "169",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Jack (afterCut-37) Sally",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-37",
        "name" : "Jack (afterCut-37) Sally",
        "interaction" : "afterCut-37",
        "SUID" : 170,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "167",
        "source" : "163",
        "target" : "166",
        "EdgeBetweenness" : 4.0,
        "shared_name" : "Hayner (afterCut-30) Olette",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-30",
        "name" : "Hayner (afterCut-30) Olette",
        "interaction" : "afterCut-30",
        "SUID" : 167,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "165",
        "source" : "163",
        "target" : "164",
        "EdgeBetweenness" : 4.0,
        "shared_name" : "Hayner (afterCut-30) Pence",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-30",
        "name" : "Hayner (afterCut-30) Pence",
        "interaction" : "afterCut-30",
        "SUID" : 165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "162",
        "source" : "160",
        "target" : "105",
        "EdgeBetweenness" : 183.0,
        "shared_name" : "Hades (afterCut-25) Pete",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-25",
        "name" : "Hades (afterCut-25) Pete",
        "interaction" : "afterCut-25",
        "SUID" : 162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "161",
        "source" : "160",
        "target" : "75",
        "EdgeBetweenness" : 261.0,
        "shared_name" : "Hades (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Hades (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "source" : "155",
        "target" : "75",
        "EdgeBetweenness" : 374.0,
        "shared_name" : "Piglet (afterCut-5) Sora",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-5",
        "name" : "Piglet (afterCut-5) Sora",
        "interaction" : "afterCut-5",
        "SUID" : 248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "247",
        "source" : "155",
        "target" : "246",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Piglet (afterCut-5) Cloud",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-5",
        "name" : "Piglet (afterCut-5) Cloud",
        "interaction" : "afterCut-5",
        "SUID" : 247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "source" : "155",
        "target" : "75",
        "EdgeBetweenness" : 374.0,
        "shared_name" : "Piglet (afterCut-5) Sora",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-5",
        "name" : "Piglet (afterCut-5) Sora",
        "interaction" : "afterCut-5",
        "SUID" : 245,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "187",
        "source" : "153",
        "target" : "75",
        "EdgeBetweenness" : 250.0,
        "shared_name" : "Lumpy (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Lumpy (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "159",
        "source" : "152",
        "target" : "157",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Gopher (afterCut-6) Pooh",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-6",
        "name" : "Gopher (afterCut-6) Pooh",
        "interaction" : "afterCut-6",
        "SUID" : 159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "158",
        "source" : "152",
        "target" : "157",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Gopher (afterCut-6) Pooh",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-6",
        "name" : "Gopher (afterCut-6) Pooh",
        "interaction" : "afterCut-6",
        "SUID" : 158,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "156",
        "source" : "152",
        "target" : "155",
        "EdgeBetweenness" : 134.0,
        "shared_name" : "Gopher (afterCut-1) Piglet",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Gopher (afterCut-1) Piglet",
        "interaction" : "afterCut-1",
        "SUID" : 156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "154",
        "source" : "152",
        "target" : "153",
        "EdgeBetweenness" : 130.0,
        "shared_name" : "Gopher (afterCut-1) Lumpy",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Gopher (afterCut-1) Lumpy",
        "interaction" : "afterCut-1",
        "SUID" : 154,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "151",
        "source" : "148",
        "target" : "103",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Gibbs (afterCut-1) Jack Sparrow",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Gibbs (afterCut-1) Jack Sparrow",
        "interaction" : "afterCut-1",
        "SUID" : 151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "150",
        "source" : "148",
        "target" : "103",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Gibbs (afterCut-1) Jack Sparrow",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Gibbs (afterCut-1) Jack Sparrow",
        "interaction" : "afterCut-1",
        "SUID" : 150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "149",
        "source" : "148",
        "target" : "103",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Gibbs (afterCut-1) Jack Sparrow",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Gibbs (afterCut-1) Jack Sparrow",
        "interaction" : "afterCut-1",
        "SUID" : 149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "147",
        "source" : "136",
        "target" : "115",
        "EdgeBetweenness" : 145.71428571428575,
        "shared_name" : "Everyone (afterCut-5) Donald",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-5",
        "name" : "Everyone (afterCut-5) Donald",
        "interaction" : "afterCut-5",
        "SUID" : 147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "146",
        "source" : "136",
        "target" : "145",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Everyone (afterCut-1) Hiro",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Everyone (afterCut-1) Hiro",
        "interaction" : "afterCut-1",
        "SUID" : 146,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "144",
        "source" : "136",
        "target" : "115",
        "EdgeBetweenness" : 145.71428571428575,
        "shared_name" : "Everyone (afterCut-1) Donald",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Everyone (afterCut-1) Donald",
        "interaction" : "afterCut-1",
        "SUID" : 144,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "143",
        "source" : "136",
        "target" : "75",
        "EdgeBetweenness" : 461.42857142857184,
        "shared_name" : "Everyone (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Everyone (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "142",
        "source" : "136",
        "target" : "117",
        "EdgeBetweenness" : 121.8095238095237,
        "shared_name" : "Everyone (afterCut-1) Goofy",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Everyone (afterCut-1) Goofy",
        "interaction" : "afterCut-1",
        "SUID" : 142,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "141",
        "source" : "136",
        "target" : "115",
        "EdgeBetweenness" : 145.71428571428575,
        "shared_name" : "Everyone (afterCut-1) Donald",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Everyone (afterCut-1) Donald",
        "interaction" : "afterCut-1",
        "SUID" : 141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "140",
        "source" : "136",
        "target" : "139",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Everyone (afterCut-1) Fred",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Everyone (afterCut-1) Fred",
        "interaction" : "afterCut-1",
        "SUID" : 140,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "138",
        "source" : "136",
        "target" : "137",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Everyone (afterCut-1) Go Go",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Everyone (afterCut-1) Go Go",
        "interaction" : "afterCut-1",
        "SUID" : 138,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "135",
        "source" : "133",
        "target" : "134",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Elsa (afterCut-1) Sora, Donald, Goofy, Riku & Mickey",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Elsa (afterCut-1) Sora, Donald, Goofy, Riku & Mickey",
        "interaction" : "afterCut-1",
        "SUID" : 135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "132",
        "source" : "127",
        "target" : "117",
        "EdgeBetweenness" : 65.30952380952375,
        "shared_name" : "Donald & Goofy (afterCut-27) Goofy",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-27",
        "name" : "Donald & Goofy (afterCut-27) Goofy",
        "interaction" : "afterCut-27",
        "SUID" : 132,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "131",
        "source" : "127",
        "target" : "75",
        "EdgeBetweenness" : 352.42857142857144,
        "shared_name" : "Donald & Goofy (afterCut-27) Sora",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-27",
        "name" : "Donald & Goofy (afterCut-27) Sora",
        "interaction" : "afterCut-27",
        "SUID" : 131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "130",
        "source" : "127",
        "target" : "115",
        "EdgeBetweenness" : 86.21428571428561,
        "shared_name" : "Donald & Goofy (afterCut-27) Donald",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-27",
        "name" : "Donald & Goofy (afterCut-27) Donald",
        "interaction" : "afterCut-27",
        "SUID" : 130,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "129",
        "source" : "127",
        "target" : "105",
        "EdgeBetweenness" : 165.0,
        "shared_name" : "Donald & Goofy (afterCut-27) Pete",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-27",
        "name" : "Donald & Goofy (afterCut-27) Pete",
        "interaction" : "afterCut-27",
        "SUID" : 129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "128",
        "source" : "127",
        "target" : "105",
        "EdgeBetweenness" : 165.0,
        "shared_name" : "Donald & Goofy (afterCut-27) Pete",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-27",
        "name" : "Donald & Goofy (afterCut-27) Pete",
        "interaction" : "afterCut-27",
        "SUID" : 128,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "126",
        "source" : "122",
        "target" : "75",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "Demyx (afterCut-24) Sora",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-24",
        "name" : "Demyx (afterCut-24) Sora",
        "interaction" : "afterCut-24",
        "SUID" : 126,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "125",
        "source" : "122",
        "target" : "75",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "Demyx (afterCut-24) Sora",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-24",
        "name" : "Demyx (afterCut-24) Sora",
        "interaction" : "afterCut-24",
        "SUID" : 125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "124",
        "source" : "122",
        "target" : "123",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Demyx (afterCut-1) Larxene",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Demyx (afterCut-1) Larxene",
        "interaction" : "afterCut-1",
        "SUID" : 124,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "121",
        "source" : "114",
        "target" : "75",
        "EdgeBetweenness" : 197.42857142857116,
        "shared_name" : "Dark Riku (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Dark Riku (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "120",
        "source" : "114",
        "target" : "115",
        "EdgeBetweenness" : 90.21428571428561,
        "shared_name" : "Dark Riku (afterCut-1) Donald",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Dark Riku (afterCut-1) Donald",
        "interaction" : "afterCut-1",
        "SUID" : 120,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "119",
        "source" : "114",
        "target" : "117",
        "EdgeBetweenness" : 69.30952380952374,
        "shared_name" : "Dark Riku (afterCut-1) Goofy",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Dark Riku (afterCut-1) Goofy",
        "interaction" : "afterCut-1",
        "SUID" : 119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "118",
        "source" : "114",
        "target" : "117",
        "EdgeBetweenness" : 69.30952380952374,
        "shared_name" : "Dark Riku (afterCut-1) Goofy",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Dark Riku (afterCut-1) Goofy",
        "interaction" : "afterCut-1",
        "SUID" : 118,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "116",
        "source" : "114",
        "target" : "115",
        "EdgeBetweenness" : 90.21428571428561,
        "shared_name" : "Dark Riku (afterCut-1) Donald",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Dark Riku (afterCut-1) Donald",
        "interaction" : "afterCut-1",
        "SUID" : 116,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "113",
        "source" : "111",
        "target" : "112",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "Boy in Black (afterCut-1) Boy in White",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Boy in Black (afterCut-1) Boy in White",
        "interaction" : "afterCut-1",
        "SUID" : 113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "110",
        "source" : "108",
        "target" : "75",
        "EdgeBetweenness" : 306.0,
        "shared_name" : "Baymax (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Baymax (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 110,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "109",
        "source" : "108",
        "target" : "71",
        "EdgeBetweenness" : 202.0,
        "shared_name" : "Baymax (afterCut-1) ????",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Baymax (afterCut-1) ????",
        "interaction" : "afterCut-1",
        "SUID" : 109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "244",
        "source" : "105",
        "target" : "117",
        "EdgeBetweenness" : 101.71428571428571,
        "shared_name" : "Pete (afterCut-18) Goofy",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-18",
        "name" : "Pete (afterCut-18) Goofy",
        "interaction" : "afterCut-18",
        "SUID" : 244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "243",
        "source" : "105",
        "target" : "115",
        "EdgeBetweenness" : 103.71428571428571,
        "shared_name" : "Pete (afterCut-18) Donald",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-18",
        "name" : "Pete (afterCut-18) Donald",
        "interaction" : "afterCut-18",
        "SUID" : 243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "source" : "105",
        "target" : "115",
        "EdgeBetweenness" : 103.71428571428571,
        "shared_name" : "Pete (afterCut-18) Donald",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-18",
        "name" : "Pete (afterCut-18) Donald",
        "interaction" : "afterCut-18",
        "SUID" : 242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "107",
        "source" : "102",
        "target" : "105",
        "EdgeBetweenness" : 384.0,
        "shared_name" : "Barbossa (afterCut-13) Pete",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-13",
        "name" : "Barbossa (afterCut-13) Pete",
        "interaction" : "afterCut-13",
        "SUID" : 107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "106",
        "source" : "102",
        "target" : "105",
        "EdgeBetweenness" : 384.0,
        "shared_name" : "Barbossa (afterCut-13) Pete",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-13",
        "name" : "Barbossa (afterCut-13) Pete",
        "interaction" : "afterCut-13",
        "SUID" : 106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "104",
        "source" : "102",
        "target" : "103",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "Barbossa (afterCut-1) Jack Sparrow",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Barbossa (afterCut-1) Jack Sparrow",
        "interaction" : "afterCut-1",
        "SUID" : 104,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "101",
        "source" : "100",
        "target" : "72",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Axel (afterCut-41) Roxas",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-41",
        "name" : "Axel (afterCut-41) Roxas",
        "interaction" : "afterCut-41",
        "SUID" : 101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "99",
        "source" : "92",
        "target" : "89",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Aqua (afterCut-1) Ansem the Wise",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Aqua (afterCut-1) Ansem the Wise",
        "interaction" : "afterCut-1",
        "SUID" : 99,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "98",
        "source" : "92",
        "target" : "89",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Aqua (afterCut-1) Ansem the Wise",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Aqua (afterCut-1) Ansem the Wise",
        "interaction" : "afterCut-1",
        "SUID" : 98,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "97",
        "source" : "92",
        "target" : "89",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Aqua (afterCut-1) Ansem the Wise",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Aqua (afterCut-1) Ansem the Wise",
        "interaction" : "afterCut-1",
        "SUID" : 97,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "96",
        "source" : "89",
        "target" : "84",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "Ansem the Wise (afterCut-15) ????????",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-15",
        "name" : "Ansem the Wise (afterCut-15) ????????",
        "interaction" : "afterCut-15",
        "SUID" : 96,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "95",
        "source" : "89",
        "target" : "84",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "Ansem the Wise (afterCut-15) ????????",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-15",
        "name" : "Ansem the Wise (afterCut-15) ????????",
        "interaction" : "afterCut-15",
        "SUID" : 95,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "94",
        "source" : "89",
        "target" : "92",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Ansem the Wise (afterCut-1) Aqua",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Ansem the Wise (afterCut-1) Aqua",
        "interaction" : "afterCut-1",
        "SUID" : 94,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "93",
        "source" : "89",
        "target" : "92",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "Ansem the Wise (afterCut-1) Aqua",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "Ansem the Wise (afterCut-1) Aqua",
        "interaction" : "afterCut-1",
        "SUID" : 93,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "91",
        "source" : "84",
        "target" : "89",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "???????? (afterCut-9) Ansem the Wise",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-9",
        "name" : "???????? (afterCut-9) Ansem the Wise",
        "interaction" : "afterCut-9",
        "SUID" : 91,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "90",
        "source" : "84",
        "target" : "89",
        "EdgeBetweenness" : 260.0,
        "shared_name" : "???????? (afterCut-9) Ansem the Wise",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-9",
        "name" : "???????? (afterCut-9) Ansem the Wise",
        "interaction" : "afterCut-9",
        "SUID" : 90,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "88",
        "source" : "84",
        "target" : "75",
        "EdgeBetweenness" : 504.0,
        "shared_name" : "???????? (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "???????? (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 88,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "87",
        "source" : "84",
        "target" : "86",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "???????? (afterCut-1) Woody",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "???????? (afterCut-1) Woody",
        "interaction" : "afterCut-1",
        "SUID" : 87,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "85",
        "source" : "84",
        "target" : "75",
        "EdgeBetweenness" : 504.0,
        "shared_name" : "???????? (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "???????? (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 85,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83",
        "source" : "77",
        "target" : "74",
        "EdgeBetweenness" : 384.0,
        "shared_name" : "?????? (afterCut-8) ?????",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-8",
        "name" : "?????? (afterCut-8) ?????",
        "interaction" : "afterCut-8",
        "SUID" : 83,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82",
        "source" : "77",
        "target" : "74",
        "EdgeBetweenness" : 384.0,
        "shared_name" : "?????? (afterCut-8) ?????",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-8",
        "name" : "?????? (afterCut-8) ?????",
        "interaction" : "afterCut-8",
        "SUID" : 82,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81",
        "source" : "77",
        "target" : "74",
        "EdgeBetweenness" : 384.0,
        "shared_name" : "?????? (afterCut-8) ?????",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-8",
        "name" : "?????? (afterCut-8) ?????",
        "interaction" : "afterCut-8",
        "SUID" : 81,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80",
        "source" : "74",
        "target" : "77",
        "EdgeBetweenness" : 384.0,
        "shared_name" : "????? (afterCut-14) ??????",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-14",
        "name" : "????? (afterCut-14) ??????",
        "interaction" : "afterCut-14",
        "SUID" : 80,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "79",
        "source" : "74",
        "target" : "77",
        "EdgeBetweenness" : 384.0,
        "shared_name" : "????? (afterCut-14) ??????",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-14",
        "name" : "????? (afterCut-14) ??????",
        "interaction" : "afterCut-14",
        "SUID" : 79,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "78",
        "source" : "74",
        "target" : "77",
        "EdgeBetweenness" : 384.0,
        "shared_name" : "????? (afterCut-14) ??????",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-14",
        "name" : "????? (afterCut-14) ??????",
        "interaction" : "afterCut-14",
        "SUID" : 78,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "76",
        "source" : "74",
        "target" : "75",
        "EdgeBetweenness" : 620.0,
        "shared_name" : "????? (afterCut-1) Sora",
        "Game" : "kingdom_hearts_3_script.xml",
        "shared_interaction" : "afterCut-1",
        "name" : "????? (afterCut-1) Sora",
        "interaction" : "afterCut-1",
        "SUID" : 76,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "73",
        "source" : "71",
        "target" : "72",
        "EdgeBetweenness" : 78.0,
        "shared_name" : "???? (afterCut-34) Roxas",
        "Game" : "Kingdom_hearts_2.5_script.xml",
        "shared_interaction" : "afterCut-34",
        "name" : "???? (afterCut-34) Roxas",
        "interaction" : "afterCut-34",
        "SUID" : 73,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}